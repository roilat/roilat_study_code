/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.PrintStream;
/*    */ import java.io.Writer;
/*    */ import org.pdfbox.pdmodel.PDDocument;
/*    */ import org.pdfbox.util.PDFTextStripper;
/*    */ 
/*    */ public class PDFBox
/*    */ {
/*    */   public static void pdfToDoc(String name1)
/*    */     throws IOException
/*    */   {
/* 19 */     PDDocument doc = PDDocument.load(name1);
/* 20 */     int pagenumber = doc.getNumberOfPages();
/*    */ 
/* 22 */     name1 = name1.substring(0, name1.lastIndexOf("."));
/*    */ 
/* 24 */     String dirName = name1;
/*    */ 
/* 26 */     String fileName = dirName + ".doc";
/* 27 */     createFile(fileName);
/* 28 */     FileOutputStream fos = new FileOutputStream(fileName);
/* 29 */     Writer writer = new OutputStreamWriter(fos, "UTF-8");
/* 30 */     PDFTextStripper stripper = new PDFTextStripper();
/*    */ 
/* 32 */     stripper.setSortByPosition(true);
/*    */ 
/* 34 */     stripper.setStartPage(1);
/* 35 */     stripper.setEndPage(pagenumber);
/* 36 */     stripper.writeText(doc, writer);
/* 37 */     writer.close();
/* 38 */     doc.close();
/* 39 */     System.out.println("pdf转换word成功！");
/*    */   }
/*    */ 
/*    */   private static void createDir(String destDirName)
/*    */   {
/* 46 */     File dir = new File(destDirName);
/* 47 */     if (dir.exists()) {
/* 48 */       System.out.println("创建目录失败，目标目录已存在！");
/*    */     }
/* 50 */     if (!destDirName.endsWith(File.separator)) {
/* 51 */       destDirName = destDirName + File.separator;
/*    */     }
/* 53 */     if (dir.mkdirs())
/* 54 */       System.out.println("创建目录成功！" + destDirName);
/*    */     else
/* 56 */       System.out.println("创建目录失败！");
/*    */   }
/*    */ 
/*    */   public static void createFile(String filePath)
/*    */   {
/* 61 */     File file = new File(filePath);
/* 62 */     if (file.exists()) {
/* 63 */       System.out.println("目标文件已存在" + filePath);
/*    */     }
/* 65 */     if (filePath.endsWith(File.separator)) {
/* 66 */       System.out.println("目标文件不能为目录！");
/*    */     }
/* 68 */     if (!file.getParentFile().exists())
/*    */     {
/* 70 */       System.out.println("目标文件所在目录不存在，准备创建它！");
/* 71 */       if (!file.getParentFile().mkdirs())
/* 72 */         System.out.println("创建目标文件所在的目录失败！");
/*    */     }
/*    */     try
/*    */     {
/* 76 */       if (file.createNewFile())
/* 77 */         System.out.println("创建文件成功:" + filePath);
/*    */       else
/* 79 */         System.out.println("创建文件失败！");
/*    */     }
/*    */     catch (IOException e) {
/* 82 */       e.printStackTrace();
/* 83 */       System.out.println("创建文件失败！" + e.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 88 */     String a = "D:\\java\\a.pdf";
/*    */ 
/* 91 */     pdfToDoc(a);
/*    */   }
/*    */ }

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     PDFBox
 * JD-Core Version:    0.6.0
 */