package org.bouncycastle.asn1;

import java.io.OutputStream;

public abstract class ASN1Generator
{
  protected OutputStream _out;

  public ASN1Generator(OutputStream paramOutputStream)
  {
    this._out = paramOutputStream;
  }

  public abstract OutputStream getRawOutputStream();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1Generator
 * JD-Core Version:    0.6.0
 */