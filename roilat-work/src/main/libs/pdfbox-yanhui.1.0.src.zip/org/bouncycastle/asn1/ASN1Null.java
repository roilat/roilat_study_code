package org.bouncycastle.asn1;

import java.io.IOException;

public abstract class ASN1Null extends ASN1Object
{
  public int hashCode()
  {
    return -1;
  }

  boolean asn1Equals(DERObject paramDERObject)
  {
    return (paramDERObject instanceof ASN1Null);
  }

  abstract void encode(DEROutputStream paramDEROutputStream)
    throws IOException;

  public String toString()
  {
    return "NULL";
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1Null
 * JD-Core Version:    0.6.0
 */