package org.bouncycastle.asn1;

import java.io.InputStream;

/** @deprecated */
public class ASN1ObjectParser
{
  ASN1StreamParser _aIn;

  protected ASN1ObjectParser(int paramInt1, int paramInt2, InputStream paramInputStream)
  {
    this._aIn = new ASN1StreamParser(paramInputStream);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1ObjectParser
 * JD-Core Version:    0.6.0
 */