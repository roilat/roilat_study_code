package org.bouncycastle.asn1;

import java.io.InputStream;

public abstract interface ASN1OctetStringParser extends DEREncodable
{
  public abstract InputStream getOctetStream();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1OctetStringParser
 * JD-Core Version:    0.6.0
 */