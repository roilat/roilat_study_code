package org.bouncycastle.asn1;

import java.io.IOException;
import java.io.OutputStream;

public class ASN1OutputStream extends DEROutputStream
{
  public ASN1OutputStream(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }

  public void writeObject(Object paramObject)
    throws IOException
  {
    if (paramObject == null)
      writeNull();
    else if ((paramObject instanceof DERObject))
      ((DERObject)paramObject).encode(this);
    else if ((paramObject instanceof DEREncodable))
      ((DEREncodable)paramObject).getDERObject().encode(this);
    else
      throw new IOException("object not ASN1Encodable");
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1OutputStream
 * JD-Core Version:    0.6.0
 */