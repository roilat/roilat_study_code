package org.bouncycastle.asn1;

public class ASN1ParsingException extends IllegalStateException
{
  private Throwable cause;

  ASN1ParsingException(String paramString)
  {
    super(paramString);
  }

  ASN1ParsingException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    this.cause = paramThrowable;
  }

  public Throwable getCause()
  {
    return this.cause;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1ParsingException
 * JD-Core Version:    0.6.0
 */