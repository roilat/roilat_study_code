package org.bouncycastle.asn1;

import java.io.IOException;

public abstract interface ASN1SetParser extends DEREncodable
{
  public abstract DEREncodable readObject()
    throws IOException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1SetParser
 * JD-Core Version:    0.6.0
 */