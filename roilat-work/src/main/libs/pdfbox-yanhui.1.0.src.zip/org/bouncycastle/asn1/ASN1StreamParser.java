package org.bouncycastle.asn1;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

public class ASN1StreamParser
{
  private final InputStream _in;
  private final int _limit;

  private static int findLimit(InputStream paramInputStream)
  {
    if ((paramInputStream instanceof DefiniteLengthInputStream))
      return ((DefiniteLengthInputStream)paramInputStream).getRemaining();
    return 2147483647;
  }

  public ASN1StreamParser(InputStream paramInputStream)
  {
    this(paramInputStream, findLimit(paramInputStream));
  }

  public ASN1StreamParser(InputStream paramInputStream, int paramInt)
  {
    this._in = paramInputStream;
    this._limit = paramInt;
  }

  public ASN1StreamParser(byte[] paramArrayOfByte)
  {
    this(new ByteArrayInputStream(paramArrayOfByte), paramArrayOfByte.length);
  }

  public DEREncodable readObject()
    throws IOException
  {
    int i = this._in.read();
    if (i == -1)
      return null;
    set00Check(false);
    int j = ASN1InputStream.readTagNumber(this._in, i);
    boolean bool = (i & 0x20) != 0;
    int k = ASN1InputStream.readLength(this._in, this._limit);
    if (k < 0)
    {
      if (!bool)
        throw new IOException("indefinite length primitive encoding encountered");
      localObject = new IndefiniteLengthInputStream(this._in);
      if ((i & 0x40) != 0)
      {
        localASN1StreamParser = new ASN1StreamParser((InputStream)localObject, this._limit);
        return new BERApplicationSpecificParser(j, localASN1StreamParser);
      }
      if ((i & 0x80) != 0)
        return new BERTaggedObjectParser(i, j, (InputStream)localObject);
      ASN1StreamParser localASN1StreamParser = new ASN1StreamParser((InputStream)localObject, this._limit);
      switch (j)
      {
      case 4:
        return new BEROctetStringParser(localASN1StreamParser);
      case 16:
        return new BERSequenceParser(localASN1StreamParser);
      case 17:
        return new BERSetParser(localASN1StreamParser);
      case 8:
        return new DERExternalParser(localASN1StreamParser);
      }
      throw new IOException("unknown BER object encountered: 0x" + Integer.toHexString(j));
    }
    Object localObject = new DefiniteLengthInputStream(this._in, k);
    if ((i & 0x40) != 0)
      return new DERApplicationSpecific(bool, j, ((DefiniteLengthInputStream)localObject).toByteArray());
    if ((i & 0x80) != 0)
      return new BERTaggedObjectParser(i, j, (InputStream)localObject);
    if (bool)
    {
      switch (j)
      {
      case 4:
        return new BEROctetStringParser(new ASN1StreamParser((InputStream)localObject));
      case 16:
        return new DERSequenceParser(new ASN1StreamParser((InputStream)localObject));
      case 17:
        return new DERSetParser(new ASN1StreamParser((InputStream)localObject));
      case 8:
        return new DERExternalParser(new ASN1StreamParser((InputStream)localObject));
      }
      return new DERUnknownTag(true, j, ((DefiniteLengthInputStream)localObject).toByteArray());
    }
    switch (j)
    {
    case 4:
      return new DEROctetStringParser((DefiniteLengthInputStream)localObject);
    }
    return (DEREncodable)ASN1InputStream.createPrimitiveDERObject(j, ((DefiniteLengthInputStream)localObject).toByteArray());
  }

  private void set00Check(boolean paramBoolean)
  {
    if ((this._in instanceof IndefiniteLengthInputStream))
      ((IndefiniteLengthInputStream)this._in).setEofOn00(paramBoolean);
  }

  ASN1EncodableVector readVector()
    throws IOException
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    DEREncodable localDEREncodable;
    while ((localDEREncodable = readObject()) != null)
      localASN1EncodableVector.add(localDEREncodable.getDERObject());
    return localASN1EncodableVector;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1StreamParser
 * JD-Core Version:    0.6.0
 */