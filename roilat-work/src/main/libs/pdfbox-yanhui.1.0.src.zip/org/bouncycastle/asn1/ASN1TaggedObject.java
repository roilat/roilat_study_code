package org.bouncycastle.asn1;

import java.io.IOException;

public abstract class ASN1TaggedObject extends ASN1Object
  implements ASN1TaggedObjectParser
{
  int tagNo;
  boolean empty = false;
  boolean explicit = true;
  DEREncodable obj = null;

  public static ASN1TaggedObject getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    if (paramBoolean)
      return (ASN1TaggedObject)paramASN1TaggedObject.getObject();
    throw new IllegalArgumentException("implicitly tagged tagged object");
  }

  public static ASN1TaggedObject getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ASN1TaggedObject)))
      return (ASN1TaggedObject)paramObject;
    throw new IllegalArgumentException("unknown object in getInstance: " + paramObject.getClass().getName());
  }

  public ASN1TaggedObject(int paramInt, DEREncodable paramDEREncodable)
  {
    this.explicit = true;
    this.tagNo = paramInt;
    this.obj = paramDEREncodable;
  }

  public ASN1TaggedObject(boolean paramBoolean, int paramInt, DEREncodable paramDEREncodable)
  {
    if ((paramDEREncodable instanceof ASN1Choice))
      this.explicit = true;
    else
      this.explicit = paramBoolean;
    this.tagNo = paramInt;
    this.obj = paramDEREncodable;
  }

  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof ASN1TaggedObject))
      return false;
    ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)paramDERObject;
    if ((this.tagNo != localASN1TaggedObject.tagNo) || (this.empty != localASN1TaggedObject.empty) || (this.explicit != localASN1TaggedObject.explicit))
      return false;
    if (this.obj == null)
    {
      if (localASN1TaggedObject.obj != null)
        return false;
    }
    else if (!this.obj.getDERObject().equals(localASN1TaggedObject.obj.getDERObject()))
      return false;
    return true;
  }

  public int hashCode()
  {
    int i = this.tagNo;
    if (this.obj != null)
      i ^= this.obj.hashCode();
    return i;
  }

  public int getTagNo()
  {
    return this.tagNo;
  }

  public boolean isExplicit()
  {
    return this.explicit;
  }

  public boolean isEmpty()
  {
    return this.empty;
  }

  public DERObject getObject()
  {
    if (this.obj != null)
      return this.obj.getDERObject();
    return null;
  }

  public DEREncodable getObjectParser(int paramInt, boolean paramBoolean)
  {
    switch (paramInt)
    {
    case 17:
      return ASN1Set.getInstance(this, paramBoolean).parser();
    case 16:
      return ASN1Sequence.getInstance(this, paramBoolean).parser();
    case 4:
      return ASN1OctetString.getInstance(this, paramBoolean).parser();
    }
    if (paramBoolean)
      return getObject();
    throw new RuntimeException("implicit tagging not implemented for tag: " + paramInt);
  }

  abstract void encode(DEROutputStream paramDEROutputStream)
    throws IOException;

  public String toString()
  {
    return "[" + this.tagNo + "]" + this.obj;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1TaggedObject
 * JD-Core Version:    0.6.0
 */