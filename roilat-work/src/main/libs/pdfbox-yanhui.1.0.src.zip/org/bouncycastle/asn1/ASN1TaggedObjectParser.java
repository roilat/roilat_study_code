package org.bouncycastle.asn1;

import java.io.IOException;

public abstract interface ASN1TaggedObjectParser extends DEREncodable
{
  public abstract int getTagNo();

  public abstract DEREncodable getObjectParser(int paramInt, boolean paramBoolean)
    throws IOException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ASN1TaggedObjectParser
 * JD-Core Version:    0.6.0
 */