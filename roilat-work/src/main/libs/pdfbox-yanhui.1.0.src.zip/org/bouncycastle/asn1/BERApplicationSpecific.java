package org.bouncycastle.asn1;

public class BERApplicationSpecific extends DERApplicationSpecific
{
  public BERApplicationSpecific(int paramInt, ASN1EncodableVector paramASN1EncodableVector)
  {
    super(paramInt, paramASN1EncodableVector);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.BERApplicationSpecific
 * JD-Core Version:    0.6.0
 */