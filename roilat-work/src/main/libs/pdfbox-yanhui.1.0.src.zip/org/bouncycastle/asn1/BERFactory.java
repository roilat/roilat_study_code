package org.bouncycastle.asn1;

class BERFactory
{
  static final BERSequence EMPTY_SEQUENCE = new BERSequence();
  static final BERSet EMPTY_SET = new BERSet();

  static BERSequence createSequence(ASN1EncodableVector paramASN1EncodableVector)
  {
    return paramASN1EncodableVector.size() < 1 ? EMPTY_SEQUENCE : new BERSequence(paramASN1EncodableVector);
  }

  static BERSet createSet(ASN1EncodableVector paramASN1EncodableVector)
  {
    return paramASN1EncodableVector.size() < 1 ? EMPTY_SET : new BERSet(paramASN1EncodableVector);
  }

  static BERSet createSet(ASN1EncodableVector paramASN1EncodableVector, boolean paramBoolean)
  {
    return paramASN1EncodableVector.size() < 1 ? EMPTY_SET : new BERSet(paramASN1EncodableVector, paramBoolean);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.BERFactory
 * JD-Core Version:    0.6.0
 */