package org.bouncycastle.asn1;

import java.io.IOException;

public class BERNull extends DERNull
{
  public static final BERNull INSTANCE = new BERNull();

  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    if (((paramDEROutputStream instanceof ASN1OutputStream)) || ((paramDEROutputStream instanceof BEROutputStream)))
      paramDEROutputStream.write(5);
    else
      super.encode(paramDEROutputStream);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.BERNull
 * JD-Core Version:    0.6.0
 */