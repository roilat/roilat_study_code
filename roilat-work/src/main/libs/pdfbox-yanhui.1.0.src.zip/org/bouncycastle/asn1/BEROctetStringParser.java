package org.bouncycastle.asn1;

import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.util.io.Streams;

public class BEROctetStringParser
  implements ASN1OctetStringParser
{
  private ASN1StreamParser _parser;

  BEROctetStringParser(ASN1StreamParser paramASN1StreamParser)
  {
    this._parser = paramASN1StreamParser;
  }

  /** @deprecated */
  protected BEROctetStringParser(ASN1ObjectParser paramASN1ObjectParser)
  {
    this._parser = paramASN1ObjectParser._aIn;
  }

  public InputStream getOctetStream()
  {
    return new ConstructedOctetStream(this._parser);
  }

  public DERObject getDERObject()
  {
    try
    {
      return new BERConstructedOctetString(Streams.readAll(getOctetStream()));
    }
    catch (IOException localIOException)
    {
    }
    throw new ASN1ParsingException("IOException converting stream to byte array: " + localIOException.getMessage(), localIOException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.BEROctetStringParser
 * JD-Core Version:    0.6.0
 */