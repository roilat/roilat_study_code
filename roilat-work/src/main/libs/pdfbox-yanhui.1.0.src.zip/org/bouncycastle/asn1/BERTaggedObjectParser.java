package org.bouncycastle.asn1;

import java.io.IOException;
import java.io.InputStream;

public class BERTaggedObjectParser
  implements ASN1TaggedObjectParser
{
  private int _baseTag;
  private int _tagNumber;
  private InputStream _contentStream;
  private boolean _indefiniteLength;

  protected BERTaggedObjectParser(int paramInt1, int paramInt2, InputStream paramInputStream)
  {
    this._baseTag = paramInt1;
    this._tagNumber = paramInt2;
    this._contentStream = paramInputStream;
    this._indefiniteLength = (paramInputStream instanceof IndefiniteLengthInputStream);
  }

  public boolean isConstructed()
  {
    return (this._baseTag & 0x20) != 0;
  }

  public int getTagNo()
  {
    return this._tagNumber;
  }

  public DEREncodable getObjectParser(int paramInt, boolean paramBoolean)
    throws IOException
  {
    if (paramBoolean)
      return new ASN1StreamParser(this._contentStream).readObject();
    switch (paramInt)
    {
    case 17:
      if (this._indefiniteLength)
        return new BERSetParser(new ASN1StreamParser(this._contentStream));
      return new DERSetParser(new ASN1StreamParser(this._contentStream));
    case 16:
      if (this._indefiniteLength)
        return new BERSequenceParser(new ASN1StreamParser(this._contentStream));
      return new DERSequenceParser(new ASN1StreamParser(this._contentStream));
    case 4:
      if ((this._indefiniteLength) || (isConstructed()))
        return new BEROctetStringParser(new ASN1StreamParser(this._contentStream));
      return new DEROctetStringParser((DefiniteLengthInputStream)this._contentStream);
    }
    throw new RuntimeException("implicit tagging not implemented");
  }

  private ASN1EncodableVector rLoadVector(InputStream paramInputStream)
  {
    try
    {
      return new ASN1StreamParser(paramInputStream).readVector();
    }
    catch (IOException localIOException)
    {
    }
    throw new ASN1ParsingException(localIOException.getMessage(), localIOException);
  }

  public DERObject getDERObject()
  {
    Object localObject;
    if (this._indefiniteLength)
    {
      localObject = rLoadVector(this._contentStream);
      return ((ASN1EncodableVector)localObject).size() == 1 ? new BERTaggedObject(true, this._tagNumber, ((ASN1EncodableVector)localObject).get(0)) : new BERTaggedObject(false, this._tagNumber, BERFactory.createSequence((ASN1EncodableVector)localObject));
    }
    if (isConstructed())
    {
      localObject = rLoadVector(this._contentStream);
      return ((ASN1EncodableVector)localObject).size() == 1 ? new DERTaggedObject(true, this._tagNumber, ((ASN1EncodableVector)localObject).get(0)) : new DERTaggedObject(false, this._tagNumber, DERFactory.createSequence((ASN1EncodableVector)localObject));
    }
    try
    {
      localObject = (DefiniteLengthInputStream)this._contentStream;
      return new DERTaggedObject(false, this._tagNumber, new DEROctetString(((DefiniteLengthInputStream)localObject).toByteArray()));
    }
    catch (IOException localIOException)
    {
    }
    throw new IllegalStateException(localIOException.getMessage());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.BERTaggedObjectParser
 * JD-Core Version:    0.6.0
 */