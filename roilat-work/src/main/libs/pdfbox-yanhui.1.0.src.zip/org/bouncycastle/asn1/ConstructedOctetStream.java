package org.bouncycastle.asn1;

import java.io.IOException;
import java.io.InputStream;

class ConstructedOctetStream extends InputStream
{
  private final ASN1StreamParser _parser;
  private boolean _first = true;
  private InputStream _currentStream;

  ConstructedOctetStream(ASN1StreamParser paramASN1StreamParser)
  {
    this._parser = paramASN1StreamParser;
  }

  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (this._currentStream == null)
    {
      if (!this._first)
        return -1;
      ASN1OctetStringParser localASN1OctetStringParser1 = (ASN1OctetStringParser)this._parser.readObject();
      if (localASN1OctetStringParser1 == null)
        return -1;
      this._first = false;
      this._currentStream = localASN1OctetStringParser1.getOctetStream();
    }
    int i = 0;
    while (true)
    {
      int j = this._currentStream.read(paramArrayOfByte, paramInt1 + i, paramInt2 - i);
      if (j >= 0)
      {
        i += j;
        if (i == paramInt2)
          return i;
      }
      ASN1OctetStringParser localASN1OctetStringParser2 = (ASN1OctetStringParser)this._parser.readObject();
      if (localASN1OctetStringParser2 == null)
      {
        this._currentStream = null;
        return i < 1 ? -1 : i;
      }
      this._currentStream = localASN1OctetStringParser2.getOctetStream();
    }
  }

  public int read()
    throws IOException
  {
    ASN1OctetStringParser localASN1OctetStringParser1;
    if (this._currentStream == null)
    {
      if (!this._first)
        return -1;
      localASN1OctetStringParser1 = (ASN1OctetStringParser)this._parser.readObject();
      if (localASN1OctetStringParser1 == null)
        return -1;
      this._first = false;
    }
    ASN1OctetStringParser localASN1OctetStringParser2;
    for (this._currentStream = localASN1OctetStringParser1.getOctetStream(); ; this._currentStream = localASN1OctetStringParser2.getOctetStream())
    {
      int i = this._currentStream.read();
      if (i >= 0)
        return i;
      localASN1OctetStringParser2 = (ASN1OctetStringParser)this._parser.readObject();
      if (localASN1OctetStringParser2 != null)
        continue;
      this._currentStream = null;
      return -1;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.ConstructedOctetStream
 * JD-Core Version:    0.6.0
 */