package org.bouncycastle.asn1;

import java.io.IOException;

public class DERBoolean extends ASN1Object
{
  byte value;
  public static final DERBoolean FALSE = new DERBoolean(false);
  public static final DERBoolean TRUE = new DERBoolean(true);

  public static DERBoolean getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DERBoolean)))
      return (DERBoolean)paramObject;
    if ((paramObject instanceof ASN1OctetString))
      return new DERBoolean(((ASN1OctetString)paramObject).getOctets());
    if ((paramObject instanceof ASN1TaggedObject))
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }

  public static DERBoolean getInstance(boolean paramBoolean)
  {
    return paramBoolean ? TRUE : FALSE;
  }

  public static DERBoolean getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }

  public DERBoolean(byte[] paramArrayOfByte)
  {
    this.value = paramArrayOfByte[0];
  }

  public DERBoolean(boolean paramBoolean)
  {
    this.value = (paramBoolean ? -1 : 0);
  }

  public boolean isTrue()
  {
    return this.value != 0;
  }

  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[1];
    arrayOfByte[0] = this.value;
    paramDEROutputStream.writeEncoded(1, arrayOfByte);
  }

  protected boolean asn1Equals(DERObject paramDERObject)
  {
    if ((paramDERObject == null) || (!(paramDERObject instanceof DERBoolean)))
      return false;
    return this.value == ((DERBoolean)paramDERObject).value;
  }

  public int hashCode()
  {
    return this.value;
  }

  public String toString()
  {
    return this.value != 0 ? "TRUE" : "FALSE";
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DERBoolean
 * JD-Core Version:    0.6.0
 */