package org.bouncycastle.asn1;

public abstract interface DEREncodable
{
  public abstract DERObject getDERObject();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DEREncodable
 * JD-Core Version:    0.6.0
 */