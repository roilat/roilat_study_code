package org.bouncycastle.asn1;

import java.io.IOException;

public class DERExternalParser
  implements DEREncodable
{
  private ASN1StreamParser _parser;

  public DERExternalParser(ASN1StreamParser paramASN1StreamParser)
  {
    this._parser = paramASN1StreamParser;
  }

  public DEREncodable readObject()
    throws IOException
  {
    return this._parser.readObject();
  }

  public DERObject getDERObject()
  {
    try
    {
      return new DERExternal(this._parser.readVector());
    }
    catch (IOException localIOException)
    {
      throw new ASN1ParsingException("unable to get DER object", localIOException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    throw new ASN1ParsingException("unable to get DER object", localIllegalArgumentException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DERExternalParser
 * JD-Core Version:    0.6.0
 */