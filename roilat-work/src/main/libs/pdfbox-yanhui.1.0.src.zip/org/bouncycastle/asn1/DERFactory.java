package org.bouncycastle.asn1;

class DERFactory
{
  static final DERSequence EMPTY_SEQUENCE = new DERSequence();
  static final DERSet EMPTY_SET = new DERSet();

  static DERSequence createSequence(ASN1EncodableVector paramASN1EncodableVector)
  {
    return paramASN1EncodableVector.size() < 1 ? EMPTY_SEQUENCE : new DERSequence(paramASN1EncodableVector);
  }

  static DERSet createSet(ASN1EncodableVector paramASN1EncodableVector)
  {
    return paramASN1EncodableVector.size() < 1 ? EMPTY_SET : new DERSet(paramASN1EncodableVector);
  }

  static DERSet createSet(ASN1EncodableVector paramASN1EncodableVector, boolean paramBoolean)
  {
    return paramASN1EncodableVector.size() < 1 ? EMPTY_SET : new DERSet(paramASN1EncodableVector, paramBoolean);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DERFactory
 * JD-Core Version:    0.6.0
 */