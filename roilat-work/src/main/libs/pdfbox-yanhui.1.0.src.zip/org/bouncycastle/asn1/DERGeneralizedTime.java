package org.bouncycastle.asn1;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

public class DERGeneralizedTime extends ASN1Object
{
  String time;

  public static DERGeneralizedTime getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DERGeneralizedTime)))
      return (DERGeneralizedTime)paramObject;
    if ((paramObject instanceof ASN1OctetString))
      return new DERGeneralizedTime(((ASN1OctetString)paramObject).getOctets());
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }

  public static DERGeneralizedTime getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }

  public DERGeneralizedTime(String paramString)
  {
    this.time = paramString;
    try
    {
      getDate();
    }
    catch (ParseException localParseException)
    {
      throw new IllegalArgumentException("invalid date string: " + localParseException.getMessage());
    }
  }

  public DERGeneralizedTime(Date paramDate)
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss'Z'");
    localSimpleDateFormat.setTimeZone(new SimpleTimeZone(0, "Z"));
    this.time = localSimpleDateFormat.format(paramDate);
  }

  DERGeneralizedTime(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length];
    for (int i = 0; i != arrayOfChar.length; i++)
      arrayOfChar[i] = (char)(paramArrayOfByte[i] & 0xFF);
    this.time = new String(arrayOfChar);
  }

  public String getTimeString()
  {
    return this.time;
  }

  public String getTime()
  {
    if (this.time.charAt(this.time.length() - 1) == 'Z')
      return this.time.substring(0, this.time.length() - 1) + "GMT+00:00";
    int i = this.time.length() - 5;
    int j = this.time.charAt(i);
    if ((j == 45) || (j == 43))
      return this.time.substring(0, i) + "GMT" + this.time.substring(i, i + 3) + ":" + this.time.substring(i + 3);
    i = this.time.length() - 3;
    j = this.time.charAt(i);
    if ((j == 45) || (j == 43))
      return this.time.substring(0, i) + "GMT" + this.time.substring(i) + ":00";
    return this.time + calculateGMTOffset();
  }

  private String calculateGMTOffset()
  {
    String str = "+";
    TimeZone localTimeZone = TimeZone.getDefault();
    int i = localTimeZone.getRawOffset();
    if (i < 0)
    {
      str = "-";
      i = -i;
    }
    int j = i / 3600000;
    int k = (i - j * 60 * 60 * 1000) / 60000;
    try
    {
      if ((localTimeZone.useDaylightTime()) && (localTimeZone.inDaylightTime(getDate())))
        j += (str.equals("+") ? 1 : -1);
    }
    catch (ParseException localParseException)
    {
    }
    return "GMT" + str + convert(j) + ":" + convert(k);
  }

  private String convert(int paramInt)
  {
    if (paramInt < 10)
      return "0" + paramInt;
    return Integer.toString(paramInt);
  }

  public Date getDate()
    throws ParseException
  {
    String str1 = this.time;
    SimpleDateFormat localSimpleDateFormat;
    if (this.time.endsWith("Z"))
    {
      if (hasFractionalSeconds())
        localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss.SSS'Z'");
      else
        localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss'Z'");
      localSimpleDateFormat.setTimeZone(new SimpleTimeZone(0, "Z"));
    }
    else if ((this.time.indexOf('-') > 0) || (this.time.indexOf('+') > 0))
    {
      str1 = getTime();
      if (hasFractionalSeconds())
        localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss.SSSz");
      else
        localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmssz");
      localSimpleDateFormat.setTimeZone(new SimpleTimeZone(0, "Z"));
    }
    else
    {
      if (hasFractionalSeconds())
        localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss.SSS");
      else
        localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
      localSimpleDateFormat.setTimeZone(new SimpleTimeZone(0, TimeZone.getDefault().getID()));
    }
    if (hasFractionalSeconds())
    {
      String str2 = str1.substring(14);
      for (int i = 1; i < str2.length(); i++)
      {
        int j = str2.charAt(i);
        if ((48 > j) || (j > 57))
          break;
      }
      if (i - 1 > 3)
      {
        str2 = str2.substring(0, 4) + str2.substring(i);
        str1 = str1.substring(0, 14) + str2;
      }
    }
    return localSimpleDateFormat.parse(str1);
  }

  private boolean hasFractionalSeconds()
  {
    return this.time.indexOf('.') == 14;
  }

  private byte[] getOctets()
  {
    char[] arrayOfChar = this.time.toCharArray();
    byte[] arrayOfByte = new byte[arrayOfChar.length];
    for (int i = 0; i != arrayOfChar.length; i++)
      arrayOfByte[i] = (byte)arrayOfChar[i];
    return arrayOfByte;
  }

  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(24, getOctets());
  }

  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERGeneralizedTime))
      return false;
    return this.time.equals(((DERGeneralizedTime)paramDERObject).time);
  }

  public int hashCode()
  {
    return this.time.hashCode();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DERGeneralizedTime
 * JD-Core Version:    0.6.0
 */