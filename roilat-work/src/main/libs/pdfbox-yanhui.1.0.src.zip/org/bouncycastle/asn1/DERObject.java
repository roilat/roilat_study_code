package org.bouncycastle.asn1;

import java.io.IOException;

public abstract class DERObject extends ASN1Encodable
  implements DERTags
{
  public DERObject toASN1Object()
  {
    return this;
  }

  public abstract int hashCode();

  public abstract boolean equals(Object paramObject);

  abstract void encode(DEROutputStream paramDEROutputStream)
    throws IOException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DERObject
 * JD-Core Version:    0.6.0
 */