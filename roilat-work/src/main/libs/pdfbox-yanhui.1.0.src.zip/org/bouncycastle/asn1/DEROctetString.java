package org.bouncycastle.asn1;

import java.io.IOException;

public class DEROctetString extends ASN1OctetString
{
  public DEROctetString(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
  }

  public DEROctetString(DEREncodable paramDEREncodable)
  {
    super(paramDEREncodable);
  }

  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(4, this.string);
  }

  static void encode(DEROutputStream paramDEROutputStream, byte[] paramArrayOfByte)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(4, paramArrayOfByte);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DEROctetString
 * JD-Core Version:    0.6.0
 */