package org.bouncycastle.asn1;

import java.io.IOException;
import java.io.InputStream;

public class DEROctetStringParser
  implements ASN1OctetStringParser
{
  private DefiniteLengthInputStream stream;

  DEROctetStringParser(DefiniteLengthInputStream paramDefiniteLengthInputStream)
  {
    this.stream = paramDefiniteLengthInputStream;
  }

  public InputStream getOctetStream()
  {
    return this.stream;
  }

  public DERObject getDERObject()
  {
    try
    {
      return new DEROctetString(this.stream.toByteArray());
    }
    catch (IOException localIOException)
    {
    }
    throw new ASN1ParsingException("IOException converting stream to byte array: " + localIOException.getMessage(), localIOException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DEROctetStringParser
 * JD-Core Version:    0.6.0
 */