package org.bouncycastle.asn1;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class DEROutputStream extends FilterOutputStream
  implements DERTags
{
  public DEROutputStream(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }

  private void writeLength(int paramInt)
    throws IOException
  {
    if (paramInt > 127)
    {
      int i = 1;
      int j = paramInt;
      while (j >>>= 8 != 0)
        i++;
      write((byte)(i | 0x80));
      for (int k = (i - 1) * 8; k >= 0; k -= 8)
        write((byte)(paramInt >> k));
    }
    write((byte)paramInt);
  }

  void writeEncoded(int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramInt);
    writeLength(paramArrayOfByte.length);
    write(paramArrayOfByte);
  }

  void writeTag(int paramInt1, int paramInt2)
    throws IOException
  {
    if (paramInt2 < 31)
    {
      write(paramInt1 | paramInt2);
    }
    else
    {
      write(paramInt1 | 0x1F);
      if (paramInt2 < 128)
      {
        write(paramInt2);
      }
      else
      {
        byte[] arrayOfByte = new byte[5];
        int i = arrayOfByte.length;
        i--;
        arrayOfByte[i] = (byte)(paramInt2 & 0x7F);
        do
        {
          paramInt2 >>= 7;
          i--;
          arrayOfByte[i] = (byte)(paramInt2 & 0x7F | 0x80);
        }
        while (paramInt2 > 127);
        write(arrayOfByte, i, arrayOfByte.length - i);
      }
    }
  }

  void writeEncoded(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
    throws IOException
  {
    writeTag(paramInt1, paramInt2);
    writeLength(paramArrayOfByte.length);
    write(paramArrayOfByte);
  }

  protected void writeNull()
    throws IOException
  {
    write(5);
    write(0);
  }

  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    this.out.write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.out.write(paramArrayOfByte, paramInt1, paramInt2);
  }

  public void writeObject(Object paramObject)
    throws IOException
  {
    if (paramObject == null)
      writeNull();
    else if ((paramObject instanceof DERObject))
      ((DERObject)paramObject).encode(this);
    else if ((paramObject instanceof DEREncodable))
      ((DEREncodable)paramObject).getDERObject().encode(this);
    else
      throw new IOException("object not DEREncodable");
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DEROutputStream
 * JD-Core Version:    0.6.0
 */