package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class DERSequenceGenerator extends DERGenerator
{
  private final ByteArrayOutputStream _bOut = new ByteArrayOutputStream();

  public DERSequenceGenerator(OutputStream paramOutputStream)
    throws IOException
  {
    super(paramOutputStream);
  }

  public DERSequenceGenerator(OutputStream paramOutputStream, int paramInt, boolean paramBoolean)
    throws IOException
  {
    super(paramOutputStream, paramInt, paramBoolean);
  }

  public void addObject(DEREncodable paramDEREncodable)
    throws IOException
  {
    paramDEREncodable.getDERObject().encode(new DEROutputStream(this._bOut));
  }

  public OutputStream getRawOutputStream()
  {
    return this._bOut;
  }

  public void close()
    throws IOException
  {
    writeDEREncoded(48, this._bOut.toByteArray());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DERSequenceGenerator
 * JD-Core Version:    0.6.0
 */