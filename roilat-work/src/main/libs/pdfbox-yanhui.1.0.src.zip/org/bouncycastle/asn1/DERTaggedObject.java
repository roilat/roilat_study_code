package org.bouncycastle.asn1;

import java.io.IOException;

public class DERTaggedObject extends ASN1TaggedObject
{
  private static final byte[] ZERO_BYTES = new byte[0];

  public DERTaggedObject(int paramInt, DEREncodable paramDEREncodable)
  {
    super(paramInt, paramDEREncodable);
  }

  public DERTaggedObject(boolean paramBoolean, int paramInt, DEREncodable paramDEREncodable)
  {
    super(paramBoolean, paramInt, paramDEREncodable);
  }

  public DERTaggedObject(int paramInt)
  {
    super(false, paramInt, new DERSequence());
  }

  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    if (!this.empty)
    {
      byte[] arrayOfByte = this.obj.getDERObject().getEncoded("DER");
      if (this.explicit)
      {
        paramDEROutputStream.writeEncoded(160, this.tagNo, arrayOfByte);
      }
      else
      {
        int i;
        if ((arrayOfByte[0] & 0x20) != 0)
          i = 160;
        else
          i = 128;
        paramDEROutputStream.writeTag(i, this.tagNo);
        paramDEROutputStream.write(arrayOfByte, 1, arrayOfByte.length - 1);
      }
    }
    else
    {
      paramDEROutputStream.writeEncoded(160, this.tagNo, ZERO_BYTES);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DERTaggedObject
 * JD-Core Version:    0.6.0
 */