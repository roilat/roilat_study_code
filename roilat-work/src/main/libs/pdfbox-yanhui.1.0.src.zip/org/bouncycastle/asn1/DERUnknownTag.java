package org.bouncycastle.asn1;

import java.io.IOException;
import org.bouncycastle.util.Arrays;

public class DERUnknownTag extends DERObject
{
  private boolean isConstructed;
  private int tag;
  private byte[] data;

  public DERUnknownTag(int paramInt, byte[] paramArrayOfByte)
  {
    this(false, paramInt, paramArrayOfByte);
  }

  public DERUnknownTag(boolean paramBoolean, int paramInt, byte[] paramArrayOfByte)
  {
    this.isConstructed = paramBoolean;
    this.tag = paramInt;
    this.data = paramArrayOfByte;
  }

  public boolean isConstructed()
  {
    return this.isConstructed;
  }

  public int getTag()
  {
    return this.tag;
  }

  public byte[] getData()
  {
    return this.data;
  }

  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(this.isConstructed ? 32 : 0, this.tag, this.data);
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof DERUnknownTag))
      return false;
    DERUnknownTag localDERUnknownTag = (DERUnknownTag)paramObject;
    return (this.isConstructed == localDERUnknownTag.isConstructed) && (this.tag == localDERUnknownTag.tag) && (Arrays.areEqual(this.data, localDERUnknownTag.data));
  }

  public int hashCode()
  {
    return (this.isConstructed ? -1 : 0) ^ this.tag ^ Arrays.hashCode(this.data);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.DERUnknownTag
 * JD-Core Version:    0.6.0
 */