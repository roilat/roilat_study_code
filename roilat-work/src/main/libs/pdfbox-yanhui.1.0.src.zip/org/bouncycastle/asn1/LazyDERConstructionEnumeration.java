package org.bouncycastle.asn1;

import java.io.IOException;
import java.util.Enumeration;

class LazyDERConstructionEnumeration
  implements Enumeration
{
  private ASN1InputStream aIn;
  private Object nextObj;

  public LazyDERConstructionEnumeration(byte[] paramArrayOfByte)
  {
    this.aIn = new ASN1InputStream(paramArrayOfByte, true);
    this.nextObj = readObject();
  }

  public boolean hasMoreElements()
  {
    return this.nextObj != null;
  }

  public Object nextElement()
  {
    Object localObject = this.nextObj;
    this.nextObj = readObject();
    return localObject;
  }

  private Object readObject()
  {
    try
    {
      return this.aIn.readObject();
    }
    catch (IOException localIOException)
    {
    }
    throw new ASN1ParsingException("malformed DER construction: " + localIOException, localIOException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.LazyDERConstructionEnumeration
 * JD-Core Version:    0.6.0
 */