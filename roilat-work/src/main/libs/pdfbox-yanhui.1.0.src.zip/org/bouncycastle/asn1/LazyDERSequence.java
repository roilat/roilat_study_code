package org.bouncycastle.asn1;

import java.io.IOException;
import java.util.Enumeration;

public class LazyDERSequence extends DERSequence
{
  private byte[] encoded;
  private boolean parsed = false;
  private int size = -1;

  LazyDERSequence(byte[] paramArrayOfByte)
    throws IOException
  {
    this.encoded = paramArrayOfByte;
  }

  private void parse()
  {
    LazyDERConstructionEnumeration localLazyDERConstructionEnumeration = new LazyDERConstructionEnumeration(this.encoded);
    while (localLazyDERConstructionEnumeration.hasMoreElements())
      addObject((DEREncodable)localLazyDERConstructionEnumeration.nextElement());
    this.parsed = true;
  }

  public DEREncodable getObjectAt(int paramInt)
  {
    if (!this.parsed)
      parse();
    return super.getObjectAt(paramInt);
  }

  public Enumeration getObjects()
  {
    if (this.parsed)
      return super.getObjects();
    return new LazyDERConstructionEnumeration(this.encoded);
  }

  public int size()
  {
    if (this.size < 0)
    {
      LazyDERConstructionEnumeration localLazyDERConstructionEnumeration = new LazyDERConstructionEnumeration(this.encoded);
      this.size = 0;
      while (localLazyDERConstructionEnumeration.hasMoreElements())
      {
        localLazyDERConstructionEnumeration.nextElement();
        this.size += 1;
      }
    }
    return this.size;
  }

  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(48, this.encoded);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.LazyDERSequence
 * JD-Core Version:    0.6.0
 */