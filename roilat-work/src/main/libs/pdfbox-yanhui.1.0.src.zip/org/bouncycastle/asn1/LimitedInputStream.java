package org.bouncycastle.asn1;

import java.io.InputStream;

abstract class LimitedInputStream extends InputStream
{
  protected final InputStream _in;

  LimitedInputStream(InputStream paramInputStream)
  {
    this._in = paramInputStream;
  }

  protected void setParentEofDetect(boolean paramBoolean)
  {
    if ((this._in instanceof IndefiniteLengthInputStream))
      ((IndefiniteLengthInputStream)this._in).setEofOn00(paramBoolean);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.LimitedInputStream
 * JD-Core Version:    0.6.0
 */