package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class CAKeyUpdAnnContent extends ASN1Encodable
{
  private CMPCertificate oldWithNew;
  private CMPCertificate newWithOld;
  private CMPCertificate newWithNew;

  private CAKeyUpdAnnContent(ASN1Sequence paramASN1Sequence)
  {
    this.oldWithNew = CMPCertificate.getInstance(paramASN1Sequence.getObjectAt(0));
    this.newWithOld = CMPCertificate.getInstance(paramASN1Sequence.getObjectAt(1));
    this.newWithNew = CMPCertificate.getInstance(paramASN1Sequence.getObjectAt(2));
  }

  public static CAKeyUpdAnnContent getInstance(Object paramObject)
  {
    if ((paramObject instanceof CAKeyUpdAnnContent))
      return (CAKeyUpdAnnContent)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new CAKeyUpdAnnContent((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public CMPCertificate getOldWithNew()
  {
    return this.oldWithNew;
  }

  public CMPCertificate getNewWithOld()
  {
    return this.newWithOld;
  }

  public CMPCertificate getNewWithNew()
  {
    return this.newWithNew;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.oldWithNew);
    localASN1EncodableVector.add(this.newWithOld);
    localASN1EncodableVector.add(this.newWithNew);
    return new DERSequence(localASN1EncodableVector);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cmp.CAKeyUpdAnnContent
 * JD-Core Version:    0.6.0
 */