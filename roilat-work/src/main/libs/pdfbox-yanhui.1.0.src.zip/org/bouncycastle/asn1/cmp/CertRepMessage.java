package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;

public class CertRepMessage extends ASN1Encodable
{
  private ASN1Sequence caPubs;
  private ASN1Sequence response;

  private CertRepMessage(ASN1Sequence paramASN1Sequence)
  {
    int i = 0;
    if (paramASN1Sequence.size() > 1)
      this.caPubs = ASN1Sequence.getInstance((ASN1TaggedObject)paramASN1Sequence.getObjectAt(i++), true);
    this.response = ASN1Sequence.getInstance(paramASN1Sequence.getObjectAt(i));
  }

  public static CertRepMessage getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertRepMessage))
      return (CertRepMessage)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new CertRepMessage((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public CMPCertificate[] getCaPubs()
  {
    if (this.caPubs == null)
      return null;
    CMPCertificate[] arrayOfCMPCertificate = new CMPCertificate[this.caPubs.size()];
    for (int i = 0; i != arrayOfCMPCertificate.length; i++)
      arrayOfCMPCertificate[i] = CMPCertificate.getInstance(this.caPubs.getObjectAt(i));
    return arrayOfCMPCertificate;
  }

  public CertResponse[] getResponse()
  {
    CertResponse[] arrayOfCertResponse = new CertResponse[this.response.size()];
    for (int i = 0; i != arrayOfCertResponse.length; i++)
      arrayOfCertResponse[i] = CertResponse.getInstance(this.response.getObjectAt(i));
    return arrayOfCertResponse;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.caPubs != null)
      localASN1EncodableVector.add(new DERTaggedObject(true, 1, this.caPubs));
    localASN1EncodableVector.add(this.response);
    return new DERSequence(localASN1EncodableVector);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cmp.CertRepMessage
 * JD-Core Version:    0.6.0
 */