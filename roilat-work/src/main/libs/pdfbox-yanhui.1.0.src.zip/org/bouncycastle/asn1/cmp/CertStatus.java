package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class CertStatus extends ASN1Encodable
{
  private ASN1OctetString certHash;
  private DERInteger certReqId;
  private PKIStatusInfo statusInfo;

  private CertStatus(ASN1Sequence paramASN1Sequence)
  {
    this.certHash = ASN1OctetString.getInstance(paramASN1Sequence.getObjectAt(0));
    this.certReqId = DERInteger.getInstance(paramASN1Sequence.getObjectAt(1));
    if (paramASN1Sequence.size() > 2)
      this.statusInfo = PKIStatusInfo.getInstance(paramASN1Sequence.getObjectAt(2));
  }

  public static CertStatus getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertStatus))
      return (CertStatus)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new CertStatus((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public DERInteger getCertReqId()
  {
    return this.certReqId;
  }

  public PKIStatusInfo getStatusInfo()
  {
    return this.statusInfo;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.certHash);
    localASN1EncodableVector.add(this.certReqId);
    if (this.statusInfo != null)
      localASN1EncodableVector.add(this.statusInfo);
    return new DERSequence(localASN1EncodableVector);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cmp.CertStatus
 * JD-Core Version:    0.6.0
 */