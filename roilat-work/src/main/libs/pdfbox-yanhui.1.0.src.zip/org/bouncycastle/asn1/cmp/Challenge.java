package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class Challenge extends ASN1Encodable
{
  private AlgorithmIdentifier owf;
  private ASN1OctetString witness;
  private ASN1OctetString challenge;

  private Challenge(ASN1Sequence paramASN1Sequence)
  {
    int i = 0;
    if (paramASN1Sequence.size() == 3)
      this.owf = AlgorithmIdentifier.getInstance(paramASN1Sequence.getObjectAt(i++));
    this.witness = ASN1OctetString.getInstance(paramASN1Sequence.getObjectAt(i++));
    this.challenge = ASN1OctetString.getInstance(paramASN1Sequence.getObjectAt(i));
  }

  public static Challenge getInstance(Object paramObject)
  {
    if ((paramObject instanceof Challenge))
      return (Challenge)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new Challenge((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public AlgorithmIdentifier getOwf()
  {
    return this.owf;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    addOptional(localASN1EncodableVector, this.owf);
    localASN1EncodableVector.add(this.witness);
    localASN1EncodableVector.add(this.challenge);
    return new DERSequence(localASN1EncodableVector);
  }

  private void addOptional(ASN1EncodableVector paramASN1EncodableVector, ASN1Encodable paramASN1Encodable)
  {
    if (paramASN1Encodable != null)
      paramASN1EncodableVector.add(paramASN1Encodable);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cmp.Challenge
 * JD-Core Version:    0.6.0
 */