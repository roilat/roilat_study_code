package org.bouncycastle.asn1.cmp;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class ErrorMsgContent extends ASN1Encodable
{
  private PKIStatusInfo pKIStatusInfo;
  private DERInteger errorCode;
  private PKIFreeText errorDetails;

  private ErrorMsgContent(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.pKIStatusInfo = PKIStatusInfo.getInstance(localEnumeration.nextElement());
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if ((localObject instanceof DERInteger))
      {
        this.errorCode = DERInteger.getInstance(localObject);
        continue;
      }
      this.errorDetails = PKIFreeText.getInstance(localObject);
    }
  }

  public static ErrorMsgContent getInstance(Object paramObject)
  {
    if ((paramObject instanceof ErrorMsgContent))
      return (ErrorMsgContent)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new ErrorMsgContent((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public PKIStatusInfo getPKIStatusInfo()
  {
    return this.pKIStatusInfo;
  }

  public DERInteger getErrorCode()
  {
    return this.errorCode;
  }

  public PKIFreeText getErrorDetails()
  {
    return this.errorDetails;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.pKIStatusInfo);
    addOptional(localASN1EncodableVector, this.errorCode);
    addOptional(localASN1EncodableVector, this.errorDetails);
    return new DERSequence(localASN1EncodableVector);
  }

  private void addOptional(ASN1EncodableVector paramASN1EncodableVector, ASN1Encodable paramASN1Encodable)
  {
    if (paramASN1Encodable != null)
      paramASN1EncodableVector.add(paramASN1Encodable);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cmp.ErrorMsgContent
 * JD-Core Version:    0.6.0
 */