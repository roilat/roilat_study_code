package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.crmf.CertId;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class OOBCertHash extends ASN1Encodable
{
  private AlgorithmIdentifier hashAlg;
  private CertId certId;
  private DERBitString hashVal;

  private OOBCertHash(ASN1Sequence paramASN1Sequence)
  {
    int i = paramASN1Sequence.size() - 1;
    this.hashVal = DERBitString.getInstance(paramASN1Sequence.getObjectAt(i--));
    for (int j = i; j >= 0; j--)
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)paramASN1Sequence.getObjectAt(j);
      if (localASN1TaggedObject.getTagNo() == 0)
        this.hashAlg = AlgorithmIdentifier.getInstance(localASN1TaggedObject, true);
      else
        this.certId = CertId.getInstance(localASN1TaggedObject, true);
    }
  }

  public static OOBCertHash getInstance(Object paramObject)
  {
    if ((paramObject instanceof OOBCertHash))
      return (OOBCertHash)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new OOBCertHash((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public AlgorithmIdentifier getHashAlg()
  {
    return this.hashAlg;
  }

  public CertId getCertId()
  {
    return this.certId;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    addOptional(localASN1EncodableVector, 0, this.hashAlg);
    addOptional(localASN1EncodableVector, 1, this.certId);
    localASN1EncodableVector.add(this.hashVal);
    return new DERSequence(localASN1EncodableVector);
  }

  private void addOptional(ASN1EncodableVector paramASN1EncodableVector, int paramInt, ASN1Encodable paramASN1Encodable)
  {
    if (paramASN1Encodable != null)
      paramASN1EncodableVector.add(new DERTaggedObject(true, paramInt, paramASN1Encodable));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cmp.OOBCertHash
 * JD-Core Version:    0.6.0
 */