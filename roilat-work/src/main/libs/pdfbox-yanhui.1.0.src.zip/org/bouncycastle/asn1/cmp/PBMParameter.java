package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class PBMParameter extends ASN1Encodable
{
  private ASN1OctetString salt;
  private AlgorithmIdentifier owf;
  private DERInteger iterationCount;
  private AlgorithmIdentifier mac;

  private PBMParameter(ASN1Sequence paramASN1Sequence)
  {
    this.salt = ASN1OctetString.getInstance(paramASN1Sequence.getObjectAt(0));
    this.owf = AlgorithmIdentifier.getInstance(paramASN1Sequence.getObjectAt(1));
    this.iterationCount = DERInteger.getInstance(paramASN1Sequence.getObjectAt(2));
    this.mac = AlgorithmIdentifier.getInstance(paramASN1Sequence.getObjectAt(3));
  }

  public static PBMParameter getInstance(Object paramObject)
  {
    if ((paramObject instanceof PBMParameter))
      return (PBMParameter)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new PBMParameter((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public AlgorithmIdentifier getOwf()
  {
    return this.owf;
  }

  public DERInteger getIterationCount()
  {
    return this.iterationCount;
  }

  public AlgorithmIdentifier getMac()
  {
    return this.mac;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.salt);
    localASN1EncodableVector.add(this.owf);
    localASN1EncodableVector.add(this.iterationCount);
    localASN1EncodableVector.add(this.mac);
    return new DERSequence(localASN1EncodableVector);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cmp.PBMParameter
 * JD-Core Version:    0.6.0
 */