package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.crmf.CertReqMessages;
import org.bouncycastle.asn1.pkcs.CertificationRequest;

public class PKIBody extends ASN1Encodable
  implements ASN1Choice
{
  private int tagNo;
  private ASN1Encodable body;

  public static PKIBody getInstance(Object paramObject)
  {
    if ((paramObject instanceof PKIBody))
      return (PKIBody)paramObject;
    if ((paramObject instanceof ASN1TaggedObject))
      return new PKIBody((ASN1TaggedObject)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  private PKIBody(ASN1TaggedObject paramASN1TaggedObject)
  {
    this.tagNo = paramASN1TaggedObject.getTagNo();
    switch (paramASN1TaggedObject.getTagNo())
    {
    case 0:
      this.body = CertReqMessages.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 1:
      this.body = CertRepMessage.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 2:
      this.body = CertReqMessages.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 3:
      this.body = CertRepMessage.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 4:
      this.body = CertificationRequest.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 5:
      this.body = POPODecKeyChallContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 6:
      this.body = POPODecKeyRespContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 7:
      this.body = CertReqMessages.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 8:
      this.body = CertRepMessage.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 9:
      this.body = CertReqMessages.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 10:
      this.body = KeyRecRepContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 11:
      this.body = RevReqContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 12:
      this.body = RevRepContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 13:
      this.body = CertReqMessages.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 14:
      this.body = CertRepMessage.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 15:
      this.body = CAKeyUpdAnnContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 16:
      this.body = CMPCertificate.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 17:
      this.body = RevAnnContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 18:
      this.body = CRLAnnContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 19:
      this.body = PKIConfirmContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 20:
      this.body = PKIMessages.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 21:
      this.body = GenMsgContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 22:
      this.body = GenRepContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 23:
      this.body = ErrorMsgContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 24:
      this.body = CertConfirmContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 25:
      this.body = PollReqContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    case 26:
      this.body = PollRepContent.getInstance(paramASN1TaggedObject.getObject());
      break;
    default:
      throw new IllegalArgumentException("unknown tag number: " + paramASN1TaggedObject.getTagNo());
    }
  }

  public DERObject toASN1Object()
  {
    return new DERTaggedObject(true, this.tagNo, this.body);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cmp.PKIBody
 * JD-Core Version:    0.6.0
 */