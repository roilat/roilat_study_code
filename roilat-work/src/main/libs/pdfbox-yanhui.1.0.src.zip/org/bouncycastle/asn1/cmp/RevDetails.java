package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.crmf.CertTemplate;
import org.bouncycastle.asn1.x509.X509Extensions;

public class RevDetails extends ASN1Encodable
{
  private CertTemplate certDetails;
  private X509Extensions crlEntryDetails;

  private RevDetails(ASN1Sequence paramASN1Sequence)
  {
    this.certDetails = CertTemplate.getInstance(paramASN1Sequence.getObjectAt(0));
    if (paramASN1Sequence.size() > 1)
      this.crlEntryDetails = X509Extensions.getInstance(paramASN1Sequence.getObjectAt(1));
  }

  public static RevDetails getInstance(Object paramObject)
  {
    if ((paramObject instanceof RevDetails))
      return (RevDetails)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new RevDetails((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public CertTemplate getCertDetails()
  {
    return this.certDetails;
  }

  public X509Extensions getCrlEntryDetails()
  {
    return this.crlEntryDetails;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.certDetails);
    if (this.crlEntryDetails != null)
      localASN1EncodableVector.add(this.crlEntryDetails);
    return new DERSequence(localASN1EncodableVector);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cmp.RevDetails
 * JD-Core Version:    0.6.0
 */