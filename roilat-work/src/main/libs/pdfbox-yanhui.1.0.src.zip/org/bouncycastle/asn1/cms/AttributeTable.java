package org.bouncycastle.asn1.cms;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DEREncodableVector;
import org.bouncycastle.asn1.DERObjectIdentifier;

public class AttributeTable
{
  private Hashtable attributes = new Hashtable();

  public AttributeTable(Hashtable paramHashtable)
  {
    this.attributes = copyTable(paramHashtable);
  }

  public AttributeTable(DEREncodableVector paramDEREncodableVector)
  {
    for (int i = 0; i != paramDEREncodableVector.size(); i++)
    {
      Attribute localAttribute = Attribute.getInstance(paramDEREncodableVector.get(i));
      addAttribute(localAttribute.getAttrType(), localAttribute);
    }
  }

  public AttributeTable(ASN1Set paramASN1Set)
  {
    for (int i = 0; i != paramASN1Set.size(); i++)
    {
      Attribute localAttribute = Attribute.getInstance(paramASN1Set.getObjectAt(i));
      addAttribute(localAttribute.getAttrType(), localAttribute);
    }
  }

  private void addAttribute(DERObjectIdentifier paramDERObjectIdentifier, Attribute paramAttribute)
  {
    Object localObject = this.attributes.get(paramDERObjectIdentifier);
    if (localObject == null)
    {
      this.attributes.put(paramDERObjectIdentifier, paramAttribute);
    }
    else
    {
      Vector localVector;
      if ((localObject instanceof Attribute))
      {
        localVector = new Vector();
        localVector.addElement(localObject);
        localVector.addElement(paramAttribute);
      }
      else
      {
        localVector = (Vector)localObject;
        localVector.addElement(paramAttribute);
      }
      this.attributes.put(paramDERObjectIdentifier, localVector);
    }
  }

  public Attribute get(DERObjectIdentifier paramDERObjectIdentifier)
  {
    Object localObject = this.attributes.get(paramDERObjectIdentifier);
    if ((localObject instanceof Vector))
      return (Attribute)((Vector)localObject).elementAt(0);
    return (Attribute)localObject;
  }

  public ASN1EncodableVector getAll(DERObjectIdentifier paramDERObjectIdentifier)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Object localObject = this.attributes.get(paramDERObjectIdentifier);
    if ((localObject instanceof Vector))
    {
      Enumeration localEnumeration = ((Vector)localObject).elements();
      while (localEnumeration.hasMoreElements())
        localASN1EncodableVector.add((Attribute)localEnumeration.nextElement());
    }
    if (localObject != null)
      localASN1EncodableVector.add((Attribute)localObject);
    return localASN1EncodableVector;
  }

  public Hashtable toHashtable()
  {
    return copyTable(this.attributes);
  }

  public ASN1EncodableVector toASN1EncodableVector()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Enumeration localEnumeration1 = this.attributes.elements();
    while (localEnumeration1.hasMoreElements())
    {
      Object localObject = localEnumeration1.nextElement();
      if ((localObject instanceof Vector))
      {
        Enumeration localEnumeration2 = ((Vector)localObject).elements();
        while (localEnumeration2.hasMoreElements())
          localASN1EncodableVector.add(Attribute.getInstance(localEnumeration2.nextElement()));
        continue;
      }
      localASN1EncodableVector.add(Attribute.getInstance(localObject));
    }
    return localASN1EncodableVector;
  }

  private Hashtable copyTable(Hashtable paramHashtable)
  {
    Hashtable localHashtable = new Hashtable();
    Enumeration localEnumeration = paramHashtable.keys();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      localHashtable.put(localObject, paramHashtable.get(localObject));
    }
    return localHashtable;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cms.AttributeTable
 * JD-Core Version:    0.6.0
 */