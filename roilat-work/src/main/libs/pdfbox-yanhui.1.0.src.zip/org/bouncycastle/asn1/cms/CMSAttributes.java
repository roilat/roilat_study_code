package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;

public abstract interface CMSAttributes
{
  public static final DERObjectIdentifier contentType = PKCSObjectIdentifiers.pkcs_9_at_contentType;
  public static final DERObjectIdentifier messageDigest = PKCSObjectIdentifiers.pkcs_9_at_messageDigest;
  public static final DERObjectIdentifier signingTime = PKCSObjectIdentifiers.pkcs_9_at_signingTime;
  public static final DERObjectIdentifier counterSignature = PKCSObjectIdentifiers.pkcs_9_at_counterSignature;
  public static final DERObjectIdentifier contentHint = PKCSObjectIdentifiers.id_aa_contentHint;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cms.CMSAttributes
 * JD-Core Version:    0.6.0
 */