package org.bouncycastle.asn1.cms;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CompressedDataParser
{
  private DERInteger _version;
  private AlgorithmIdentifier _compressionAlgorithm;
  private ContentInfoParser _encapContentInfo;

  public CompressedDataParser(ASN1SequenceParser paramASN1SequenceParser)
    throws IOException
  {
    this._version = ((DERInteger)paramASN1SequenceParser.readObject());
    this._compressionAlgorithm = AlgorithmIdentifier.getInstance(paramASN1SequenceParser.readObject().getDERObject());
    this._encapContentInfo = new ContentInfoParser((ASN1SequenceParser)paramASN1SequenceParser.readObject());
  }

  public DERInteger getVersion()
  {
    return this._version;
  }

  public AlgorithmIdentifier getCompressionAlgorithmIdentifier()
  {
    return this._compressionAlgorithm;
  }

  public ContentInfoParser getEncapContentInfo()
  {
    return this._encapContentInfo;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cms.CompressedDataParser
 * JD-Core Version:    0.6.0
 */