package org.bouncycastle.asn1.crmf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;

public class CertReqMessages extends ASN1Encodable
{
  private ASN1Sequence content;

  private CertReqMessages(ASN1Sequence paramASN1Sequence)
  {
    this.content = paramASN1Sequence;
  }

  public static CertReqMessages getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertReqMessages))
      return (CertReqMessages)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new CertReqMessages((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public CertReqMsg[] toCertReqMsgArray()
  {
    CertReqMsg[] arrayOfCertReqMsg = new CertReqMsg[this.content.size()];
    for (int i = 0; i != arrayOfCertReqMsg.length; i++)
      arrayOfCertReqMsg[i] = CertReqMsg.getInstance(this.content.getObjectAt(i));
    return arrayOfCertReqMsg;
  }

  public DERObject toASN1Object()
  {
    return this.content;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.crmf.CertReqMessages
 * JD-Core Version:    0.6.0
 */