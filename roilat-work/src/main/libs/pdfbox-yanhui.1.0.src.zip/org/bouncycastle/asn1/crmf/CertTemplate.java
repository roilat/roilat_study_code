package org.bouncycastle.asn1.crmf;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509Name;

public class CertTemplate extends ASN1Encodable
{
  private DERInteger version;
  private DERInteger serialNumber;
  private AlgorithmIdentifier signingAlg;
  private X509Name issuer;
  private OptionalValidity validity;
  private X509Name subject;
  private SubjectPublicKeyInfo publicKey;
  private DERBitString issuerUID;
  private DERBitString subjectUID;
  private X509Extensions extensions;

  private CertTemplate(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    while (localEnumeration.hasMoreElements())
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)localEnumeration.nextElement();
      switch (localASN1TaggedObject.getTagNo())
      {
      case 0:
        this.version = DERInteger.getInstance(localASN1TaggedObject, false);
        break;
      case 1:
        this.serialNumber = DERInteger.getInstance(localASN1TaggedObject, false);
        break;
      case 2:
        this.signingAlg = AlgorithmIdentifier.getInstance(localASN1TaggedObject, false);
        break;
      case 3:
        this.issuer = X509Name.getInstance(localASN1TaggedObject, true);
        break;
      case 4:
        this.validity = OptionalValidity.getInstance(ASN1Sequence.getInstance(localASN1TaggedObject, false));
        break;
      case 5:
        this.subject = X509Name.getInstance(localASN1TaggedObject, true);
        break;
      case 6:
        this.publicKey = SubjectPublicKeyInfo.getInstance(localASN1TaggedObject, false);
        break;
      case 7:
        this.issuerUID = DERBitString.getInstance(localASN1TaggedObject, false);
        break;
      case 8:
        this.subjectUID = DERBitString.getInstance(localASN1TaggedObject, false);
        break;
      case 9:
        this.extensions = X509Extensions.getInstance(localASN1TaggedObject, false);
        break;
      default:
        throw new IllegalArgumentException("unknown tag: " + localASN1TaggedObject.getTagNo());
      }
    }
  }

  public static CertTemplate getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertTemplate))
      return (CertTemplate)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new CertTemplate((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    addOptional(localASN1EncodableVector, 0, false, this.version);
    addOptional(localASN1EncodableVector, 1, false, this.serialNumber);
    addOptional(localASN1EncodableVector, 2, false, this.signingAlg);
    addOptional(localASN1EncodableVector, 3, true, this.issuer);
    addOptional(localASN1EncodableVector, 4, false, this.validity);
    addOptional(localASN1EncodableVector, 5, true, this.subject);
    addOptional(localASN1EncodableVector, 6, false, this.publicKey);
    addOptional(localASN1EncodableVector, 7, false, this.issuerUID);
    addOptional(localASN1EncodableVector, 8, false, this.subjectUID);
    addOptional(localASN1EncodableVector, 9, false, this.extensions);
    return new DERSequence(localASN1EncodableVector);
  }

  private void addOptional(ASN1EncodableVector paramASN1EncodableVector, int paramInt, boolean paramBoolean, ASN1Encodable paramASN1Encodable)
  {
    if (paramASN1Encodable != null)
      paramASN1EncodableVector.add(new DERTaggedObject(paramBoolean, paramInt, paramASN1Encodable));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.crmf.CertTemplate
 * JD-Core Version:    0.6.0
 */