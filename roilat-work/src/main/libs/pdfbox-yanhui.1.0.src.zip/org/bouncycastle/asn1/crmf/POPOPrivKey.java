package org.bouncycastle.asn1.crmf;

import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;

public class POPOPrivKey extends ASN1Encodable
  implements ASN1Choice
{
  private DERObject obj;

  private POPOPrivKey(DERObject paramDERObject)
  {
    this.obj = paramDERObject;
  }

  public static ASN1Encodable getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return new POPOPrivKey(paramASN1TaggedObject.getObject());
  }

  public DERObject toASN1Object()
  {
    return this.obj;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.crmf.POPOPrivKey
 * JD-Core Version:    0.6.0
 */