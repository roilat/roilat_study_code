package org.bouncycastle.asn1.crmf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;

public class POPOSigningKeyInput extends ASN1Encodable
{
  private ASN1Encodable authInfo;
  private SubjectPublicKeyInfo publicKey;

  private POPOSigningKeyInput(ASN1Sequence paramASN1Sequence)
  {
    this.authInfo = ((ASN1Encodable)paramASN1Sequence.getObjectAt(0));
    this.publicKey = SubjectPublicKeyInfo.getInstance(paramASN1Sequence.getObjectAt(1));
  }

  public static POPOSigningKeyInput getInstance(Object paramObject)
  {
    if ((paramObject instanceof POPOSigningKeyInput))
      return (POPOSigningKeyInput)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new POPOSigningKeyInput((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }

  public SubjectPublicKeyInfo getPublicKey()
  {
    return this.publicKey;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.authInfo);
    localASN1EncodableVector.add(this.publicKey);
    return new DERSequence(localASN1EncodableVector);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.crmf.POPOSigningKeyInput
 * JD-Core Version:    0.6.0
 */