package org.bouncycastle.asn1.cryptopro;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class GOST3410PublicKeyAlgParameters extends ASN1Encodable
{
  private DERObjectIdentifier publicKeyParamSet;
  private DERObjectIdentifier digestParamSet;
  private DERObjectIdentifier encryptionParamSet;

  public static GOST3410PublicKeyAlgParameters getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }

  public static GOST3410PublicKeyAlgParameters getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof GOST3410PublicKeyAlgParameters)))
      return (GOST3410PublicKeyAlgParameters)paramObject;
    if ((paramObject instanceof ASN1Sequence))
      return new GOST3410PublicKeyAlgParameters((ASN1Sequence)paramObject);
    throw new IllegalArgumentException("Invalid GOST3410Parameter: " + paramObject.getClass().getName());
  }

  public GOST3410PublicKeyAlgParameters(DERObjectIdentifier paramDERObjectIdentifier1, DERObjectIdentifier paramDERObjectIdentifier2)
  {
    this.publicKeyParamSet = paramDERObjectIdentifier1;
    this.digestParamSet = paramDERObjectIdentifier2;
    this.encryptionParamSet = null;
  }

  public GOST3410PublicKeyAlgParameters(DERObjectIdentifier paramDERObjectIdentifier1, DERObjectIdentifier paramDERObjectIdentifier2, DERObjectIdentifier paramDERObjectIdentifier3)
  {
    this.publicKeyParamSet = paramDERObjectIdentifier1;
    this.digestParamSet = paramDERObjectIdentifier2;
    this.encryptionParamSet = paramDERObjectIdentifier3;
  }

  public GOST3410PublicKeyAlgParameters(ASN1Sequence paramASN1Sequence)
  {
    this.publicKeyParamSet = ((DERObjectIdentifier)paramASN1Sequence.getObjectAt(0));
    this.digestParamSet = ((DERObjectIdentifier)paramASN1Sequence.getObjectAt(1));
    if (paramASN1Sequence.size() > 2)
      this.encryptionParamSet = ((DERObjectIdentifier)paramASN1Sequence.getObjectAt(2));
  }

  public DERObjectIdentifier getPublicKeyParamSet()
  {
    return this.publicKeyParamSet;
  }

  public DERObjectIdentifier getDigestParamSet()
  {
    return this.digestParamSet;
  }

  public DERObjectIdentifier getEncryptionParamSet()
  {
    return this.encryptionParamSet;
  }

  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.publicKeyParamSet);
    localASN1EncodableVector.add(this.digestParamSet);
    if (this.encryptionParamSet != null)
      localASN1EncodableVector.add(this.encryptionParamSet);
    return new DERSequence(localASN1EncodableVector);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.asn1.cryptopro.GOST3410PublicKeyAlgParameters
 * JD-Core Version:    0.6.0
 */