package org.bouncycastle.cert;

import java.io.OutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEREnumerated;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.Holder;
import org.bouncycastle.asn1.x509.IssuerSerial;
import org.bouncycastle.asn1.x509.ObjectDigestInfo;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.Selector;

public class AttributeCertificateHolder
  implements Selector
{
  private static DigestCalculatorProvider digestCalculatorProvider;
  final Holder holder;

  AttributeCertificateHolder(ASN1Sequence paramASN1Sequence)
  {
    this.holder = Holder.getInstance(paramASN1Sequence);
  }

  public AttributeCertificateHolder(X500Name paramX500Name, BigInteger paramBigInteger)
  {
    this.holder = new Holder(new IssuerSerial(new GeneralNames(new DERSequence(new GeneralName(paramX500Name))), new DERInteger(paramBigInteger)));
  }

  public AttributeCertificateHolder(X509CertificateHolder paramX509CertificateHolder)
  {
    this.holder = new Holder(new IssuerSerial(generateGeneralNames(paramX509CertificateHolder.getIssuer()), new DERInteger(paramX509CertificateHolder.getSerialNumber())));
  }

  public AttributeCertificateHolder(X500Name paramX500Name)
  {
    this.holder = new Holder(generateGeneralNames(paramX500Name));
  }

  public AttributeCertificateHolder(int paramInt, String paramString1, String paramString2, byte[] paramArrayOfByte)
  {
    this.holder = new Holder(new ObjectDigestInfo(paramInt, paramString2, new AlgorithmIdentifier(paramString1), Arrays.clone(paramArrayOfByte)));
  }

  public int getDigestedObjectType()
  {
    if (this.holder.getObjectDigestInfo() != null)
      return this.holder.getObjectDigestInfo().getDigestedObjectType().getValue().intValue();
    return -1;
  }

  public AlgorithmIdentifier getDigestAlgorithm()
  {
    if (this.holder.getObjectDigestInfo() != null)
      return this.holder.getObjectDigestInfo().getDigestAlgorithm();
    return null;
  }

  public byte[] getObjectDigest()
  {
    if (this.holder.getObjectDigestInfo() != null)
      return this.holder.getObjectDigestInfo().getObjectDigest().getBytes();
    return null;
  }

  public ASN1ObjectIdentifier getOtherObjectTypeID()
  {
    if (this.holder.getObjectDigestInfo() != null)
      new ASN1ObjectIdentifier(this.holder.getObjectDigestInfo().getOtherObjectTypeID().getId());
    return null;
  }

  private GeneralNames generateGeneralNames(X500Name paramX500Name)
  {
    return new GeneralNames(new DERSequence(new GeneralName(paramX500Name)));
  }

  private boolean matchesDN(X500Name paramX500Name, GeneralNames paramGeneralNames)
  {
    GeneralName[] arrayOfGeneralName = paramGeneralNames.getNames();
    for (int i = 0; i != arrayOfGeneralName.length; i++)
    {
      GeneralName localGeneralName = arrayOfGeneralName[i];
      if ((localGeneralName.getTagNo() == 4) && (X500Name.getInstance(localGeneralName.getName()).equals(paramX500Name)))
        return true;
    }
    return false;
  }

  private X500Name[] getPrincipals(GeneralName[] paramArrayOfGeneralName)
  {
    ArrayList localArrayList = new ArrayList(paramArrayOfGeneralName.length);
    for (int i = 0; i != paramArrayOfGeneralName.length; i++)
    {
      if (paramArrayOfGeneralName[i].getTagNo() != 4)
        continue;
      localArrayList.add(X500Name.getInstance(paramArrayOfGeneralName[i].getName()));
    }
    return (X500Name[])(X500Name[])localArrayList.toArray(new X500Name[localArrayList.size()]);
  }

  public X500Name[] getEntityNames()
  {
    if (this.holder.getEntityName() != null)
      return getPrincipals(this.holder.getEntityName().getNames());
    return null;
  }

  public X500Name[] getIssuer()
  {
    if (this.holder.getBaseCertificateID() != null)
      return getPrincipals(this.holder.getBaseCertificateID().getIssuer().getNames());
    return null;
  }

  public BigInteger getSerialNumber()
  {
    if (this.holder.getBaseCertificateID() != null)
      return this.holder.getBaseCertificateID().getSerial().getValue();
    return null;
  }

  public Object clone()
  {
    return new AttributeCertificateHolder((ASN1Sequence)this.holder.toASN1Object());
  }

  public boolean match(Object paramObject)
  {
    if (!(paramObject instanceof X509CertificateHolder))
      return false;
    X509CertificateHolder localX509CertificateHolder = (X509CertificateHolder)paramObject;
    if (this.holder.getBaseCertificateID() != null)
      return (this.holder.getBaseCertificateID().getSerial().getValue().equals(localX509CertificateHolder.getSerialNumber())) && (matchesDN(localX509CertificateHolder.getIssuer(), this.holder.getBaseCertificateID().getIssuer()));
    if ((this.holder.getEntityName() != null) && (matchesDN(localX509CertificateHolder.getSubject(), this.holder.getEntityName())))
      return true;
    if (this.holder.getObjectDigestInfo() != null)
      try
      {
        DigestCalculator localDigestCalculator = digestCalculatorProvider.get(this.holder.getObjectDigestInfo().getDigestAlgorithm());
        OutputStream localOutputStream = localDigestCalculator.getOutputStream();
        switch (getDigestedObjectType())
        {
        case 0:
          localOutputStream.write(localX509CertificateHolder.getSubjectPublicKeyInfo().getEncoded());
          break;
        case 1:
          localOutputStream.write(localX509CertificateHolder.getEncoded());
        }
        localOutputStream.close();
        if (!Arrays.areEqual(localDigestCalculator.getDigest(), getObjectDigest()))
          return false;
      }
      catch (Exception localException)
      {
        return false;
      }
    return false;
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof AttributeCertificateHolder))
      return false;
    AttributeCertificateHolder localAttributeCertificateHolder = (AttributeCertificateHolder)paramObject;
    return this.holder.equals(localAttributeCertificateHolder.holder);
  }

  public int hashCode()
  {
    return this.holder.hashCode();
  }

  public static void setDigestCalculatorProvider(DigestCalculatorProvider paramDigestCalculatorProvider)
  {
    digestCalculatorProvider = paramDigestCalculatorProvider;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.AttributeCertificateHolder
 * JD-Core Version:    0.6.0
 */