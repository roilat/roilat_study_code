package org.bouncycastle.cert;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AttCertIssuer;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.IssuerSerial;
import org.bouncycastle.asn1.x509.V2Form;
import org.bouncycastle.util.Selector;

public class AttributeCertificateIssuer
  implements Selector
{
  final ASN1Encodable form;

  public AttributeCertificateIssuer(AttCertIssuer paramAttCertIssuer)
  {
    this.form = paramAttCertIssuer.getIssuer();
  }

  public AttributeCertificateIssuer(X500Name paramX500Name)
  {
    this.form = new V2Form(new GeneralNames(new DERSequence(new GeneralName(paramX500Name))));
  }

  public X500Name[] getNames()
  {
    GeneralNames localGeneralNames;
    if ((this.form instanceof V2Form))
      localGeneralNames = ((V2Form)this.form).getIssuerName();
    else
      localGeneralNames = (GeneralNames)this.form;
    GeneralName[] arrayOfGeneralName = localGeneralNames.getNames();
    ArrayList localArrayList = new ArrayList(arrayOfGeneralName.length);
    for (int i = 0; i != arrayOfGeneralName.length; i++)
    {
      if (arrayOfGeneralName[i].getTagNo() != 4)
        continue;
      localArrayList.add(X500Name.getInstance(arrayOfGeneralName[i].getName()));
    }
    return (X500Name[])(X500Name[])localArrayList.toArray(new X500Name[localArrayList.size()]);
  }

  private boolean matchesDN(X500Name paramX500Name, GeneralNames paramGeneralNames)
  {
    GeneralName[] arrayOfGeneralName = paramGeneralNames.getNames();
    for (int i = 0; i != arrayOfGeneralName.length; i++)
    {
      GeneralName localGeneralName = arrayOfGeneralName[i];
      if ((localGeneralName.getTagNo() == 4) && (X500Name.getInstance(localGeneralName.getName()).equals(paramX500Name)))
        return true;
    }
    return false;
  }

  public Object clone()
  {
    return new AttributeCertificateIssuer(AttCertIssuer.getInstance(this.form));
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof AttributeCertificateIssuer))
      return false;
    AttributeCertificateIssuer localAttributeCertificateIssuer = (AttributeCertificateIssuer)paramObject;
    return this.form.equals(localAttributeCertificateIssuer.form);
  }

  public int hashCode()
  {
    return this.form.hashCode();
  }

  public boolean match(Object paramObject)
  {
    if (!(paramObject instanceof X509CertificateHolder))
      return false;
    X509CertificateHolder localX509CertificateHolder = (X509CertificateHolder)paramObject;
    Object localObject;
    if ((this.form instanceof V2Form))
    {
      localObject = (V2Form)this.form;
      if (((V2Form)localObject).getBaseCertificateID() != null)
        return (((V2Form)localObject).getBaseCertificateID().getSerial().getValue().equals(localX509CertificateHolder.getSerialNumber())) && (matchesDN(localX509CertificateHolder.getIssuer(), ((V2Form)localObject).getBaseCertificateID().getIssuer()));
      GeneralNames localGeneralNames = ((V2Form)localObject).getIssuerName();
      if (matchesDN(localX509CertificateHolder.getSubject(), localGeneralNames))
        return true;
    }
    else
    {
      localObject = (GeneralNames)this.form;
      if (matchesDN(localX509CertificateHolder.getSubject(), (GeneralNames)localObject))
        return true;
    }
    return false;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.AttributeCertificateIssuer
 * JD-Core Version:    0.6.0
 */