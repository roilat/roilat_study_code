package org.bouncycastle.cert;

import java.io.IOException;

public class CertIOException extends IOException
{
  private Throwable cause;

  public CertIOException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    this.cause = paramThrowable;
  }

  public CertIOException(String paramString)
  {
    super(paramString);
  }

  public Throwable getCause()
  {
    return this.cause;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.CertIOException
 * JD-Core Version:    0.6.0
 */