package org.bouncycastle.cert;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.AttCertValidityPeriod;
import org.bouncycastle.asn1.x509.Attribute;
import org.bouncycastle.asn1.x509.AttributeCertificate;
import org.bouncycastle.asn1.x509.AttributeCertificateInfo;
import org.bouncycastle.asn1.x509.Holder;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;

public class X509AttributeCertificateHolder
{
  private static Attribute[] EMPTY_ARRAY = new Attribute[0];
  private AttributeCertificate attrCert;
  private X509Extensions extensions;

  private static AttributeCertificate parseBytes(byte[] paramArrayOfByte)
    throws IOException
  {
    try
    {
      return AttributeCertificate.getInstance(ASN1Object.fromByteArray(paramArrayOfByte));
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CertIOException("malformed data: " + localClassCastException.getMessage(), localClassCastException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    throw new CertIOException("malformed data: " + localIllegalArgumentException.getMessage(), localIllegalArgumentException);
  }

  public X509AttributeCertificateHolder(byte[] paramArrayOfByte)
    throws IOException
  {
    this(parseBytes(paramArrayOfByte));
  }

  public X509AttributeCertificateHolder(AttributeCertificate paramAttributeCertificate)
  {
    this.attrCert = paramAttributeCertificate;
    this.extensions = paramAttributeCertificate.getAcinfo().getExtensions();
  }

  public byte[] getEncoded()
    throws IOException
  {
    return this.attrCert.getEncoded();
  }

  public int getVersion()
  {
    return this.attrCert.getAcinfo().getVersion().getValue().intValue() + 1;
  }

  public BigInteger getSerialNumber()
  {
    return this.attrCert.getAcinfo().getSerialNumber().getValue();
  }

  public AttributeCertificateHolder getHolder()
  {
    return new AttributeCertificateHolder((ASN1Sequence)this.attrCert.getAcinfo().getHolder().toASN1Object());
  }

  public AttributeCertificateIssuer getIssuer()
  {
    return new AttributeCertificateIssuer(this.attrCert.getAcinfo().getIssuer());
  }

  public Date getNotBefore()
  {
    return CertUtils.recoverDate(this.attrCert.getAcinfo().getAttrCertValidityPeriod().getNotBeforeTime());
  }

  public Date getNotAfter()
  {
    return CertUtils.recoverDate(this.attrCert.getAcinfo().getAttrCertValidityPeriod().getNotAfterTime());
  }

  public Attribute[] getAttributes()
  {
    ASN1Sequence localASN1Sequence = this.attrCert.getAcinfo().getAttributes();
    Attribute[] arrayOfAttribute = new Attribute[localASN1Sequence.size()];
    for (int i = 0; i != localASN1Sequence.size(); i++)
      arrayOfAttribute[i] = Attribute.getInstance(localASN1Sequence.getObjectAt(i));
    return arrayOfAttribute;
  }

  public Attribute[] getAttributes(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    ASN1Sequence localASN1Sequence = this.attrCert.getAcinfo().getAttributes();
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i != localASN1Sequence.size(); i++)
    {
      Attribute localAttribute = Attribute.getInstance(localASN1Sequence.getObjectAt(i));
      if (!localAttribute.getAttrType().equals(paramASN1ObjectIdentifier))
        continue;
      localArrayList.add(localAttribute);
    }
    if (localArrayList.size() == 0)
      return EMPTY_ARRAY;
    return (Attribute[])(Attribute[])localArrayList.toArray(new Attribute[localArrayList.size()]);
  }

  public boolean hasExtensions()
  {
    return this.extensions != null;
  }

  public X509Extension getExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    if (this.extensions != null)
      return this.extensions.getExtension(paramASN1ObjectIdentifier);
    return null;
  }

  public List getExtensionOIDs()
  {
    return CertUtils.getExtensionOIDs(this.extensions);
  }

  public Set getCriticalExtensionOIDs()
  {
    return CertUtils.getCriticalExtensionOIDs(this.extensions);
  }

  public Set getNonCriticalExtensionOIDs()
  {
    return CertUtils.getNonCriticalExtensionOIDs(this.extensions);
  }

  public boolean[] getIssuerUniqueID()
  {
    return CertUtils.bitStringToBoolean(this.attrCert.getAcinfo().getIssuerUniqueID());
  }

  public AlgorithmIdentifier getSignatureAlgorithm()
  {
    return this.attrCert.getSignatureAlgorithm();
  }

  public byte[] getSignature()
  {
    return this.attrCert.getSignatureValue().getBytes();
  }

  public AttributeCertificate toASN1Structure()
  {
    return this.attrCert;
  }

  public boolean isValidOn(Date paramDate)
  {
    AttCertValidityPeriod localAttCertValidityPeriod = this.attrCert.getAcinfo().getAttrCertValidityPeriod();
    return (!paramDate.before(CertUtils.recoverDate(localAttCertValidityPeriod.getNotBeforeTime()))) && (!paramDate.after(CertUtils.recoverDate(localAttCertValidityPeriod.getNotAfterTime())));
  }

  public boolean isSignatureValid(ContentVerifierProvider paramContentVerifierProvider)
    throws CertException
  {
    AttributeCertificateInfo localAttributeCertificateInfo = this.attrCert.getAcinfo();
    if (!localAttributeCertificateInfo.getSignature().equals(this.attrCert.getSignatureAlgorithm()))
      throw new CertException("signature invalid - algorithm identifier mismatch");
    ContentVerifier localContentVerifier;
    try
    {
      localContentVerifier = paramContentVerifierProvider.get(localAttributeCertificateInfo.getSignature());
      OutputStream localOutputStream = localContentVerifier.getOutputStream();
      localOutputStream.write(localAttributeCertificateInfo.getDEREncoded());
      localOutputStream.close();
    }
    catch (Exception localException)
    {
      throw new CertException("unable to process signature: " + localException.getMessage(), localException);
    }
    return localContentVerifier.verify(this.attrCert.getSignatureValue().getBytes());
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof X509AttributeCertificateHolder))
      return false;
    X509AttributeCertificateHolder localX509AttributeCertificateHolder = (X509AttributeCertificateHolder)paramObject;
    return this.attrCert.equals(localX509AttributeCertificateHolder.attrCert);
  }

  public int hashCode()
  {
    return this.attrCert.hashCode();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.X509AttributeCertificateHolder
 * JD-Core Version:    0.6.0
 */