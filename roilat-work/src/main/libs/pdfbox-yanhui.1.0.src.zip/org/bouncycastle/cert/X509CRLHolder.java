package org.bouncycastle.cert;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.List;
import java.util.Set;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.CertificateList;
import org.bouncycastle.asn1.x509.TBSCertList;
import org.bouncycastle.asn1.x509.TBSCertList.CRLEntry;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;

public class X509CRLHolder
{
  private CertificateList x509CRL;
  private X509Extensions extensions;

  private static CertificateList parseBytes(byte[] paramArrayOfByte)
    throws IOException
  {
    try
    {
      return CertificateList.getInstance(ASN1Object.fromByteArray(paramArrayOfByte));
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CertIOException("malformed data: " + localClassCastException.getMessage(), localClassCastException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    throw new CertIOException("malformed data: " + localIllegalArgumentException.getMessage(), localIllegalArgumentException);
  }

  public X509CRLHolder(byte[] paramArrayOfByte)
    throws IOException
  {
    this(parseBytes(paramArrayOfByte));
  }

  public X509CRLHolder(CertificateList paramCertificateList)
  {
    this.x509CRL = paramCertificateList;
    this.extensions = paramCertificateList.getTBSCertList().getExtensions();
  }

  public byte[] getEncoded()
    throws IOException
  {
    return this.x509CRL.getEncoded();
  }

  public X500Name getIssuer()
  {
    return X500Name.getInstance(this.x509CRL.getIssuer());
  }

  public X509CRLEntryHolder getRevokedCertificate(BigInteger paramBigInteger)
  {
    Enumeration localEnumeration = this.x509CRL.getRevokedCertificateEnumeration();
    while (localEnumeration.hasMoreElements())
    {
      TBSCertList.CRLEntry localCRLEntry = (TBSCertList.CRLEntry)localEnumeration.nextElement();
      if (localCRLEntry.getUserCertificate().getValue().equals(paramBigInteger))
        return new X509CRLEntryHolder(localCRLEntry);
    }
    return null;
  }

  public Collection getRevokedCertificates()
  {
    TBSCertList.CRLEntry[] arrayOfCRLEntry = this.x509CRL.getRevokedCertificates();
    ArrayList localArrayList = new ArrayList(arrayOfCRLEntry.length);
    Enumeration localEnumeration = this.x509CRL.getRevokedCertificateEnumeration();
    while (localEnumeration.hasMoreElements())
    {
      TBSCertList.CRLEntry localCRLEntry = (TBSCertList.CRLEntry)localEnumeration.nextElement();
      localArrayList.add(new X509CRLEntryHolder(localCRLEntry));
    }
    return localArrayList;
  }

  public boolean hasExtensions()
  {
    return this.extensions != null;
  }

  public X509Extension getExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    if (this.extensions != null)
      return this.extensions.getExtension(paramASN1ObjectIdentifier);
    return null;
  }

  public List getExtensionOIDs()
  {
    return CertUtils.getExtensionOIDs(this.extensions);
  }

  public Set getCriticalExtensionOIDs()
  {
    return CertUtils.getCriticalExtensionOIDs(this.extensions);
  }

  public Set getNonCriticalExtensionOIDs()
  {
    return CertUtils.getNonCriticalExtensionOIDs(this.extensions);
  }

  public CertificateList toASN1Structure()
  {
    return this.x509CRL;
  }

  public boolean isSignatureValid(ContentVerifierProvider paramContentVerifierProvider)
    throws CertException
  {
    TBSCertList localTBSCertList = this.x509CRL.getTBSCertList();
    if (!localTBSCertList.getSignature().equals(this.x509CRL.getSignatureAlgorithm()))
      throw new CertException("signature invalid - algorithm identifier mismatch");
    ContentVerifier localContentVerifier;
    try
    {
      localContentVerifier = paramContentVerifierProvider.get(localTBSCertList.getSignature());
      OutputStream localOutputStream = localContentVerifier.getOutputStream();
      localOutputStream.write(localTBSCertList.getDEREncoded());
      localOutputStream.close();
    }
    catch (Exception localException)
    {
      throw new CertException("unable to process signature: " + localException.getMessage(), localException);
    }
    return localContentVerifier.verify(this.x509CRL.getSignature().getBytes());
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof X509CRLHolder))
      return false;
    X509CRLHolder localX509CRLHolder = (X509CRLHolder)paramObject;
    return this.x509CRL.equals(localX509CRLHolder.x509CRL);
  }

  public int hashCode()
  {
    return this.x509CRL.hashCode();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.X509CRLHolder
 * JD-Core Version:    0.6.0
 */