package org.bouncycastle.cert;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;
import org.bouncycastle.asn1.x509.Time;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;

public class X509CertificateHolder
{
  private X509CertificateStructure x509Certificate;
  private X509Extensions extensions;

  private static X509CertificateStructure parseBytes(byte[] paramArrayOfByte)
    throws IOException
  {
    try
    {
      return X509CertificateStructure.getInstance(ASN1Object.fromByteArray(paramArrayOfByte));
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CertIOException("malformed data: " + localClassCastException.getMessage(), localClassCastException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    throw new CertIOException("malformed data: " + localIllegalArgumentException.getMessage(), localIllegalArgumentException);
  }

  public X509CertificateHolder(byte[] paramArrayOfByte)
    throws IOException
  {
    this(parseBytes(paramArrayOfByte));
  }

  public X509CertificateHolder(X509CertificateStructure paramX509CertificateStructure)
  {
    this.x509Certificate = paramX509CertificateStructure;
    this.extensions = paramX509CertificateStructure.getTBSCertificate().getExtensions();
  }

  public int getVersion()
  {
    return this.x509Certificate.getVersion();
  }

  public boolean hasExtensions()
  {
    return this.extensions != null;
  }

  public X509Extension getExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    if (this.extensions != null)
      return this.extensions.getExtension(paramASN1ObjectIdentifier);
    return null;
  }

  public List getExtensionOIDs()
  {
    return CertUtils.getExtensionOIDs(this.extensions);
  }

  public Set getCriticalExtensionOIDs()
  {
    return CertUtils.getCriticalExtensionOIDs(this.extensions);
  }

  public Set getNonCriticalExtensionOIDs()
  {
    return CertUtils.getNonCriticalExtensionOIDs(this.extensions);
  }

  public IssuerAndSerialNumber getIssuerAndSerialNumber()
  {
    return new IssuerAndSerialNumber(this.x509Certificate.getIssuer(), this.x509Certificate.getSerialNumber());
  }

  public BigInteger getSerialNumber()
  {
    return this.x509Certificate.getSerialNumber().getValue();
  }

  public X500Name getIssuer()
  {
    return X500Name.getInstance(this.x509Certificate.getIssuer());
  }

  public X500Name getSubject()
  {
    return X500Name.getInstance(this.x509Certificate.getSubject());
  }

  public Date getNotBefore()
  {
    return this.x509Certificate.getStartDate().getDate();
  }

  public Date getNotAfter()
  {
    return this.x509Certificate.getEndDate().getDate();
  }

  public SubjectPublicKeyInfo getSubjectPublicKeyInfo()
  {
    return this.x509Certificate.getSubjectPublicKeyInfo();
  }

  public X509CertificateStructure toASN1Structure()
  {
    return this.x509Certificate;
  }

  public AlgorithmIdentifier getSignatureAlgorithm()
  {
    return this.x509Certificate.getSignatureAlgorithm();
  }

  public byte[] getSignature()
  {
    return this.x509Certificate.getSignature().getBytes();
  }

  public boolean isValidOn(Date paramDate)
  {
    return (!paramDate.before(this.x509Certificate.getStartDate().getDate())) && (!paramDate.after(this.x509Certificate.getEndDate().getDate()));
  }

  public boolean isSignatureValid(ContentVerifierProvider paramContentVerifierProvider)
    throws CertException
  {
    TBSCertificateStructure localTBSCertificateStructure = this.x509Certificate.getTBSCertificate();
    if (!localTBSCertificateStructure.getSignature().equals(this.x509Certificate.getSignatureAlgorithm()))
      throw new CertException("signature invalid - algorithm identifier mismatch");
    ContentVerifier localContentVerifier;
    try
    {
      localContentVerifier = paramContentVerifierProvider.get(localTBSCertificateStructure.getSignature());
      OutputStream localOutputStream = localContentVerifier.getOutputStream();
      localOutputStream.write(localTBSCertificateStructure.getDEREncoded());
      localOutputStream.close();
    }
    catch (Exception localException)
    {
      throw new CertException("unable to process signature: " + localException.getMessage(), localException);
    }
    return localContentVerifier.verify(this.x509Certificate.getSignature().getBytes());
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof X509CertificateHolder))
      return false;
    X509CertificateHolder localX509CertificateHolder = (X509CertificateHolder)paramObject;
    return this.x509Certificate.equals(localX509CertificateHolder.x509Certificate);
  }

  public int hashCode()
  {
    return this.x509Certificate.hashCode();
  }

  public byte[] getEncoded()
    throws IOException
  {
    return this.x509Certificate.getEncoded();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.X509CertificateHolder
 * JD-Core Version:    0.6.0
 */