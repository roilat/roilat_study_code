package org.bouncycastle.cert;

import java.math.BigInteger;
import java.util.Date;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.CertificateList;
import org.bouncycastle.asn1.x509.TBSCertList;
import org.bouncycastle.asn1.x509.Time;
import org.bouncycastle.asn1.x509.V2TBSCertListGenerator;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509ExtensionsGenerator;
import org.bouncycastle.operator.ContentSigner;

public class X509v2CRLBuilder
{
  private V2TBSCertListGenerator tbsGen = new V2TBSCertListGenerator();
  private X509ExtensionsGenerator extGenerator = new X509ExtensionsGenerator();

  public X509v2CRLBuilder(X500Name paramX500Name, Date paramDate)
  {
    this.tbsGen.setIssuer(paramX500Name);
    this.tbsGen.setThisUpdate(new Time(paramDate));
  }

  public X509v2CRLBuilder setNextUpdate(Date paramDate)
  {
    this.tbsGen.setNextUpdate(new Time(paramDate));
    return this;
  }

  public X509v2CRLBuilder addCRLEntry(BigInteger paramBigInteger, Date paramDate, int paramInt)
  {
    this.tbsGen.addCRLEntry(new DERInteger(paramBigInteger), new Time(paramDate), paramInt);
    return this;
  }

  public X509v2CRLBuilder addCRLEntry(BigInteger paramBigInteger, Date paramDate1, int paramInt, Date paramDate2)
  {
    this.tbsGen.addCRLEntry(new DERInteger(paramBigInteger), new Time(paramDate1), paramInt, new DERGeneralizedTime(paramDate2));
    return this;
  }

  public X509v2CRLBuilder addCRLEntry(BigInteger paramBigInteger, Date paramDate, X509Extensions paramX509Extensions)
  {
    this.tbsGen.addCRLEntry(new DERInteger(paramBigInteger), new Time(paramDate), paramX509Extensions);
    return this;
  }

  public X509v2CRLBuilder addCRL(X509CRLHolder paramX509CRLHolder)
  {
    TBSCertList localTBSCertList = paramX509CRLHolder.toASN1Structure().getTBSCertList();
    if (localTBSCertList != null)
    {
      Enumeration localEnumeration = localTBSCertList.getRevokedCertificateEnumeration();
      while (localEnumeration.hasMoreElements())
        this.tbsGen.addCRLEntry(ASN1Sequence.getInstance(((ASN1Encodable)localEnumeration.nextElement()).getDERObject()));
    }
    return this;
  }

  public X509v2CRLBuilder addExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier, boolean paramBoolean, ASN1Encodable paramASN1Encodable)
  {
    this.extGenerator.addExtension(paramASN1ObjectIdentifier, paramBoolean, paramASN1Encodable);
    return this;
  }

  public X509CRLHolder build(ContentSigner paramContentSigner)
  {
    this.tbsGen.setSignature(paramContentSigner.getAlgorithmIdentifier());
    if (!this.extGenerator.isEmpty())
      this.tbsGen.setExtensions(this.extGenerator.generate());
    return CertUtils.generateFullCRL(paramContentSigner, this.tbsGen.generateTBSCertList());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.X509v2CRLBuilder
 * JD-Core Version:    0.6.0
 */