package org.bouncycastle.cert;

import java.math.BigInteger;
import java.util.Date;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;
import org.bouncycastle.asn1.x509.Time;
import org.bouncycastle.asn1.x509.V3TBSCertificateGenerator;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509ExtensionsGenerator;
import org.bouncycastle.operator.ContentSigner;

public class X509v3CertificateBuilder
{
  private V3TBSCertificateGenerator tbsGen = new V3TBSCertificateGenerator();
  private X509ExtensionsGenerator extGenerator;

  public X509v3CertificateBuilder(X500Name paramX500Name1, BigInteger paramBigInteger, Date paramDate1, Date paramDate2, X500Name paramX500Name2, SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    this.tbsGen.setSerialNumber(new DERInteger(paramBigInteger));
    this.tbsGen.setIssuer(paramX500Name1);
    this.tbsGen.setStartDate(new Time(paramDate1));
    this.tbsGen.setEndDate(new Time(paramDate2));
    this.tbsGen.setSubject(paramX500Name2);
    this.tbsGen.setSubjectPublicKeyInfo(paramSubjectPublicKeyInfo);
    this.extGenerator = new X509ExtensionsGenerator();
  }

  public X509v3CertificateBuilder setSubjectUniqueID(boolean[] paramArrayOfBoolean)
  {
    this.tbsGen.setSubjectUniqueID(CertUtils.booleanToBitString(paramArrayOfBoolean));
    return this;
  }

  public X509v3CertificateBuilder setIssuerUniqueID(boolean[] paramArrayOfBoolean)
  {
    this.tbsGen.setIssuerUniqueID(CertUtils.booleanToBitString(paramArrayOfBoolean));
    return this;
  }

  public X509v3CertificateBuilder addExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier, boolean paramBoolean, ASN1Encodable paramASN1Encodable)
  {
    this.extGenerator.addExtension(paramASN1ObjectIdentifier, paramBoolean, paramASN1Encodable);
    return this;
  }

  public X509v3CertificateBuilder copyAndAddExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier, boolean paramBoolean, X509CertificateHolder paramX509CertificateHolder)
  {
    X509CertificateStructure localX509CertificateStructure = paramX509CertificateHolder.toASN1Structure();
    X509Extension localX509Extension = localX509CertificateStructure.getTBSCertificate().getExtensions().getExtension(paramASN1ObjectIdentifier);
    if (localX509Extension == null)
      throw new NullPointerException("extension " + paramASN1ObjectIdentifier + " not present");
    this.extGenerator.addExtension(paramASN1ObjectIdentifier, paramBoolean, localX509Extension.getValue().getOctets());
    return this;
  }

  public X509CertificateHolder build(ContentSigner paramContentSigner)
  {
    this.tbsGen.setSignature(paramContentSigner.getAlgorithmIdentifier());
    if (!this.extGenerator.isEmpty())
      this.tbsGen.setExtensions(this.extGenerator.generate());
    return CertUtils.generateFullCert(paramContentSigner, this.tbsGen.generateTBSCertificate());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.X509v3CertificateBuilder
 * JD-Core Version:    0.6.0
 */