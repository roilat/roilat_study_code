package org.bouncycastle.cert.cmp;

public class CMPException extends Exception
{
  private Throwable cause;

  public CMPException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    this.cause = paramThrowable;
  }

  public CMPException(String paramString)
  {
    super(paramString);
  }

  public Throwable getCause()
  {
    return this.cause;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.cmp.CMPException
 * JD-Core Version:    0.6.0
 */