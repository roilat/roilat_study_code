package org.bouncycastle.cert.cmp;

import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.DEROutputStream;

class CMPUtil
{
  static void derEncodeToStream(ASN1Encodable paramASN1Encodable, OutputStream paramOutputStream)
  {
    DEROutputStream localDEROutputStream = new DEROutputStream(paramOutputStream);
    try
    {
      localDEROutputStream.writeObject(paramASN1Encodable);
      localDEROutputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new CMPRuntimeException("unable to DER encode object: " + localIOException.getMessage(), localIOException);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.cmp.CMPUtil
 * JD-Core Version:    0.6.0
 */