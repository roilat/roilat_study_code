package org.bouncycastle.cert.cmp;

import org.bouncycastle.asn1.cmp.CertConfirmContent;
import org.bouncycastle.asn1.cmp.CertStatus;
import org.bouncycastle.operator.DefaultDigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DigestAlgorithmIdentifierFinder;

public class CertificateConfirmationContent
{
  private DigestAlgorithmIdentifierFinder digestAlgFinder;
  private CertConfirmContent content;

  public CertificateConfirmationContent(CertConfirmContent paramCertConfirmContent)
  {
    this(paramCertConfirmContent, new DefaultDigestAlgorithmIdentifierFinder());
  }

  public CertificateConfirmationContent(CertConfirmContent paramCertConfirmContent, DigestAlgorithmIdentifierFinder paramDigestAlgorithmIdentifierFinder)
  {
    this.digestAlgFinder = paramDigestAlgorithmIdentifierFinder;
    this.content = paramCertConfirmContent;
  }

  public CertConfirmContent toASN1Structure()
  {
    return this.content;
  }

  public CertificateStatus[] getStatusMessages()
  {
    CertStatus[] arrayOfCertStatus = this.content.toCertStatusArray();
    CertificateStatus[] arrayOfCertificateStatus = new CertificateStatus[arrayOfCertStatus.length];
    for (int i = 0; i != arrayOfCertificateStatus.length; i++)
      arrayOfCertificateStatus[i] = new CertificateStatus(this.digestAlgFinder, arrayOfCertStatus[i]);
    return arrayOfCertificateStatus;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.cmp.CertificateConfirmationContent
 * JD-Core Version:    0.6.0
 */