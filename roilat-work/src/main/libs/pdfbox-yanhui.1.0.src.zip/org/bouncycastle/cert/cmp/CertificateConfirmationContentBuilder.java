package org.bouncycastle.cert.cmp;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.cmp.CertConfirmContent;
import org.bouncycastle.asn1.cmp.CertStatus;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.DefaultDigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;

public class CertificateConfirmationContentBuilder
{
  private DigestAlgorithmIdentifierFinder digestAlgFinder;
  private List acceptedCerts = new ArrayList();
  private List acceptedReqIds = new ArrayList();

  public CertificateConfirmationContentBuilder()
  {
    this(new DefaultDigestAlgorithmIdentifierFinder());
  }

  public CertificateConfirmationContentBuilder(DigestAlgorithmIdentifierFinder paramDigestAlgorithmIdentifierFinder)
  {
    this.digestAlgFinder = paramDigestAlgorithmIdentifierFinder;
  }

  public CertificateConfirmationContentBuilder addAcceptedCertificate(X509CertificateHolder paramX509CertificateHolder, BigInteger paramBigInteger)
  {
    this.acceptedCerts.add(paramX509CertificateHolder);
    this.acceptedReqIds.add(paramBigInteger);
    return this;
  }

  public CertificateConfirmationContent build(DigestCalculatorProvider paramDigestCalculatorProvider)
    throws CMPException
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    for (int i = 0; i != this.acceptedCerts.size(); i++)
    {
      X509CertificateHolder localX509CertificateHolder = (X509CertificateHolder)this.acceptedCerts.get(i);
      BigInteger localBigInteger = (BigInteger)this.acceptedReqIds.get(i);
      AlgorithmIdentifier localAlgorithmIdentifier = this.digestAlgFinder.find(localX509CertificateHolder.toASN1Structure().getSignatureAlgorithm());
      if (localAlgorithmIdentifier == null)
        throw new CMPException("cannot find algorithm for digest from signature");
      DigestCalculator localDigestCalculator;
      try
      {
        localDigestCalculator = paramDigestCalculatorProvider.get(localAlgorithmIdentifier);
      }
      catch (OperatorCreationException localOperatorCreationException)
      {
        throw new CMPException("unable to create digest: " + localOperatorCreationException.getMessage(), localOperatorCreationException);
      }
      CMPUtil.derEncodeToStream(localX509CertificateHolder.toASN1Structure(), localDigestCalculator.getOutputStream());
      localASN1EncodableVector.add(new CertStatus(localDigestCalculator.getDigest(), localBigInteger));
    }
    return new CertificateConfirmationContent(CertConfirmContent.getInstance(new DERSequence(localASN1EncodableVector)), this.digestAlgFinder);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.cmp.CertificateConfirmationContentBuilder
 * JD-Core Version:    0.6.0
 */