package org.bouncycastle.cert.cmp;

import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.cmp.CertStatus;
import org.bouncycastle.asn1.cmp.PKIStatusInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.DigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.util.Arrays;

public class CertificateStatus
{
  private DigestAlgorithmIdentifierFinder digestAlgFinder;
  private CertStatus certStatus;

  CertificateStatus(DigestAlgorithmIdentifierFinder paramDigestAlgorithmIdentifierFinder, CertStatus paramCertStatus)
  {
    this.digestAlgFinder = paramDigestAlgorithmIdentifierFinder;
    this.certStatus = paramCertStatus;
  }

  public PKIStatusInfo getStatusInfo()
  {
    return this.certStatus.getStatusInfo();
  }

  public BigInteger getCertRequestID()
  {
    return this.certStatus.getCertReqId().getValue();
  }

  public boolean isVerified(X509CertificateHolder paramX509CertificateHolder, DigestCalculatorProvider paramDigestCalculatorProvider)
    throws CMPException
  {
    AlgorithmIdentifier localAlgorithmIdentifier = this.digestAlgFinder.find(paramX509CertificateHolder.toASN1Structure().getSignatureAlgorithm());
    if (localAlgorithmIdentifier == null)
      throw new CMPException("cannot find algorithm for digest from signature");
    DigestCalculator localDigestCalculator;
    try
    {
      localDigestCalculator = paramDigestCalculatorProvider.get(localAlgorithmIdentifier);
    }
    catch (OperatorCreationException localOperatorCreationException)
    {
      throw new CMPException("unable to create digester: " + localOperatorCreationException.getMessage(), localOperatorCreationException);
    }
    CMPUtil.derEncodeToStream(paramX509CertificateHolder.toASN1Structure(), localDigestCalculator.getOutputStream());
    return Arrays.areEqual(this.certStatus.getCertHash().getOctets(), localDigestCalculator.getDigest());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.cmp.CertificateStatus
 * JD-Core Version:    0.6.0
 */