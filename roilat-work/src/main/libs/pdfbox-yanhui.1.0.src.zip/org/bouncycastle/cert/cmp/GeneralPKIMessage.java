package org.bouncycastle.cert.cmp;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.cmp.PKIBody;
import org.bouncycastle.asn1.cmp.PKIHeader;
import org.bouncycastle.asn1.cmp.PKIMessage;
import org.bouncycastle.cert.CertIOException;

public class GeneralPKIMessage
{
  private final PKIMessage pkiMessage;

  private static PKIMessage parseBytes(byte[] paramArrayOfByte)
    throws IOException
  {
    try
    {
      return PKIMessage.getInstance(ASN1Object.fromByteArray(paramArrayOfByte));
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CertIOException("malformed data: " + localClassCastException.getMessage(), localClassCastException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    throw new CertIOException("malformed data: " + localIllegalArgumentException.getMessage(), localIllegalArgumentException);
  }

  public GeneralPKIMessage(byte[] paramArrayOfByte)
    throws IOException
  {
    this(parseBytes(paramArrayOfByte));
  }

  public GeneralPKIMessage(PKIMessage paramPKIMessage)
  {
    this.pkiMessage = paramPKIMessage;
  }

  public PKIHeader getHeader()
  {
    return this.pkiMessage.getHeader();
  }

  public PKIBody getBody()
  {
    return this.pkiMessage.getBody();
  }

  public boolean hasProtection()
  {
    return this.pkiMessage.getHeader().getProtectionAlg() != null;
  }

  public PKIMessage toASN1Structure()
  {
    return this.pkiMessage;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.cmp.GeneralPKIMessage
 * JD-Core Version:    0.6.0
 */