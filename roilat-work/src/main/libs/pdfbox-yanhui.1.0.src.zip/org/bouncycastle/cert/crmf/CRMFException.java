package org.bouncycastle.cert.crmf;

public class CRMFException extends Exception
{
  private Throwable cause;

  public CRMFException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    this.cause = paramThrowable;
  }

  public Throwable getCause()
  {
    return this.cause;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.CRMFException
 * JD-Core Version:    0.6.0
 */