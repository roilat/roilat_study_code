package org.bouncycastle.cert.crmf;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.crmf.AttributeTypeAndValue;
import org.bouncycastle.asn1.crmf.CRMFObjectIdentifiers;
import org.bouncycastle.asn1.crmf.CertReqMsg;
import org.bouncycastle.asn1.crmf.CertRequest;
import org.bouncycastle.asn1.crmf.CertTemplate;
import org.bouncycastle.asn1.crmf.Controls;
import org.bouncycastle.asn1.crmf.PKIArchiveOptions;
import org.bouncycastle.asn1.crmf.PKMACValue;
import org.bouncycastle.asn1.crmf.POPOSigningKey;
import org.bouncycastle.asn1.crmf.POPOSigningKeyInput;
import org.bouncycastle.asn1.crmf.ProofOfPossession;
import org.bouncycastle.cert.CertIOException;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;
import org.bouncycastle.operator.OperatorCreationException;

public class CertificateRequestMessage
{
  public static final int popRaVerified = 0;
  public static final int popSigningKey = 1;
  public static final int popKeyEncipherment = 2;
  public static final int popKeyAgreement = 3;
  private final CertReqMsg certReqMsg;
  private final Controls controls;

  private static CertReqMsg parseBytes(byte[] paramArrayOfByte)
    throws IOException
  {
    try
    {
      return CertReqMsg.getInstance(ASN1Object.fromByteArray(paramArrayOfByte));
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CertIOException("malformed data: " + localClassCastException.getMessage(), localClassCastException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    throw new CertIOException("malformed data: " + localIllegalArgumentException.getMessage(), localIllegalArgumentException);
  }

  public CertificateRequestMessage(byte[] paramArrayOfByte)
    throws IOException
  {
    this(parseBytes(paramArrayOfByte));
  }

  public CertificateRequestMessage(CertReqMsg paramCertReqMsg)
  {
    this.certReqMsg = paramCertReqMsg;
    this.controls = paramCertReqMsg.getCertReq().getControls();
  }

  public CertReqMsg toASN1Structure()
  {
    return this.certReqMsg;
  }

  public CertTemplate getCertTemplate()
  {
    return this.certReqMsg.getCertReq().getCertTemplate();
  }

  public boolean hasControls()
  {
    return this.controls != null;
  }

  public boolean hasControl(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    return findControl(paramASN1ObjectIdentifier) != null;
  }

  public Control getControl(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    AttributeTypeAndValue localAttributeTypeAndValue = findControl(paramASN1ObjectIdentifier);
    if (localAttributeTypeAndValue != null)
    {
      if (localAttributeTypeAndValue.getType().equals(CRMFObjectIdentifiers.id_regCtrl_pkiArchiveOptions))
        return new PKIArchiveControl(PKIArchiveOptions.getInstance(localAttributeTypeAndValue.getValue()));
      if (localAttributeTypeAndValue.getType().equals(CRMFObjectIdentifiers.id_regCtrl_regToken))
        return new RegTokenControl(DERUTF8String.getInstance(localAttributeTypeAndValue.getValue()));
      if (localAttributeTypeAndValue.getType().equals(CRMFObjectIdentifiers.id_regCtrl_authenticator))
        return new AuthenticatorControl(DERUTF8String.getInstance(localAttributeTypeAndValue.getValue()));
    }
    return null;
  }

  private AttributeTypeAndValue findControl(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    if (this.controls == null)
      return null;
    AttributeTypeAndValue[] arrayOfAttributeTypeAndValue = this.controls.toAttributeTypeAndValueArray();
    AttributeTypeAndValue localAttributeTypeAndValue = null;
    for (int i = 0; i != arrayOfAttributeTypeAndValue.length; i++)
    {
      if (!arrayOfAttributeTypeAndValue[i].getType().equals(paramASN1ObjectIdentifier))
        continue;
      localAttributeTypeAndValue = arrayOfAttributeTypeAndValue[i];
      break;
    }
    return localAttributeTypeAndValue;
  }

  public boolean hasProofOfPossession()
  {
    return this.certReqMsg.getPopo() != null;
  }

  public int getProofOfPossessionType()
  {
    return this.certReqMsg.getPopo().getType();
  }

  public boolean hasSigningKeyProofOfPossessionWithPKMAC()
  {
    ProofOfPossession localProofOfPossession = this.certReqMsg.getPopo();
    if (localProofOfPossession.getType() == 1)
    {
      POPOSigningKey localPOPOSigningKey = POPOSigningKey.getInstance(localProofOfPossession.getObject());
      return localPOPOSigningKey.getPoposkInput().getPublicKeyMAC() != null;
    }
    return false;
  }

  public boolean isValidSigningKeyPOP(ContentVerifierProvider paramContentVerifierProvider)
    throws CRMFException, IllegalStateException
  {
    ProofOfPossession localProofOfPossession = this.certReqMsg.getPopo();
    if (localProofOfPossession.getType() == 1)
    {
      POPOSigningKey localPOPOSigningKey = POPOSigningKey.getInstance(localProofOfPossession.getObject());
      if (localPOPOSigningKey.getPoposkInput().getPublicKeyMAC() != null)
        throw new IllegalStateException("verification requires password check");
      return verifySignature(paramContentVerifierProvider, localPOPOSigningKey);
    }
    throw new IllegalStateException("not Signing Key type of proof of possession");
  }

  public boolean isValidSigningKeyPOP(ContentVerifierProvider paramContentVerifierProvider, PKMACBuilder paramPKMACBuilder, char[] paramArrayOfChar)
    throws CRMFException, IllegalStateException
  {
    ProofOfPossession localProofOfPossession = this.certReqMsg.getPopo();
    if (localProofOfPossession.getType() == 1)
    {
      POPOSigningKey localPOPOSigningKey = POPOSigningKey.getInstance(localProofOfPossession.getObject());
      if (localPOPOSigningKey.getPoposkInput().getSender() != null)
        throw new IllegalStateException("no PKMAC present in proof of possession");
      PKMACValue localPKMACValue = localPOPOSigningKey.getPoposkInput().getPublicKeyMAC();
      PKMACValueVerifier localPKMACValueVerifier = new PKMACValueVerifier(paramPKMACBuilder);
      if (localPKMACValueVerifier.isValid(localPKMACValue, paramArrayOfChar, getCertTemplate().getPublicKey()))
        return verifySignature(paramContentVerifierProvider, localPOPOSigningKey);
      return false;
    }
    throw new IllegalStateException("not Signing Key type of proof of possession");
  }

  private boolean verifySignature(ContentVerifierProvider paramContentVerifierProvider, POPOSigningKey paramPOPOSigningKey)
    throws CRMFException
  {
    ContentVerifier localContentVerifier;
    try
    {
      localContentVerifier = paramContentVerifierProvider.get(paramPOPOSigningKey.getAlgorithmIdentifier());
    }
    catch (OperatorCreationException localOperatorCreationException)
    {
      throw new CRMFException("unable to create verifier: " + localOperatorCreationException.getMessage(), localOperatorCreationException);
    }
    CRMFUtil.derEncodeToStream(paramPOPOSigningKey.getPoposkInput(), localContentVerifier.getOutputStream());
    return localContentVerifier.verify(paramPOPOSigningKey.getSignature().getBytes());
  }

  public byte[] getEncoded()
    throws IOException
  {
    return this.certReqMsg.getEncoded();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.CertificateRequestMessage
 * JD-Core Version:    0.6.0
 */