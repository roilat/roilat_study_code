package org.bouncycastle.cert.crmf;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Integer;
import org.bouncycastle.asn1.ASN1Null;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.crmf.AttributeTypeAndValue;
import org.bouncycastle.asn1.crmf.CertReqMsg;
import org.bouncycastle.asn1.crmf.CertRequest;
import org.bouncycastle.asn1.crmf.CertTemplate;
import org.bouncycastle.asn1.crmf.CertTemplateBuilder;
import org.bouncycastle.asn1.crmf.POPOPrivKey;
import org.bouncycastle.asn1.crmf.ProofOfPossession;
import org.bouncycastle.asn1.crmf.SubsequentMessage;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509ExtensionsGenerator;
import org.bouncycastle.operator.ContentSigner;

public class CertificateRequestMessageBuilder
{
  private final BigInteger certReqId;
  private X509ExtensionsGenerator extGenerator;
  private CertTemplateBuilder templateBuilder;
  private List controls;
  private ContentSigner popSigner;
  private PKMACBuilder pkmacBuilder;
  private char[] password;
  private GeneralName sender;
  private POPOPrivKey popoPrivKey;
  private ASN1Null popRaVerified;

  public CertificateRequestMessageBuilder(BigInteger paramBigInteger)
  {
    this.certReqId = paramBigInteger;
    this.extGenerator = new X509ExtensionsGenerator();
    this.templateBuilder = new CertTemplateBuilder();
    this.controls = new ArrayList();
  }

  public CertificateRequestMessageBuilder setPublicKey(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    if (paramSubjectPublicKeyInfo != null)
      this.templateBuilder.setPublicKey(paramSubjectPublicKeyInfo);
    return this;
  }

  public CertificateRequestMessageBuilder setIssuer(X500Name paramX500Name)
  {
    if (paramX500Name != null)
      this.templateBuilder.setIssuer(paramX500Name);
    return this;
  }

  public CertificateRequestMessageBuilder setSubject(X500Name paramX500Name)
  {
    if (paramX500Name != null)
      this.templateBuilder.setSubject(paramX500Name);
    return this;
  }

  public CertificateRequestMessageBuilder setSerialNumber(BigInteger paramBigInteger)
  {
    if (paramBigInteger != null)
      this.templateBuilder.setSerialNumber(new ASN1Integer(paramBigInteger));
    return this;
  }

  public CertificateRequestMessageBuilder addExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier, boolean paramBoolean, ASN1Encodable paramASN1Encodable)
  {
    this.extGenerator.addExtension(paramASN1ObjectIdentifier, paramBoolean, paramASN1Encodable);
    return this;
  }

  public CertificateRequestMessageBuilder addExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier, boolean paramBoolean, byte[] paramArrayOfByte)
  {
    this.extGenerator.addExtension(paramASN1ObjectIdentifier, paramBoolean, paramArrayOfByte);
    return this;
  }

  public CertificateRequestMessageBuilder addControl(Control paramControl)
  {
    this.controls.add(paramControl);
    return this;
  }

  public CertificateRequestMessageBuilder setProofOfPossessionSigningKeySigner(ContentSigner paramContentSigner)
  {
    if ((this.popoPrivKey != null) || (this.popRaVerified != null))
      throw new IllegalStateException("only one proof of possession allowed");
    this.popSigner = paramContentSigner;
    return this;
  }

  public CertificateRequestMessageBuilder setProofOfPossessionSubsequentMessage(SubsequentMessage paramSubsequentMessage)
  {
    if ((this.popSigner != null) || (this.popRaVerified != null))
      throw new IllegalStateException("only one proof of possession allowed");
    this.popoPrivKey = new POPOPrivKey(paramSubsequentMessage);
    return this;
  }

  public CertificateRequestMessageBuilder setProofOfPossessionRaVerified()
  {
    if ((this.popSigner != null) || (this.popoPrivKey != null))
      throw new IllegalStateException("only one proof of possession allowed");
    this.popRaVerified = DERNull.INSTANCE;
    return this;
  }

  public CertificateRequestMessageBuilder setAuthInfoPKMAC(PKMACBuilder paramPKMACBuilder, char[] paramArrayOfChar)
  {
    this.pkmacBuilder = paramPKMACBuilder;
    this.password = paramArrayOfChar;
    return this;
  }

  public CertificateRequestMessageBuilder setAuthInfoSender(X500Name paramX500Name)
  {
    return setAuthInfoSender(new GeneralName(paramX500Name));
  }

  public CertificateRequestMessageBuilder setAuthInfoSender(GeneralName paramGeneralName)
  {
    this.sender = paramGeneralName;
    return this;
  }

  public CertificateRequestMessage build()
    throws CRMFException
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERInteger(this.certReqId));
    if (!this.extGenerator.isEmpty())
      this.templateBuilder.setExtensions(this.extGenerator.generate());
    localASN1EncodableVector.add(this.templateBuilder.build());
    Object localObject2;
    Object localObject3;
    if (!this.controls.isEmpty())
    {
      localObject1 = new ASN1EncodableVector();
      localObject2 = this.controls.iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (Control)((Iterator)localObject2).next();
        ((ASN1EncodableVector)localObject1).add(new AttributeTypeAndValue(((Control)localObject3).getType(), ((Control)localObject3).getValue()));
      }
      localASN1EncodableVector.add(new DERSequence((ASN1EncodableVector)localObject1));
    }
    Object localObject1 = CertRequest.getInstance(new DERSequence(localASN1EncodableVector));
    localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add((DEREncodable)localObject1);
    if (this.popSigner != null)
    {
      localObject2 = ((CertRequest)localObject1).getCertTemplate().getPublicKey();
      localObject3 = new ProofOfPossessionSigningKeyBuilder((SubjectPublicKeyInfo)localObject2);
      if (this.sender != null)
      {
        ((ProofOfPossessionSigningKeyBuilder)localObject3).setSender(this.sender);
      }
      else
      {
        PKMACValueGenerator localPKMACValueGenerator = new PKMACValueGenerator(this.pkmacBuilder);
        ((ProofOfPossessionSigningKeyBuilder)localObject3).setPublicKeyMac(localPKMACValueGenerator, this.password);
      }
      localASN1EncodableVector.add(new ProofOfPossession(((ProofOfPossessionSigningKeyBuilder)localObject3).build(this.popSigner)));
    }
    else if (this.popoPrivKey != null)
    {
      localASN1EncodableVector.add(new ProofOfPossession(2, this.popoPrivKey));
    }
    else if (this.popRaVerified != null)
    {
      localASN1EncodableVector.add(new ProofOfPossession());
    }
    return (CertificateRequestMessage)(CertificateRequestMessage)(CertificateRequestMessage)new CertificateRequestMessage(CertReqMsg.getInstance(new DERSequence(localASN1EncodableVector)));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.CertificateRequestMessageBuilder
 * JD-Core Version:    0.6.0
 */