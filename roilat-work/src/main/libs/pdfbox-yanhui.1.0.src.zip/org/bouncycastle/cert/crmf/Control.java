package org.bouncycastle.cert.crmf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;

public abstract interface Control
{
  public abstract ASN1ObjectIdentifier getType();

  public abstract ASN1Encodable getValue();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.Control
 * JD-Core Version:    0.6.0
 */