package org.bouncycastle.cert.crmf;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.crmf.EncryptedValue;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.KeyWrapper;
import org.bouncycastle.operator.OperatorException;
import org.bouncycastle.operator.OutputEncryptor;
import org.bouncycastle.util.Strings;

public class EncryptedValueBuilder
{
  private KeyWrapper wrapper;
  private OutputEncryptor encryptor;
  private EncryptedValuePadder padder;

  public EncryptedValueBuilder(KeyWrapper paramKeyWrapper, OutputEncryptor paramOutputEncryptor)
  {
    this(paramKeyWrapper, paramOutputEncryptor, null);
  }

  public EncryptedValueBuilder(KeyWrapper paramKeyWrapper, OutputEncryptor paramOutputEncryptor, EncryptedValuePadder paramEncryptedValuePadder)
  {
    this.wrapper = paramKeyWrapper;
    this.encryptor = paramOutputEncryptor;
    this.padder = paramEncryptedValuePadder;
  }

  public EncryptedValue build(char[] paramArrayOfChar)
    throws CRMFException
  {
    return encryptData(padData(Strings.toUTF8ByteArray(paramArrayOfChar)));
  }

  public EncryptedValue build(X509CertificateHolder paramX509CertificateHolder)
    throws CRMFException
  {
    try
    {
      return encryptData(padData(paramX509CertificateHolder.getEncoded()));
    }
    catch (IOException localIOException)
    {
    }
    throw new CRMFException("cannot encode certificate: " + localIOException.getMessage(), localIOException);
  }

  private EncryptedValue encryptData(byte[] paramArrayOfByte)
    throws CRMFException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = this.encryptor.getOutputStream(localByteArrayOutputStream);
    try
    {
      localOutputStream.write(paramArrayOfByte);
      localOutputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new CRMFException("cannot process data: " + localIOException.getMessage(), localIOException);
    }
    AlgorithmIdentifier localAlgorithmIdentifier1 = null;
    AlgorithmIdentifier localAlgorithmIdentifier2 = this.encryptor.getAlgorithmIdentifier();
    DERBitString localDERBitString1;
    try
    {
      this.wrapper.generateWrappedKey(this.encryptor.getKey());
      localDERBitString1 = new DERBitString(this.wrapper.generateWrappedKey(this.encryptor.getKey()));
    }
    catch (OperatorException localOperatorException)
    {
      throw new CRMFException("cannot wrap key: " + localOperatorException.getMessage(), localOperatorException);
    }
    AlgorithmIdentifier localAlgorithmIdentifier3 = this.wrapper.getAlgorithmIdentifier();
    ASN1OctetString localASN1OctetString = null;
    DERBitString localDERBitString2 = new DERBitString(localByteArrayOutputStream.toByteArray());
    return new EncryptedValue(localAlgorithmIdentifier1, localAlgorithmIdentifier2, localDERBitString1, localAlgorithmIdentifier3, localASN1OctetString, localDERBitString2);
  }

  private byte[] padData(byte[] paramArrayOfByte)
  {
    if (this.padder != null)
      return this.padder.getPaddedData(paramArrayOfByte);
    return paramArrayOfByte;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.EncryptedValueBuilder
 * JD-Core Version:    0.6.0
 */