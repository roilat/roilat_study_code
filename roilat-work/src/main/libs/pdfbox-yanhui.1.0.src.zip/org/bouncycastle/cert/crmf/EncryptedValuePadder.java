package org.bouncycastle.cert.crmf;

public abstract interface EncryptedValuePadder
{
  public abstract byte[] getPaddedData(byte[] paramArrayOfByte);

  public abstract byte[] getUnpaddedData(byte[] paramArrayOfByte);
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.EncryptedValuePadder
 * JD-Core Version:    0.6.0
 */