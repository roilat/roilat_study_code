package org.bouncycastle.cert.crmf;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.crmf.EncryptedValue;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.InputDecryptor;
import org.bouncycastle.util.Strings;
import org.bouncycastle.util.io.Streams;

public class EncryptedValueParser
{
  private EncryptedValue value;
  private EncryptedValuePadder padder;

  public EncryptedValueParser(EncryptedValue paramEncryptedValue)
  {
    this.value = paramEncryptedValue;
  }

  public EncryptedValueParser(EncryptedValue paramEncryptedValue, EncryptedValuePadder paramEncryptedValuePadder)
  {
    this.value = paramEncryptedValue;
    this.padder = paramEncryptedValuePadder;
  }

  private byte[] decryptValue(ValueDecryptorGenerator paramValueDecryptorGenerator)
    throws CRMFException
  {
    if (this.value.getIntendedAlg() != null)
      throw new UnsupportedOperationException();
    if (this.value.getValueHint() != null)
      throw new UnsupportedOperationException();
    InputDecryptor localInputDecryptor = paramValueDecryptorGenerator.getValueDecryptor(this.value.getKeyAlg(), this.value.getSymmAlg(), this.value.getEncSymmKey().getBytes());
    InputStream localInputStream = localInputDecryptor.getInputStream(new ByteArrayInputStream(this.value.getEncValue().getBytes()));
    try
    {
      byte[] arrayOfByte = Streams.readAll(localInputStream);
      if (this.padder != null)
        return this.padder.getUnpaddedData(arrayOfByte);
      return arrayOfByte;
    }
    catch (IOException localIOException)
    {
    }
    throw new CRMFException("Cannot parse decrypted data: " + localIOException.getMessage(), localIOException);
  }

  public X509CertificateHolder readCertificateHolder(ValueDecryptorGenerator paramValueDecryptorGenerator)
    throws CRMFException
  {
    return new X509CertificateHolder(X509CertificateStructure.getInstance(decryptValue(paramValueDecryptorGenerator)));
  }

  public char[] readPassphrase(ValueDecryptorGenerator paramValueDecryptorGenerator)
    throws CRMFException
  {
    return Strings.fromUTF8ByteArray(decryptValue(paramValueDecryptorGenerator)).toCharArray();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.EncryptedValueParser
 * JD-Core Version:    0.6.0
 */