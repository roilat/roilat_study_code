package org.bouncycastle.cert.crmf;

import java.security.SecureRandom;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.generators.MGF1BytesGenerator;
import org.bouncycastle.crypto.params.MGFParameters;

public class FixedLengthMGF1Padder
  implements EncryptedValuePadder
{
  private int length;
  private SecureRandom random;
  private Digest dig = new SHA1Digest();

  public FixedLengthMGF1Padder(int paramInt)
  {
    this(paramInt, null);
  }

  public FixedLengthMGF1Padder(int paramInt, SecureRandom paramSecureRandom)
  {
    this.length = paramInt;
    this.random = paramSecureRandom;
  }

  public byte[] getPaddedData(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte1 = new byte[this.length];
    byte[] arrayOfByte2 = new byte[this.dig.getDigestSize()];
    byte[] arrayOfByte3 = new byte[this.length - this.dig.getDigestSize()];
    if (this.random == null)
      this.random = new SecureRandom();
    this.random.nextBytes(arrayOfByte2);
    MGF1BytesGenerator localMGF1BytesGenerator = new MGF1BytesGenerator(this.dig);
    localMGF1BytesGenerator.init(new MGFParameters(arrayOfByte2));
    localMGF1BytesGenerator.generateBytes(arrayOfByte3, 0, arrayOfByte3.length);
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, arrayOfByte2.length);
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte1, arrayOfByte2.length, paramArrayOfByte.length);
    for (int i = arrayOfByte2.length + paramArrayOfByte.length + 1; i != arrayOfByte1.length; i++)
    {
      int j = (byte)this.random.nextInt();
      arrayOfByte1[i] = (j == 0 ? 1 : j);
    }
    for (i = 0; i != arrayOfByte3.length; i++)
    {
      int tmp184_183 = (i + arrayOfByte2.length);
      byte[] tmp184_178 = arrayOfByte1;
      tmp184_178[tmp184_183] = (byte)(tmp184_178[tmp184_183] ^ arrayOfByte3[i]);
    }
    return arrayOfByte1;
  }

  public byte[] getUnpaddedData(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte1 = new byte[this.dig.getDigestSize()];
    byte[] arrayOfByte2 = new byte[this.length - this.dig.getDigestSize()];
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte1, 0, arrayOfByte1.length);
    MGF1BytesGenerator localMGF1BytesGenerator = new MGF1BytesGenerator(this.dig);
    localMGF1BytesGenerator.init(new MGFParameters(arrayOfByte1));
    localMGF1BytesGenerator.generateBytes(arrayOfByte2, 0, arrayOfByte2.length);
    for (int i = 0; i != arrayOfByte2.length; i++)
    {
      int tmp90_89 = (i + arrayOfByte1.length);
      byte[] tmp90_84 = paramArrayOfByte;
      tmp90_84[tmp90_89] = (byte)(tmp90_84[tmp90_89] ^ arrayOfByte2[i]);
    }
    i = 0;
    for (int j = paramArrayOfByte.length - 1; j != arrayOfByte1.length; j--)
    {
      if (paramArrayOfByte[j] != 0)
        continue;
      i = j;
      break;
    }
    if (i == 0)
      throw new IllegalStateException("bad padding in encoding");
    byte[] arrayOfByte3 = new byte[i - arrayOfByte1.length];
    System.arraycopy(paramArrayOfByte, arrayOfByte1.length, arrayOfByte3, 0, arrayOfByte3.length);
    return arrayOfByte3;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.FixedLengthMGF1Padder
 * JD-Core Version:    0.6.0
 */