package org.bouncycastle.cert.crmf;

import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.crmf.PKMACValue;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.operator.MacCalculator;

class PKMACValueGenerator
{
  private PKMACBuilder builder;

  public PKMACValueGenerator(PKMACBuilder paramPKMACBuilder)
  {
    this.builder = paramPKMACBuilder;
  }

  public PKMACValue generate(char[] paramArrayOfChar, SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
    throws CRMFException
  {
    MacCalculator localMacCalculator = this.builder.build(paramArrayOfChar);
    OutputStream localOutputStream = localMacCalculator.getOutputStream();
    try
    {
      localOutputStream.write(paramSubjectPublicKeyInfo.getDEREncoded());
      localOutputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new CRMFException("exception encoding mac input: " + localIOException.getMessage(), localIOException);
    }
    return new PKMACValue(localMacCalculator.getAlgorithmIdentifier(), new DERBitString(localMacCalculator.getMac()));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.PKMACValueGenerator
 * JD-Core Version:    0.6.0
 */