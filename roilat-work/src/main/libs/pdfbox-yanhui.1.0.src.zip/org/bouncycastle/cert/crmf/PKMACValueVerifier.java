package org.bouncycastle.cert.crmf;

import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.cmp.PBMParameter;
import org.bouncycastle.asn1.crmf.PKMACValue;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.operator.MacCalculator;
import org.bouncycastle.util.Arrays;

class PKMACValueVerifier
{
  private final PKMACBuilder builder;

  public PKMACValueVerifier(PKMACBuilder paramPKMACBuilder)
  {
    this.builder = paramPKMACBuilder;
  }

  public boolean isValid(PKMACValue paramPKMACValue, char[] paramArrayOfChar, SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
    throws CRMFException
  {
    this.builder.setParameters(PBMParameter.getInstance(paramPKMACValue.getAlgId().getParameters()));
    MacCalculator localMacCalculator = this.builder.build(paramArrayOfChar);
    OutputStream localOutputStream = localMacCalculator.getOutputStream();
    try
    {
      localOutputStream.write(paramSubjectPublicKeyInfo.getDEREncoded());
      localOutputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new CRMFException("exception encoding mac input: " + localIOException.getMessage(), localIOException);
    }
    return Arrays.areEqual(localMacCalculator.getMac(), paramPKMACValue.getValue().getBytes());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.PKMACValueVerifier
 * JD-Core Version:    0.6.0
 */