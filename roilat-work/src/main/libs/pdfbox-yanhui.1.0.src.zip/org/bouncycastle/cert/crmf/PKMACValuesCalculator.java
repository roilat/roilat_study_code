package org.bouncycastle.cert.crmf;

import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface PKMACValuesCalculator
{
  public abstract void setup(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2)
    throws CRMFException;

  public abstract byte[] calculateDigest(byte[] paramArrayOfByte)
    throws CRMFException;

  public abstract byte[] calculateMac(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws CRMFException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.PKMACValuesCalculator
 * JD-Core Version:    0.6.0
 */