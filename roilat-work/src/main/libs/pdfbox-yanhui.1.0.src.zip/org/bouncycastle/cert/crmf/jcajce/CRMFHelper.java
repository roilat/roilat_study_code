package org.bouncycastle.cert.crmf.jcajce;

import java.io.IOException;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.InvalidParameterSpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.RC2ParameterSpec;
import org.bouncycastle.asn1.ASN1Null;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.iana.IANAObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.cert.crmf.CRMFException;
import org.bouncycastle.cms.CMSAlgorithm;
import org.bouncycastle.cms.CMSEnvelopedDataGenerator;
import org.bouncycastle.jcajce.JcaJceHelper;

class CRMFHelper
{
  protected static final Map BASE_CIPHER_NAMES = new HashMap();
  protected static final Map CIPHER_ALG_NAMES = new HashMap();
  protected static final Map DIGEST_ALG_NAMES = new HashMap();
  protected static final Map KEY_ALG_NAMES = new HashMap();
  protected static final Map MAC_ALG_NAMES = new HashMap();
  private JcaJceHelper helper;

  CRMFHelper(JcaJceHelper paramJcaJceHelper)
  {
    this.helper = paramJcaJceHelper;
  }

  PublicKey toPublicKey(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
    throws CRMFException
  {
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(new DERBitString(paramSubjectPublicKeyInfo).getBytes());
    AlgorithmIdentifier localAlgorithmIdentifier = paramSubjectPublicKeyInfo.getAlgorithmId();
    try
    {
      return createKeyFactory(localAlgorithmIdentifier.getAlgorithm()).generatePublic(localX509EncodedKeySpec);
    }
    catch (InvalidKeySpecException localInvalidKeySpecException)
    {
    }
    throw new CRMFException("invalid key: " + localInvalidKeySpecException.getMessage(), localInvalidKeySpecException);
  }

  Cipher createCipher(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CRMFException
  {
    try
    {
      String str = (String)CIPHER_ALG_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createCipher(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createCipher(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CRMFException("cannot create cipher: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  public KeyGenerator createKeyGenerator(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CRMFException
  {
    try
    {
      String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createKeyGenerator(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createKeyGenerator(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CRMFException("cannot create key generator: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  Cipher createContentCipher(Key paramKey, AlgorithmIdentifier paramAlgorithmIdentifier)
    throws CRMFException
  {
    return (Cipher)execute(new JCECallback(paramAlgorithmIdentifier, paramKey)
    {
      public Object doInJCE()
        throws CRMFException, InvalidAlgorithmParameterException, InvalidKeyException, InvalidParameterSpecException, NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException
      {
        Cipher localCipher = CRMFHelper.this.createCipher(this.val$encryptionAlgID.getAlgorithm());
        ASN1Object localASN1Object = (ASN1Object)this.val$encryptionAlgID.getParameters();
        String str = this.val$encryptionAlgID.getAlgorithm().getId();
        if ((localASN1Object != null) && (!(localASN1Object instanceof ASN1Null)))
          try
          {
            AlgorithmParameters localAlgorithmParameters = CRMFHelper.this.createAlgorithmParameters(this.val$encryptionAlgID.getAlgorithm());
            try
            {
              localAlgorithmParameters.init(localASN1Object.getEncoded(), "ASN.1");
            }
            catch (IOException localIOException)
            {
              throw new CRMFException("error decoding algorithm parameters.", localIOException);
            }
            localCipher.init(2, this.val$sKey, localAlgorithmParameters);
          }
          catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
          {
            if ((str.equals(CMSEnvelopedDataGenerator.DES_EDE3_CBC)) || (str.equals("1.3.6.1.4.1.188.7.1.1.2")) || (str.equals(CMSEnvelopedDataGenerator.AES128_CBC)) || (str.equals(CMSEnvelopedDataGenerator.AES192_CBC)) || (str.equals(CMSEnvelopedDataGenerator.AES256_CBC)))
              localCipher.init(2, this.val$sKey, new IvParameterSpec(ASN1OctetString.getInstance(localASN1Object).getOctets()));
            else
              throw localNoSuchAlgorithmException;
          }
        else if ((str.equals(CMSEnvelopedDataGenerator.DES_EDE3_CBC)) || (str.equals("1.3.6.1.4.1.188.7.1.1.2")) || (str.equals("1.2.840.113533.7.66.10")))
          localCipher.init(2, this.val$sKey, new IvParameterSpec(new byte[8]));
        else
          localCipher.init(2, this.val$sKey);
        return localCipher;
      }
    });
  }

  AlgorithmParameters createAlgorithmParameters(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws NoSuchAlgorithmException, NoSuchProviderException
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
    if (str != null)
      try
      {
        return this.helper.createAlgorithmParameters(str);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
      }
    return this.helper.createAlgorithmParameters(paramASN1ObjectIdentifier.getId());
  }

  KeyFactory createKeyFactory(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CRMFException
  {
    try
    {
      String str = (String)KEY_ALG_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createKeyFactory(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createKeyFactory(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CRMFException("cannot create cipher: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  MessageDigest createDigest(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CRMFException
  {
    try
    {
      String str = (String)DIGEST_ALG_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createDigest(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createDigest(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CRMFException("cannot create cipher: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  Mac createMac(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CRMFException
  {
    try
    {
      String str = (String)MAC_ALG_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createMac(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createMac(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CRMFException("cannot create mac: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  AlgorithmParameterGenerator createAlgorithmParameterGenerator(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws GeneralSecurityException
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
    if (str != null)
      try
      {
        return this.helper.createAlgorithmParameterGenerator(str);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
      }
    return this.helper.createAlgorithmParameterGenerator(paramASN1ObjectIdentifier.getId());
  }

  AlgorithmParameters generateParameters(ASN1ObjectIdentifier paramASN1ObjectIdentifier, SecretKey paramSecretKey, SecureRandom paramSecureRandom)
    throws CRMFException
  {
    try
    {
      AlgorithmParameterGenerator localAlgorithmParameterGenerator = createAlgorithmParameterGenerator(paramASN1ObjectIdentifier);
      if (paramASN1ObjectIdentifier.equals(CMSEnvelopedDataGenerator.RC2_CBC))
      {
        byte[] arrayOfByte = new byte[8];
        paramSecureRandom.nextBytes(arrayOfByte);
        try
        {
          localAlgorithmParameterGenerator.init(new RC2ParameterSpec(paramSecretKey.getEncoded().length * 8, arrayOfByte), paramSecureRandom);
        }
        catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
        {
          throw new CRMFException("parameters generation error: " + localInvalidAlgorithmParameterException, localInvalidAlgorithmParameterException);
        }
      }
      return localAlgorithmParameterGenerator.generateParameters();
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      return null;
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CRMFException("exception creating algorithm parameter generator: " + localGeneralSecurityException, localGeneralSecurityException);
  }

  AlgorithmIdentifier getAlgorithmIdentifier(ASN1ObjectIdentifier paramASN1ObjectIdentifier, AlgorithmParameters paramAlgorithmParameters)
    throws CRMFException
  {
    Object localObject;
    if (paramAlgorithmParameters != null)
      try
      {
        localObject = ASN1Object.fromByteArray(paramAlgorithmParameters.getEncoded("ASN.1"));
      }
      catch (IOException localIOException)
      {
        throw new CRMFException("cannot encode parameters: " + localIOException.getMessage(), localIOException);
      }
    else
      localObject = DERNull.INSTANCE;
    return (AlgorithmIdentifier)new AlgorithmIdentifier(paramASN1ObjectIdentifier, (DEREncodable)localObject);
  }

  static Object execute(JCECallback paramJCECallback)
    throws CRMFException
  {
    try
    {
      return paramJCECallback.doInJCE();
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CRMFException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CRMFException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
      throw new CRMFException("can't find provider.", localNoSuchProviderException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CRMFException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CRMFException("algorithm parameters invalid.", localInvalidAlgorithmParameterException);
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException)
    {
    }
    throw new CRMFException("MAC algorithm parameter spec invalid.", localInvalidParameterSpecException);
  }

  static
  {
    BASE_CIPHER_NAMES.put(PKCSObjectIdentifiers.des_EDE3_CBC, "DESEDE");
    BASE_CIPHER_NAMES.put(NISTObjectIdentifiers.id_aes128_CBC, "AES");
    BASE_CIPHER_NAMES.put(NISTObjectIdentifiers.id_aes192_CBC, "AES");
    BASE_CIPHER_NAMES.put(NISTObjectIdentifiers.id_aes256_CBC, "AES");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.DES_EDE3_CBC, "DESEDE/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.AES128_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.AES192_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.AES256_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(new ASN1ObjectIdentifier(PKCSObjectIdentifiers.rsaEncryption.getId()), "RSA/ECB/PKCS1Padding");
    DIGEST_ALG_NAMES.put(OIWObjectIdentifiers.idSHA1, "SHA1");
    DIGEST_ALG_NAMES.put(NISTObjectIdentifiers.id_sha224, "SHA224");
    DIGEST_ALG_NAMES.put(NISTObjectIdentifiers.id_sha256, "SHA256");
    DIGEST_ALG_NAMES.put(NISTObjectIdentifiers.id_sha384, "SHA384");
    DIGEST_ALG_NAMES.put(NISTObjectIdentifiers.id_sha512, "SHA512");
    MAC_ALG_NAMES.put(IANAObjectIdentifiers.hmacSHA1, "HMACSHA1");
    MAC_ALG_NAMES.put(PKCSObjectIdentifiers.id_hmacWithSHA1, "HMACSHA1");
    MAC_ALG_NAMES.put(PKCSObjectIdentifiers.id_hmacWithSHA224, "HMACSHA224");
    MAC_ALG_NAMES.put(PKCSObjectIdentifiers.id_hmacWithSHA256, "HMACSHA256");
    MAC_ALG_NAMES.put(PKCSObjectIdentifiers.id_hmacWithSHA384, "HMACSHA384");
    MAC_ALG_NAMES.put(PKCSObjectIdentifiers.id_hmacWithSHA512, "HMACSHA512");
    KEY_ALG_NAMES.put(PKCSObjectIdentifiers.rsaEncryption, "RSA");
    KEY_ALG_NAMES.put(X9ObjectIdentifiers.id_dsa, "DSA");
  }

  static abstract interface JCECallback
  {
    public abstract Object doInJCE()
      throws CRMFException, InvalidAlgorithmParameterException, InvalidKeyException, InvalidParameterSpecException, NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.jcajce.CRMFHelper
 * JD-Core Version:    0.6.0
 */