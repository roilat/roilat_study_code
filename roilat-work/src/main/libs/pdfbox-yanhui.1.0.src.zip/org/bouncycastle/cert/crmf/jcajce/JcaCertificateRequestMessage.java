package org.bouncycastle.cert.crmf.jcajce;

import java.security.Provider;
import java.security.PublicKey;
import javax.security.auth.x500.X500Principal;
import org.bouncycastle.asn1.crmf.CertReqMsg;
import org.bouncycastle.asn1.crmf.CertTemplate;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.crmf.CRMFException;
import org.bouncycastle.cert.crmf.CertificateRequestMessage;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;

public class JcaCertificateRequestMessage extends CertificateRequestMessage
{
  private CRMFHelper helper = new CRMFHelper(new DefaultJcaJceHelper());

  public JcaCertificateRequestMessage(CertificateRequestMessage paramCertificateRequestMessage)
  {
    this(paramCertificateRequestMessage.toASN1Structure());
  }

  public JcaCertificateRequestMessage(CertReqMsg paramCertReqMsg)
  {
    super(paramCertReqMsg);
  }

  public JcaCertificateRequestMessage setProvider(String paramString)
  {
    this.helper = new CRMFHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public JcaCertificateRequestMessage setProvider(Provider paramProvider)
  {
    this.helper = new CRMFHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public X500Principal getSubjectX500Principal()
  {
    X500Name localX500Name = getCertTemplate().getSubject();
    if (localX500Name != null)
      return new X500Principal(localX500Name.getDEREncoded());
    return null;
  }

  public PublicKey getPublicKey()
    throws CRMFException
  {
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = getCertTemplate().getPublicKey();
    if (localSubjectPublicKeyInfo != null)
      return this.helper.toPublicKey(localSubjectPublicKeyInfo);
    return null;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.jcajce.JcaCertificateRequestMessage
 * JD-Core Version:    0.6.0
 */