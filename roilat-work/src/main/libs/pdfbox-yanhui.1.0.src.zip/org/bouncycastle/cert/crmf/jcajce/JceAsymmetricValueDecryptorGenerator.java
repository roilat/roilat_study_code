package org.bouncycastle.cert.crmf.jcajce;

import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.ProviderException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cert.crmf.CRMFException;
import org.bouncycastle.cert.crmf.ValueDecryptorGenerator;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.InputDecryptor;

public class JceAsymmetricValueDecryptorGenerator
  implements ValueDecryptorGenerator
{
  private PrivateKey recipientKey;
  private CRMFHelper helper = new CRMFHelper(new DefaultJcaJceHelper());

  public JceAsymmetricValueDecryptorGenerator(PrivateKey paramPrivateKey)
  {
    this.recipientKey = paramPrivateKey;
  }

  public JceAsymmetricValueDecryptorGenerator setProvider(Provider paramProvider)
  {
    this.helper = new CRMFHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceAsymmetricValueDecryptorGenerator setProvider(String paramString)
  {
    this.helper = new CRMFHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  private Key extractSecretKey(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, byte[] paramArrayOfByte)
    throws CRMFException
  {
    try
    {
      Object localObject = null;
      Cipher localCipher = this.helper.createCipher(paramAlgorithmIdentifier1.getAlgorithm());
      try
      {
        localCipher.init(4, this.recipientKey);
        localObject = localCipher.unwrap(paramArrayOfByte, paramAlgorithmIdentifier2.getAlgorithm().getId(), 3);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
      }
      catch (ProviderException localProviderException)
      {
      }
      if (localObject == null)
      {
        localCipher.init(2, this.recipientKey);
        localObject = new SecretKeySpec(localCipher.doFinal(paramArrayOfByte), paramAlgorithmIdentifier2.getAlgorithm().getId());
      }
      return localObject;
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CRMFException("key invalid in message.", localInvalidKeyException);
    }
    catch (IllegalBlockSizeException localIllegalBlockSizeException)
    {
      throw new CRMFException("illegal blocksize in message.", localIllegalBlockSizeException);
    }
    catch (BadPaddingException localBadPaddingException)
    {
    }
    throw new CRMFException("bad padding in message.", localBadPaddingException);
  }

  public InputDecryptor getValueDecryptor(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, byte[] paramArrayOfByte)
    throws CRMFException
  {
    Key localKey = extractSecretKey(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramArrayOfByte);
    Cipher localCipher = this.helper.createContentCipher(localKey, paramAlgorithmIdentifier2);
    return new InputDecryptor(paramAlgorithmIdentifier2, localCipher)
    {
      public AlgorithmIdentifier getAlgorithmIdentifier()
      {
        return this.val$contentEncryptionAlgorithm;
      }

      public InputStream getInputStream(InputStream paramInputStream)
      {
        return new CipherInputStream(paramInputStream, this.val$dataCipher);
      }
    };
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.jcajce.JceAsymmetricValueDecryptorGenerator
 * JD-Core Version:    0.6.0
 */