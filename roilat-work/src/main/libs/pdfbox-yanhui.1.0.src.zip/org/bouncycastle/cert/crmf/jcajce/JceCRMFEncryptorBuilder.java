package org.bouncycastle.cert.crmf.jcajce;

import java.io.OutputStream;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cert.crmf.CRMFException;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.OutputEncryptor;

public class JceCRMFEncryptorBuilder
{
  private final ASN1ObjectIdentifier encryptionOID;
  private final int keySize;
  private CRMFHelper helper = new CRMFHelper(new DefaultJcaJceHelper());
  private SecureRandom random;

  public JceCRMFEncryptorBuilder(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    this(paramASN1ObjectIdentifier, -1);
  }

  public JceCRMFEncryptorBuilder(ASN1ObjectIdentifier paramASN1ObjectIdentifier, int paramInt)
  {
    this.encryptionOID = paramASN1ObjectIdentifier;
    this.keySize = paramInt;
  }

  public JceCRMFEncryptorBuilder setProvider(Provider paramProvider)
  {
    this.helper = new CRMFHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceCRMFEncryptorBuilder setProvider(String paramString)
  {
    this.helper = new CRMFHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public JceCRMFEncryptorBuilder setSecureRandom(SecureRandom paramSecureRandom)
  {
    this.random = paramSecureRandom;
    return this;
  }

  public OutputEncryptor build()
    throws CRMFException
  {
    return new CRMFOutputEncryptor(this.encryptionOID, this.keySize, this.random);
  }

  private class CRMFOutputEncryptor
    implements OutputEncryptor
  {
    private SecretKey encKey;
    private AlgorithmIdentifier algorithmIdentifier;
    private Cipher cipher;

    CRMFOutputEncryptor(ASN1ObjectIdentifier paramInt, int paramSecureRandom, SecureRandom arg4)
      throws CRMFException
    {
      KeyGenerator localKeyGenerator = JceCRMFEncryptorBuilder.this.helper.createKeyGenerator(paramInt);
      SecureRandom localSecureRandom;
      if (localSecureRandom == null)
        localSecureRandom = new SecureRandom();
      if (paramSecureRandom < 0)
        localKeyGenerator.init(localSecureRandom);
      else
        localKeyGenerator.init(paramSecureRandom, localSecureRandom);
      this.cipher = JceCRMFEncryptorBuilder.this.helper.createCipher(paramInt);
      this.encKey = localKeyGenerator.generateKey();
      AlgorithmParameters localAlgorithmParameters = JceCRMFEncryptorBuilder.this.helper.generateParameters(paramInt, this.encKey, localSecureRandom);
      try
      {
        this.cipher.init(1, this.encKey, localAlgorithmParameters, localSecureRandom);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CRMFException("unable to initialize cipher: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
      }
      if (localAlgorithmParameters == null)
        localAlgorithmParameters = this.cipher.getParameters();
      this.algorithmIdentifier = JceCRMFEncryptorBuilder.this.helper.getAlgorithmIdentifier(paramInt, localAlgorithmParameters);
    }

    public AlgorithmIdentifier getAlgorithmIdentifier()
    {
      return this.algorithmIdentifier;
    }

    public OutputStream getOutputStream(OutputStream paramOutputStream)
    {
      return new CipherOutputStream(paramOutputStream, this.cipher);
    }

    public GenericKey getKey()
    {
      return new GenericKey(this.encKey);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.jcajce.JceCRMFEncryptorBuilder
 * JD-Core Version:    0.6.0
 */