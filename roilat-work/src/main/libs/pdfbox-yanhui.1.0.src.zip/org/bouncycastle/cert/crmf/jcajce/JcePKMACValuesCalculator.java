package org.bouncycastle.cert.crmf.jcajce;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.Provider;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cert.crmf.CRMFException;
import org.bouncycastle.cert.crmf.PKMACValuesCalculator;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;

public class JcePKMACValuesCalculator
  implements PKMACValuesCalculator
{
  private MessageDigest digest;
  private Mac mac;
  private CRMFHelper helper = new CRMFHelper(new DefaultJcaJceHelper());

  public JcePKMACValuesCalculator setProvider(Provider paramProvider)
  {
    this.helper = new CRMFHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JcePKMACValuesCalculator setProvider(String paramString)
  {
    this.helper = new CRMFHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public void setup(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2)
    throws CRMFException
  {
    this.digest = this.helper.createDigest(paramAlgorithmIdentifier1.getAlgorithm());
    this.mac = this.helper.createMac(paramAlgorithmIdentifier2.getAlgorithm());
  }

  public byte[] calculateDigest(byte[] paramArrayOfByte)
  {
    return this.digest.digest(paramArrayOfByte);
  }

  public byte[] calculateMac(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws CRMFException
  {
    try
    {
      this.mac.init(new SecretKeySpec(paramArrayOfByte1, this.mac.getAlgorithm()));
      return this.mac.doFinal(paramArrayOfByte2);
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CRMFException("failure in setup: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.crmf.jcajce.JcePKMACValuesCalculator
 * JD-Core Version:    0.6.0
 */