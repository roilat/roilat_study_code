package org.bouncycastle.cert.jcajce;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.util.CollectionStore;
import org.bouncycastle.x509.X509AttributeCertificate;

public class JcaAttrCertStore extends CollectionStore
{
  public JcaAttrCertStore(Collection paramCollection)
    throws IOException
  {
    super(convertCerts(paramCollection));
  }

  public JcaAttrCertStore(X509AttributeCertificate paramX509AttributeCertificate)
    throws IOException
  {
    this(Collections.singletonList(paramX509AttributeCertificate));
  }

  private static Collection convertCerts(Collection paramCollection)
    throws IOException
  {
    ArrayList localArrayList = new ArrayList(paramCollection.size());
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if ((localObject instanceof X509AttributeCertificate))
      {
        X509AttributeCertificate localX509AttributeCertificate = (X509AttributeCertificate)localObject;
        localArrayList.add(new JcaX509AttributeCertificateHolder(localX509AttributeCertificate));
      }
      else
      {
        localArrayList.add(localObject);
      }
    }
    return localArrayList;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.jcajce.JcaAttrCertStore
 * JD-Core Version:    0.6.0
 */