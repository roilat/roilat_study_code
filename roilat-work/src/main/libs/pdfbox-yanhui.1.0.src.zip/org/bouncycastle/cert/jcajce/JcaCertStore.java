package org.bouncycastle.cert.jcajce;

import java.io.IOException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.util.CollectionStore;

public class JcaCertStore extends CollectionStore
{
  public JcaCertStore(Collection paramCollection)
    throws CertificateEncodingException
  {
    super(convertCerts(paramCollection));
  }

  private static Collection convertCerts(Collection paramCollection)
    throws CertificateEncodingException
  {
    ArrayList localArrayList = new ArrayList(paramCollection.size());
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if ((localObject instanceof X509Certificate))
      {
        X509Certificate localX509Certificate = (X509Certificate)localObject;
        try
        {
          localArrayList.add(new X509CertificateHolder(localX509Certificate.getEncoded()));
        }
        catch (IOException localIOException)
        {
          throw new CertificateEncodingException("unable to read encoding: " + localIOException.getMessage());
        }
      }
      else
      {
        localArrayList.add((X509CertificateHolder)localObject);
      }
    }
    return localArrayList;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.jcajce.JcaCertStore
 * JD-Core Version:    0.6.0
 */