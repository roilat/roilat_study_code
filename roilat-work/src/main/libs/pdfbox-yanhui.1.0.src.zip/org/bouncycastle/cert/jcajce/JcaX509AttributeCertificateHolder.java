package org.bouncycastle.cert.jcajce;

import java.io.IOException;
import org.bouncycastle.asn1.x509.AttributeCertificate;
import org.bouncycastle.cert.X509AttributeCertificateHolder;
import org.bouncycastle.x509.X509AttributeCertificate;

public class JcaX509AttributeCertificateHolder extends X509AttributeCertificateHolder
{
  public JcaX509AttributeCertificateHolder(X509AttributeCertificate paramX509AttributeCertificate)
    throws IOException
  {
    super(AttributeCertificate.getInstance(paramX509AttributeCertificate.getEncoded()));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.jcajce.JcaX509AttributeCertificateHolder
 * JD-Core Version:    0.6.0
 */