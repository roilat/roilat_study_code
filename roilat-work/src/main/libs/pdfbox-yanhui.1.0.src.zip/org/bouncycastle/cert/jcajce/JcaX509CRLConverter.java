package org.bouncycastle.cert.jcajce;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.cert.CRLException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import org.bouncycastle.cert.X509CRLHolder;

public class JcaX509CRLConverter
{
  private CertHelper helper = new DefaultCertHelper();

  public JcaX509CRLConverter setProvider(Provider paramProvider)
  {
    this.helper = new ProviderCertHelper(paramProvider);
    return this;
  }

  public JcaX509CRLConverter setProvider(String paramString)
  {
    this.helper = new NamedCertHelper(paramString);
    return this;
  }

  public X509CRL getCRL(X509CRLHolder paramX509CRLHolder)
    throws CRLException
  {
    try
    {
      CertificateFactory localCertificateFactory = this.helper.getCertificateFactory("X.509");
      return (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(paramX509CRLHolder.getEncoded()));
    }
    catch (IOException localIOException)
    {
      throw new ExCRLException("exception parsing certificate: " + localIOException.getMessage(), localIOException);
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
      throw new ExCRLException("cannot find required provider:" + localNoSuchProviderException.getMessage(), localNoSuchProviderException);
    }
    catch (CertificateException localCertificateException)
    {
    }
    throw new ExCRLException("cannot create factory: " + localCertificateException.getMessage(), localCertificateException);
  }

  private class ExCRLException extends CRLException
  {
    private Throwable cause;

    public ExCRLException(String paramThrowable, Throwable arg3)
    {
      super();
      Object localObject;
      this.cause = localObject;
    }

    public Throwable getCause()
    {
      return this.cause;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.jcajce.JcaX509CRLConverter
 * JD-Core Version:    0.6.0
 */