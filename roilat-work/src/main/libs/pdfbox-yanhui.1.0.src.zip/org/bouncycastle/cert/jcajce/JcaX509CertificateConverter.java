package org.bouncycastle.cert.jcajce;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import org.bouncycastle.cert.X509CertificateHolder;

public class JcaX509CertificateConverter
{
  private CertHelper helper = new DefaultCertHelper();

  public JcaX509CertificateConverter setProvider(Provider paramProvider)
  {
    this.helper = new ProviderCertHelper(paramProvider);
    return this;
  }

  public JcaX509CertificateConverter setProvider(String paramString)
  {
    this.helper = new NamedCertHelper(paramString);
    return this;
  }

  public X509Certificate getCertificate(X509CertificateHolder paramX509CertificateHolder)
    throws CertificateException
  {
    try
    {
      CertificateFactory localCertificateFactory = this.helper.getCertificateFactory("X.509");
      return (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(paramX509CertificateHolder.getEncoded()));
    }
    catch (IOException localIOException)
    {
      throw new ExCertificateParsingException("exception parsing certificate: " + localIOException.getMessage(), localIOException);
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
    }
    throw new ExCertificateException("cannot find required provider:" + localNoSuchProviderException.getMessage(), localNoSuchProviderException);
  }

  private class ExCertificateException extends CertificateException
  {
    private Throwable cause;

    public ExCertificateException(String paramThrowable, Throwable arg3)
    {
      super();
      Object localObject;
      this.cause = localObject;
    }

    public Throwable getCause()
    {
      return this.cause;
    }
  }

  private class ExCertificateParsingException extends CertificateParsingException
  {
    private Throwable cause;

    public ExCertificateParsingException(String paramThrowable, Throwable arg3)
    {
      super();
      Object localObject;
      this.cause = localObject;
    }

    public Throwable getCause()
    {
      return this.cause;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
 * JD-Core Version:    0.6.0
 */