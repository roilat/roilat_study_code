package org.bouncycastle.cert.jcajce;

import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;

class NamedCertHelper extends CertHelper
{
  private final String providerName;

  NamedCertHelper(String paramString)
  {
    this.providerName = paramString;
  }

  protected CertificateFactory createCertificateFactory(String paramString)
    throws CertificateException, NoSuchProviderException
  {
    return CertificateFactory.getInstance(paramString, this.providerName);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.jcajce.NamedCertHelper
 * JD-Core Version:    0.6.0
 */