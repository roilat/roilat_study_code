package org.bouncycastle.cert.jcajce;

import java.security.Provider;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;

class ProviderCertHelper extends CertHelper
{
  private final Provider provider;

  ProviderCertHelper(Provider paramProvider)
  {
    this.provider = paramProvider;
  }

  protected CertificateFactory createCertificateFactory(String paramString)
    throws CertificateException
  {
    return CertificateFactory.getInstance(paramString, this.provider);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.jcajce.ProviderCertHelper
 * JD-Core Version:    0.6.0
 */