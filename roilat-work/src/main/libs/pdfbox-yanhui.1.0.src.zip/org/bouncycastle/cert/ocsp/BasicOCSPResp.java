package org.bouncycastle.cert.ocsp;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.ocsp.BasicOCSPResponse;
import org.bouncycastle.asn1.ocsp.ResponseData;
import org.bouncycastle.asn1.ocsp.SingleResponse;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;

public class BasicOCSPResp
{
  private BasicOCSPResponse resp;
  private ResponseData data;
  private X509Extensions extensions;

  public BasicOCSPResp(BasicOCSPResponse paramBasicOCSPResponse)
  {
    this.resp = paramBasicOCSPResponse;
    this.data = paramBasicOCSPResponse.getTbsResponseData();
    this.extensions = paramBasicOCSPResponse.getTbsResponseData().getResponseExtensions();
  }

  public byte[] getTBSResponseData()
  {
    return this.resp.getTbsResponseData().getDEREncoded();
  }

  public int getVersion()
  {
    return this.data.getVersion().getValue().intValue() + 1;
  }

  public RespID getResponderId()
  {
    return new RespID(this.data.getResponderID());
  }

  public Date getProducedAt()
  {
    return OCSPUtils.extractDate(this.data.getProducedAt());
  }

  public SingleResp[] getResponses()
  {
    ASN1Sequence localASN1Sequence = this.data.getResponses();
    SingleResp[] arrayOfSingleResp = new SingleResp[localASN1Sequence.size()];
    for (int i = 0; i != arrayOfSingleResp.length; i++)
      arrayOfSingleResp[i] = new SingleResp(SingleResponse.getInstance(localASN1Sequence.getObjectAt(i)));
    return arrayOfSingleResp;
  }

  public boolean hasExtensions()
  {
    return this.extensions != null;
  }

  public X509Extension getExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    if (this.extensions != null)
      return this.extensions.getExtension(paramASN1ObjectIdentifier);
    return null;
  }

  public List getExtensionOIDs()
  {
    return OCSPUtils.getExtensionOIDs(this.extensions);
  }

  public Set getCriticalExtensionOIDs()
  {
    return OCSPUtils.getCriticalExtensionOIDs(this.extensions);
  }

  public Set getNonCriticalExtensionOIDs()
  {
    return OCSPUtils.getNonCriticalExtensionOIDs(this.extensions);
  }

  public ASN1ObjectIdentifier getSignatureAlgOID()
  {
    return this.resp.getSignatureAlgorithm().getAlgorithm();
  }

  public byte[] getSignature()
  {
    return this.resp.getSignature().getBytes();
  }

  public X509CertificateHolder[] getCerts()
  {
    if (this.resp.getCerts() != null)
    {
      ASN1Sequence localASN1Sequence = this.resp.getCerts();
      if (localASN1Sequence != null)
      {
        X509CertificateHolder[] arrayOfX509CertificateHolder = new X509CertificateHolder[localASN1Sequence.size()];
        for (int i = 0; i != arrayOfX509CertificateHolder.length; i++)
          arrayOfX509CertificateHolder[i] = new X509CertificateHolder(X509CertificateStructure.getInstance(localASN1Sequence.getObjectAt(i)));
        return arrayOfX509CertificateHolder;
      }
      return OCSPUtils.EMPTY_CERTS;
    }
    return OCSPUtils.EMPTY_CERTS;
  }

  public boolean isSignatureValid(ContentVerifierProvider paramContentVerifierProvider)
    throws OCSPException
  {
    try
    {
      ContentVerifier localContentVerifier = paramContentVerifierProvider.get(this.resp.getSignatureAlgorithm());
      OutputStream localOutputStream = localContentVerifier.getOutputStream();
      localOutputStream.write(this.resp.getTbsResponseData().getDEREncoded());
      localOutputStream.close();
      return localContentVerifier.verify(getSignature());
    }
    catch (Exception localException)
    {
    }
    throw new OCSPException("exception processing sig: " + localException, localException);
  }

  public byte[] getEncoded()
    throws IOException
  {
    return this.resp.getEncoded();
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof BasicOCSPResp))
      return false;
    BasicOCSPResp localBasicOCSPResp = (BasicOCSPResp)paramObject;
    return this.resp.equals(localBasicOCSPResp.resp);
  }

  public int hashCode()
  {
    return this.resp.hashCode();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.BasicOCSPResp
 * JD-Core Version:    0.6.0
 */