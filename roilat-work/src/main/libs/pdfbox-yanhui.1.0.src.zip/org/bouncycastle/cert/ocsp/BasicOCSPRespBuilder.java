package org.bouncycastle.cert.ocsp;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.ocsp.BasicOCSPResponse;
import org.bouncycastle.asn1.ocsp.CertStatus;
import org.bouncycastle.asn1.ocsp.ResponseData;
import org.bouncycastle.asn1.ocsp.RevokedInfo;
import org.bouncycastle.asn1.ocsp.SingleResponse;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.CRLReason;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.DigestCalculator;

public class BasicOCSPRespBuilder
{
  private List list = new ArrayList();
  private X509Extensions responseExtensions = null;
  private RespID responderID;

  public BasicOCSPRespBuilder(RespID paramRespID)
  {
    this.responderID = paramRespID;
  }

  public BasicOCSPRespBuilder(SubjectPublicKeyInfo paramSubjectPublicKeyInfo, DigestCalculator paramDigestCalculator)
    throws OCSPException
  {
    this.responderID = new RespID(paramSubjectPublicKeyInfo, paramDigestCalculator);
  }

  public BasicOCSPRespBuilder addResponse(CertificateID paramCertificateID, CertificateStatus paramCertificateStatus)
  {
    this.list.add(new ResponseObject(paramCertificateID, paramCertificateStatus, new Date(), null, null));
    return this;
  }

  public BasicOCSPRespBuilder addResponse(CertificateID paramCertificateID, CertificateStatus paramCertificateStatus, X509Extensions paramX509Extensions)
  {
    this.list.add(new ResponseObject(paramCertificateID, paramCertificateStatus, new Date(), null, paramX509Extensions));
    return this;
  }

  public BasicOCSPRespBuilder addResponse(CertificateID paramCertificateID, CertificateStatus paramCertificateStatus, Date paramDate, X509Extensions paramX509Extensions)
  {
    this.list.add(new ResponseObject(paramCertificateID, paramCertificateStatus, new Date(), paramDate, paramX509Extensions));
    return this;
  }

  public BasicOCSPRespBuilder addResponse(CertificateID paramCertificateID, CertificateStatus paramCertificateStatus, Date paramDate1, Date paramDate2, X509Extensions paramX509Extensions)
  {
    this.list.add(new ResponseObject(paramCertificateID, paramCertificateStatus, paramDate1, paramDate2, paramX509Extensions));
    return this;
  }

  public BasicOCSPRespBuilder setResponseExtensions(X509Extensions paramX509Extensions)
  {
    this.responseExtensions = paramX509Extensions;
    return this;
  }

  public BasicOCSPResp build(ContentSigner paramContentSigner, X509CertificateHolder[] paramArrayOfX509CertificateHolder, Date paramDate)
    throws OCSPException
  {
    Iterator localIterator = this.list.iterator();
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    while (localIterator.hasNext())
      try
      {
        localASN1EncodableVector1.add(((ResponseObject)localIterator.next()).toResponse());
      }
      catch (Exception localException1)
      {
        throw new OCSPException("exception creating Request", localException1);
      }
    ResponseData localResponseData = new ResponseData(this.responderID.toASN1Object(), new DERGeneralizedTime(paramDate), new DERSequence(localASN1EncodableVector1), this.responseExtensions);
    DERBitString localDERBitString;
    try
    {
      OutputStream localOutputStream = paramContentSigner.getOutputStream();
      localOutputStream.write(localResponseData.getEncoded("DER"));
      localOutputStream.close();
      localDERBitString = new DERBitString(paramContentSigner.getSignature());
    }
    catch (Exception localException2)
    {
      throw new OCSPException("exception processing TBSRequest: " + localException2.getMessage(), localException2);
    }
    AlgorithmIdentifier localAlgorithmIdentifier = paramContentSigner.getAlgorithmIdentifier();
    DERSequence localDERSequence = null;
    if ((paramArrayOfX509CertificateHolder != null) && (paramArrayOfX509CertificateHolder.length > 0))
    {
      ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
      for (int i = 0; i != paramArrayOfX509CertificateHolder.length; i++)
        localASN1EncodableVector2.add(paramArrayOfX509CertificateHolder[i].toASN1Structure());
      localDERSequence = new DERSequence(localASN1EncodableVector2);
    }
    return new BasicOCSPResp(new BasicOCSPResponse(localResponseData, localAlgorithmIdentifier, localDERBitString, localDERSequence));
  }

  private class ResponseObject
  {
    CertificateID certId;
    CertStatus certStatus;
    DERGeneralizedTime thisUpdate;
    DERGeneralizedTime nextUpdate;
    X509Extensions extensions;

    public ResponseObject(CertificateID paramCertificateStatus, CertificateStatus paramDate1, Date paramDate2, Date paramX509Extensions, X509Extensions arg6)
    {
      this.certId = paramCertificateStatus;
      if (paramDate1 == null)
      {
        this.certStatus = new CertStatus();
      }
      else if ((paramDate1 instanceof UnknownStatus))
      {
        this.certStatus = new CertStatus(2, new DERNull());
      }
      else
      {
        RevokedStatus localRevokedStatus = (RevokedStatus)paramDate1;
        if (localRevokedStatus.hasRevocationReason())
          this.certStatus = new CertStatus(new RevokedInfo(new DERGeneralizedTime(localRevokedStatus.getRevocationTime()), new CRLReason(localRevokedStatus.getRevocationReason())));
        else
          this.certStatus = new CertStatus(new RevokedInfo(new DERGeneralizedTime(localRevokedStatus.getRevocationTime()), null));
      }
      this.thisUpdate = new DERGeneralizedTime(paramDate2);
      if (paramX509Extensions != null)
        this.nextUpdate = new DERGeneralizedTime(paramX509Extensions);
      else
        this.nextUpdate = null;
      Object localObject;
      this.extensions = localObject;
    }

    public SingleResponse toResponse()
      throws Exception
    {
      return new SingleResponse(this.certId.toASN1Object(), this.certStatus, this.thisUpdate, this.nextUpdate, this.extensions);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.BasicOCSPRespBuilder
 * JD-Core Version:    0.6.0
 */