package org.bouncycastle.cert.ocsp;

public class OCSPException extends Exception
{
  private Throwable cause;

  public OCSPException(String paramString)
  {
    super(paramString);
  }

  public OCSPException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    this.cause = paramThrowable;
  }

  public Throwable getCause()
  {
    return this.cause;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.OCSPException
 * JD-Core Version:    0.6.0
 */