package org.bouncycastle.cert.ocsp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.List;
import java.util.Set;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OutputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.ocsp.OCSPRequest;
import org.bouncycastle.asn1.ocsp.Request;
import org.bouncycastle.asn1.ocsp.Signature;
import org.bouncycastle.asn1.ocsp.TBSRequest;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.cert.CertIOException;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;

public class OCSPReq
{
  private static final X509CertificateHolder[] EMPTY_CERTS = new X509CertificateHolder[0];
  private OCSPRequest req;
  private X509Extensions extensions;

  public OCSPReq(OCSPRequest paramOCSPRequest)
  {
    this.req = paramOCSPRequest;
    this.extensions = paramOCSPRequest.getTbsRequest().getRequestExtensions();
  }

  public OCSPReq(byte[] paramArrayOfByte)
    throws IOException
  {
    this(new ASN1InputStream(paramArrayOfByte));
  }

  private OCSPReq(ASN1InputStream paramASN1InputStream)
    throws IOException
  {
    try
    {
      this.req = OCSPRequest.getInstance(paramASN1InputStream.readObject());
      this.extensions = this.req.getTbsRequest().getRequestExtensions();
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new CertIOException("malformed request: " + localIllegalArgumentException.getMessage(), localIllegalArgumentException);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CertIOException("malformed request: " + localClassCastException.getMessage(), localClassCastException);
    }
  }

  public int getVersion()
  {
    return this.req.getTbsRequest().getVersion().getValue().intValue() + 1;
  }

  public GeneralName getRequestorName()
  {
    return GeneralName.getInstance(this.req.getTbsRequest().getRequestorName());
  }

  public Req[] getRequestList()
  {
    ASN1Sequence localASN1Sequence = this.req.getTbsRequest().getRequestList();
    Req[] arrayOfReq = new Req[localASN1Sequence.size()];
    for (int i = 0; i != arrayOfReq.length; i++)
      arrayOfReq[i] = new Req(Request.getInstance(localASN1Sequence.getObjectAt(i)));
    return arrayOfReq;
  }

  public boolean hasExtensions()
  {
    return this.extensions != null;
  }

  public X509Extension getExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    if (this.extensions != null)
      return this.extensions.getExtension(paramASN1ObjectIdentifier);
    return null;
  }

  public List getExtensionOIDs()
  {
    return OCSPUtils.getExtensionOIDs(this.extensions);
  }

  public Set getCriticalExtensionOIDs()
  {
    return OCSPUtils.getCriticalExtensionOIDs(this.extensions);
  }

  public Set getNonCriticalExtensionOIDs()
  {
    return OCSPUtils.getNonCriticalExtensionOIDs(this.extensions);
  }

  public ASN1ObjectIdentifier getSignatureAlgOID()
  {
    if (!isSigned())
      return null;
    return this.req.getOptionalSignature().getSignatureAlgorithm().getAlgorithm();
  }

  public byte[] getSignature()
  {
    if (!isSigned())
      return null;
    return this.req.getOptionalSignature().getSignature().getBytes();
  }

  public X509CertificateHolder[] getCerts()
  {
    if (this.req.getOptionalSignature() != null)
    {
      ASN1Sequence localASN1Sequence = this.req.getOptionalSignature().getCerts();
      if (localASN1Sequence != null)
      {
        X509CertificateHolder[] arrayOfX509CertificateHolder = new X509CertificateHolder[localASN1Sequence.size()];
        for (int i = 0; i != arrayOfX509CertificateHolder.length; i++)
          arrayOfX509CertificateHolder[i] = new X509CertificateHolder(X509CertificateStructure.getInstance(localASN1Sequence.getObjectAt(i)));
        return arrayOfX509CertificateHolder;
      }
      return EMPTY_CERTS;
    }
    return EMPTY_CERTS;
  }

  public boolean isSigned()
  {
    return this.req.getOptionalSignature() != null;
  }

  public boolean isSignatureValid(ContentVerifierProvider paramContentVerifierProvider)
    throws OCSPException
  {
    if (!isSigned())
      throw new OCSPException("attempt to verify signature on unsigned object");
    try
    {
      ContentVerifier localContentVerifier = paramContentVerifierProvider.get(this.req.getOptionalSignature().getSignatureAlgorithm());
      OutputStream localOutputStream = localContentVerifier.getOutputStream();
      localOutputStream.write(this.req.getTbsRequest().getDEREncoded());
      return localContentVerifier.verify(getSignature());
    }
    catch (Exception localException)
    {
    }
    throw new OCSPException("exception processing signature: " + localException, localException);
  }

  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(this.req);
    return localByteArrayOutputStream.toByteArray();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.OCSPReq
 * JD-Core Version:    0.6.0
 */