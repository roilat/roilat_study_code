package org.bouncycastle.cert.ocsp;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.ocsp.OCSPRequest;
import org.bouncycastle.asn1.ocsp.Request;
import org.bouncycastle.asn1.ocsp.Signature;
import org.bouncycastle.asn1.ocsp.TBSRequest;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.ContentSigner;

public class OCSPReqBuilder
{
  private List list = new ArrayList();
  private GeneralName requestorName = null;
  private X509Extensions requestExtensions = null;

  public OCSPReqBuilder addRequest(CertificateID paramCertificateID)
  {
    this.list.add(new RequestObject(paramCertificateID, null));
    return this;
  }

  public OCSPReqBuilder addRequest(CertificateID paramCertificateID, X509Extensions paramX509Extensions)
  {
    this.list.add(new RequestObject(paramCertificateID, paramX509Extensions));
    return this;
  }

  public OCSPReqBuilder setRequestorName(X500Name paramX500Name)
  {
    this.requestorName = new GeneralName(4, paramX500Name);
    return this;
  }

  public OCSPReqBuilder setRequestorName(GeneralName paramGeneralName)
  {
    this.requestorName = paramGeneralName;
    return this;
  }

  public OCSPReqBuilder setRequestExtensions(X509Extensions paramX509Extensions)
  {
    this.requestExtensions = paramX509Extensions;
    return this;
  }

  private OCSPReq generateRequest(ContentSigner paramContentSigner, X509CertificateHolder[] paramArrayOfX509CertificateHolder)
    throws OCSPException
  {
    Iterator localIterator = this.list.iterator();
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    while (localIterator.hasNext())
      try
      {
        localASN1EncodableVector1.add(((RequestObject)localIterator.next()).toRequest());
      }
      catch (Exception localException1)
      {
        throw new OCSPException("exception creating Request", localException1);
      }
    TBSRequest localTBSRequest = new TBSRequest(this.requestorName, new DERSequence(localASN1EncodableVector1), this.requestExtensions);
    Signature localSignature = null;
    if (paramContentSigner != null)
    {
      if (this.requestorName == null)
        throw new OCSPException("requestorName must be specified if request is signed.");
      try
      {
        OutputStream localOutputStream = paramContentSigner.getOutputStream();
        localOutputStream.write(localTBSRequest.getDEREncoded());
        localOutputStream.close();
      }
      catch (Exception localException2)
      {
        throw new OCSPException("exception processing TBSRequest: " + localException2, localException2);
      }
      DERBitString localDERBitString = new DERBitString(paramContentSigner.getSignature());
      AlgorithmIdentifier localAlgorithmIdentifier = paramContentSigner.getAlgorithmIdentifier();
      if ((paramArrayOfX509CertificateHolder != null) && (paramArrayOfX509CertificateHolder.length > 0))
      {
        ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
        for (int i = 0; i != paramArrayOfX509CertificateHolder.length; i++)
          localASN1EncodableVector2.add(paramArrayOfX509CertificateHolder[i].toASN1Structure());
        localSignature = new Signature(localAlgorithmIdentifier, localDERBitString, new DERSequence(localASN1EncodableVector2));
      }
      else
      {
        localSignature = new Signature(localAlgorithmIdentifier, localDERBitString);
      }
    }
    return new OCSPReq(new OCSPRequest(localTBSRequest, localSignature));
  }

  public OCSPReq build()
    throws OCSPException
  {
    return generateRequest(null, null);
  }

  public OCSPReq build(ContentSigner paramContentSigner, X509CertificateHolder[] paramArrayOfX509CertificateHolder)
    throws OCSPException, IllegalArgumentException
  {
    if (paramContentSigner == null)
      throw new IllegalArgumentException("no signer specified");
    return generateRequest(paramContentSigner, paramArrayOfX509CertificateHolder);
  }

  private class RequestObject
  {
    CertificateID certId;
    X509Extensions extensions;

    public RequestObject(CertificateID paramX509Extensions, X509Extensions arg3)
    {
      this.certId = paramX509Extensions;
      Object localObject;
      this.extensions = localObject;
    }

    public Request toRequest()
      throws Exception
    {
      return new Request(this.certId.toASN1Object(), this.extensions);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.OCSPReqBuilder
 * JD-Core Version:    0.6.0
 */