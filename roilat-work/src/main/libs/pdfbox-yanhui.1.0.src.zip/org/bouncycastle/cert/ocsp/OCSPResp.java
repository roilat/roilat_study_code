package org.bouncycastle.cert.ocsp;

import java.io.IOException;
import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.ocsp.BasicOCSPResponse;
import org.bouncycastle.asn1.ocsp.OCSPObjectIdentifiers;
import org.bouncycastle.asn1.ocsp.OCSPResponse;
import org.bouncycastle.asn1.ocsp.OCSPResponseStatus;
import org.bouncycastle.asn1.ocsp.ResponseBytes;
import org.bouncycastle.cert.CertIOException;

public class OCSPResp
{
  private OCSPResponse resp;

  public OCSPResp(OCSPResponse paramOCSPResponse)
  {
    this.resp = paramOCSPResponse;
  }

  public OCSPResp(byte[] paramArrayOfByte)
    throws IOException
  {
    this(new ASN1InputStream(paramArrayOfByte));
  }

  private OCSPResp(ASN1InputStream paramASN1InputStream)
    throws IOException
  {
    try
    {
      this.resp = OCSPResponse.getInstance(paramASN1InputStream.readObject());
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new CertIOException("malformed response: " + localIllegalArgumentException.getMessage(), localIllegalArgumentException);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CertIOException("malformed response: " + localClassCastException.getMessage(), localClassCastException);
    }
  }

  public int getStatus()
  {
    return this.resp.getResponseStatus().getValue().intValue();
  }

  public Object getResponseObject()
    throws OCSPException
  {
    ResponseBytes localResponseBytes = this.resp.getResponseBytes();
    if (localResponseBytes == null)
      return null;
    if (localResponseBytes.getResponseType().equals(OCSPObjectIdentifiers.id_pkix_ocsp_basic))
      try
      {
        ASN1Object localASN1Object = ASN1Object.fromByteArray(localResponseBytes.getResponse().getOctets());
        return new BasicOCSPResp(BasicOCSPResponse.getInstance(localASN1Object));
      }
      catch (Exception localException)
      {
        throw new OCSPException("problem decoding object: " + localException, localException);
      }
    return localResponseBytes.getResponse();
  }

  public byte[] getEncoded()
    throws IOException
  {
    return this.resp.getEncoded();
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof OCSPResp))
      return false;
    OCSPResp localOCSPResp = (OCSPResp)paramObject;
    return this.resp.equals(localOCSPResp.resp);
  }

  public int hashCode()
  {
    return this.resp.hashCode();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.OCSPResp
 * JD-Core Version:    0.6.0
 */