package org.bouncycastle.cert.ocsp;

import java.io.IOException;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.ocsp.OCSPObjectIdentifiers;
import org.bouncycastle.asn1.ocsp.OCSPResponse;
import org.bouncycastle.asn1.ocsp.OCSPResponseStatus;
import org.bouncycastle.asn1.ocsp.ResponseBytes;

public class OCSPRespBuilder
{
  public static final int SUCCESSFUL = 0;
  public static final int MALFORMED_REQUEST = 1;
  public static final int INTERNAL_ERROR = 2;
  public static final int TRY_LATER = 3;
  public static final int SIG_REQUIRED = 5;
  public static final int UNAUTHORIZED = 6;

  public OCSPResp build(int paramInt, Object paramObject)
    throws OCSPException
  {
    if (paramObject == null)
      return new OCSPResp(new OCSPResponse(new OCSPResponseStatus(paramInt), null));
    if ((paramObject instanceof BasicOCSPResp))
    {
      BasicOCSPResp localBasicOCSPResp = (BasicOCSPResp)paramObject;
      DEROctetString localDEROctetString;
      try
      {
        localDEROctetString = new DEROctetString(localBasicOCSPResp.getEncoded());
      }
      catch (IOException localIOException)
      {
        throw new OCSPException("can't encode object.", localIOException);
      }
      ResponseBytes localResponseBytes = new ResponseBytes(OCSPObjectIdentifiers.id_pkix_ocsp_basic, localDEROctetString);
      return new OCSPResp(new OCSPResponse(new OCSPResponseStatus(paramInt), localResponseBytes));
    }
    throw new OCSPException("unknown response object");
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.OCSPRespBuilder
 * JD-Core Version:    0.6.0
 */