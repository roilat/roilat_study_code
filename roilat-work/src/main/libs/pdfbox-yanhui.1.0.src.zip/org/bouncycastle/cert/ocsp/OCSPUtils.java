package org.bouncycastle.cert.ocsp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.cert.X509CertificateHolder;

class OCSPUtils
{
  static final X509CertificateHolder[] EMPTY_CERTS = new X509CertificateHolder[0];
  static Set EMPTY_SET = Collections.unmodifiableSet(new HashSet());
  static List EMPTY_LIST = Collections.unmodifiableList(new ArrayList());

  static Date extractDate(DERGeneralizedTime paramDERGeneralizedTime)
  {
    try
    {
      return paramDERGeneralizedTime.getDate();
    }
    catch (Exception localException)
    {
    }
    throw new IllegalStateException("exception processing GeneralizedTime: " + localException.getMessage());
  }

  static Set getCriticalExtensionOIDs(X509Extensions paramX509Extensions)
  {
    if (paramX509Extensions == null)
      return EMPTY_SET;
    return Collections.unmodifiableSet(new HashSet(Arrays.asList(paramX509Extensions.getCriticalExtensionOIDs())));
  }

  static Set getNonCriticalExtensionOIDs(X509Extensions paramX509Extensions)
  {
    if (paramX509Extensions == null)
      return EMPTY_SET;
    return Collections.unmodifiableSet(new HashSet(Arrays.asList(paramX509Extensions.getNonCriticalExtensionOIDs())));
  }

  static List getExtensionOIDs(X509Extensions paramX509Extensions)
  {
    if (paramX509Extensions == null)
      return EMPTY_LIST;
    return Collections.unmodifiableList(Arrays.asList(paramX509Extensions.getExtensionOIDs()));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.OCSPUtils
 * JD-Core Version:    0.6.0
 */