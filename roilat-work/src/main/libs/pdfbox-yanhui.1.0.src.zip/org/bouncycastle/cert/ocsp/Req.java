package org.bouncycastle.cert.ocsp;

import org.bouncycastle.asn1.ocsp.Request;
import org.bouncycastle.asn1.x509.X509Extensions;

public class Req
{
  private Request req;

  public Req(Request paramRequest)
  {
    this.req = paramRequest;
  }

  public CertificateID getCertID()
  {
    return new CertificateID(this.req.getReqCert());
  }

  public X509Extensions getSingleRequestExtensions()
  {
    return this.req.getSingleRequestExtensions();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.Req
 * JD-Core Version:    0.6.0
 */