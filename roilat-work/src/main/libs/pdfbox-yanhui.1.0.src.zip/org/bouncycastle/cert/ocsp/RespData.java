package org.bouncycastle.cert.ocsp;

import java.math.BigInteger;
import java.util.Date;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.ocsp.ResponseData;
import org.bouncycastle.asn1.ocsp.SingleResponse;
import org.bouncycastle.asn1.x509.X509Extensions;

public class RespData
{
  private ResponseData data;

  public RespData(ResponseData paramResponseData)
  {
    this.data = paramResponseData;
  }

  public int getVersion()
  {
    return this.data.getVersion().getValue().intValue() + 1;
  }

  public RespID getResponderId()
  {
    return new RespID(this.data.getResponderID());
  }

  public Date getProducedAt()
  {
    return OCSPUtils.extractDate(this.data.getProducedAt());
  }

  public SingleResp[] getResponses()
  {
    ASN1Sequence localASN1Sequence = this.data.getResponses();
    SingleResp[] arrayOfSingleResp = new SingleResp[localASN1Sequence.size()];
    for (int i = 0; i != arrayOfSingleResp.length; i++)
      arrayOfSingleResp[i] = new SingleResp(SingleResponse.getInstance(localASN1Sequence.getObjectAt(i)));
    return arrayOfSingleResp;
  }

  public X509Extensions getResponseExtensions()
  {
    return this.data.getResponseExtensions();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.RespData
 * JD-Core Version:    0.6.0
 */