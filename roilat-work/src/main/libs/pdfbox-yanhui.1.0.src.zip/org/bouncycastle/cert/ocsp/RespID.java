package org.bouncycastle.cert.ocsp;

import java.io.OutputStream;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.ocsp.ResponderID;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.operator.DigestCalculator;

public class RespID
{
  public static final AlgorithmIdentifier HASH_SHA1 = new AlgorithmIdentifier(OIWObjectIdentifiers.idSHA1, DERNull.INSTANCE);
  ResponderID id;

  public RespID(ResponderID paramResponderID)
  {
    this.id = paramResponderID;
  }

  public RespID(X500Name paramX500Name)
  {
    this.id = new ResponderID(paramX500Name);
  }

  public RespID(SubjectPublicKeyInfo paramSubjectPublicKeyInfo, DigestCalculator paramDigestCalculator)
    throws OCSPException
  {
    try
    {
      if (!paramDigestCalculator.getAlgorithmIdentifier().equals(HASH_SHA1))
        throw new IllegalArgumentException("only SHA-1 can be used with RespID");
      OutputStream localOutputStream = paramDigestCalculator.getOutputStream();
      localOutputStream.write(paramSubjectPublicKeyInfo.getPublicKeyData().getBytes());
      localOutputStream.close();
      this.id = new ResponderID(new DEROctetString(paramDigestCalculator.getDigest()));
    }
    catch (Exception localException)
    {
      throw new OCSPException("problem creating ID: " + localException, localException);
    }
  }

  public ResponderID toASN1Object()
  {
    return this.id;
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof RespID))
      return false;
    RespID localRespID = (RespID)paramObject;
    return this.id.equals(localRespID.id);
  }

  public int hashCode()
  {
    return this.id.hashCode();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.RespID
 * JD-Core Version:    0.6.0
 */