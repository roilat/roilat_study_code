package org.bouncycastle.cert.ocsp;

import java.util.Date;
import java.util.List;
import java.util.Set;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ocsp.CertStatus;
import org.bouncycastle.asn1.ocsp.RevokedInfo;
import org.bouncycastle.asn1.ocsp.SingleResponse;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;

public class SingleResp
{
  private SingleResponse resp;
  private X509Extensions extensions;

  public SingleResp(SingleResponse paramSingleResponse)
  {
    this.resp = paramSingleResponse;
    this.extensions = paramSingleResponse.getSingleExtensions();
  }

  public CertificateID getCertID()
  {
    return new CertificateID(this.resp.getCertID());
  }

  public CertificateStatus getCertStatus()
  {
    CertStatus localCertStatus = this.resp.getCertStatus();
    if (localCertStatus.getTagNo() == 0)
      return null;
    if (localCertStatus.getTagNo() == 1)
      return new RevokedStatus(RevokedInfo.getInstance(localCertStatus.getStatus()));
    return new UnknownStatus();
  }

  public Date getThisUpdate()
  {
    return OCSPUtils.extractDate(this.resp.getThisUpdate());
  }

  public Date getNextUpdate()
  {
    if (this.resp.getNextUpdate() == null)
      return null;
    return OCSPUtils.extractDate(this.resp.getNextUpdate());
  }

  public boolean hasExtensions()
  {
    return this.extensions != null;
  }

  public X509Extension getExtension(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    if (this.extensions != null)
      return this.extensions.getExtension(paramASN1ObjectIdentifier);
    return null;
  }

  public List getExtensionOIDs()
  {
    return OCSPUtils.getExtensionOIDs(this.extensions);
  }

  public Set getCriticalExtensionOIDs()
  {
    return OCSPUtils.getCriticalExtensionOIDs(this.extensions);
  }

  public Set getNonCriticalExtensionOIDs()
  {
    return OCSPUtils.getNonCriticalExtensionOIDs(this.extensions);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.SingleResp
 * JD-Core Version:    0.6.0
 */