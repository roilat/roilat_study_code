package org.bouncycastle.cert.ocsp;

public class UnknownStatus
  implements CertificateStatus
{
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.ocsp.UnknownStatus
 * JD-Core Version:    0.6.0
 */