package org.bouncycastle.cert.selector;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.cert.AttributeCertificateHolder;
import org.bouncycastle.cert.AttributeCertificateIssuer;
import org.bouncycastle.cert.X509AttributeCertificateHolder;

public class X509AttributeCertificateSelectorBuilder
{
  private AttributeCertificateHolder holder;
  private AttributeCertificateIssuer issuer;
  private BigInteger serialNumber;
  private Date attributeCertificateValid;
  private X509AttributeCertificateHolder attributeCert;
  private Collection targetNames = new HashSet();
  private Collection targetGroups = new HashSet();

  public void setAttributeCert(X509AttributeCertificateHolder paramX509AttributeCertificateHolder)
  {
    this.attributeCert = paramX509AttributeCertificateHolder;
  }

  public void setAttributeCertificateValid(Date paramDate)
  {
    if (paramDate != null)
      this.attributeCertificateValid = new Date(paramDate.getTime());
    else
      this.attributeCertificateValid = null;
  }

  public void setHolder(AttributeCertificateHolder paramAttributeCertificateHolder)
  {
    this.holder = paramAttributeCertificateHolder;
  }

  public void setIssuer(AttributeCertificateIssuer paramAttributeCertificateIssuer)
  {
    this.issuer = paramAttributeCertificateIssuer;
  }

  public void setSerialNumber(BigInteger paramBigInteger)
  {
    this.serialNumber = paramBigInteger;
  }

  public void addTargetName(GeneralName paramGeneralName)
  {
    this.targetNames.add(paramGeneralName);
  }

  public void setTargetNames(Collection paramCollection)
    throws IOException
  {
    this.targetNames = extractGeneralNames(paramCollection);
  }

  public void addTargetGroup(GeneralName paramGeneralName)
  {
    this.targetGroups.add(paramGeneralName);
  }

  public void setTargetGroups(Collection paramCollection)
    throws IOException
  {
    this.targetGroups = extractGeneralNames(paramCollection);
  }

  private Set extractGeneralNames(Collection paramCollection)
    throws IOException
  {
    if ((paramCollection == null) || (paramCollection.isEmpty()))
      return new HashSet();
    HashSet localHashSet = new HashSet();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      localHashSet.add(GeneralName.getInstance(localIterator.next()));
    return localHashSet;
  }

  public X509AttributeCertificateSelector build()
  {
    X509AttributeCertificateSelector localX509AttributeCertificateSelector = new X509AttributeCertificateSelector(this.holder, this.issuer, this.serialNumber, this.attributeCertificateValid, this.attributeCert, Collections.unmodifiableCollection(new HashSet(this.targetNames)), Collections.unmodifiableCollection(new HashSet(this.targetGroups)));
    return localX509AttributeCertificateSelector;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cert.selector.X509AttributeCertificateSelectorBuilder
 * JD-Core Version:    0.6.0
 */