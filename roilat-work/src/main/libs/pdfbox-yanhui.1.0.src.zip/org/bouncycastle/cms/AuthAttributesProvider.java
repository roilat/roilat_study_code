package org.bouncycastle.cms;

import org.bouncycastle.asn1.ASN1Set;

abstract interface AuthAttributesProvider
{
  public abstract ASN1Set getAuthAttributes();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.AuthAttributesProvider
 * JD-Core Version:    0.6.0
 */