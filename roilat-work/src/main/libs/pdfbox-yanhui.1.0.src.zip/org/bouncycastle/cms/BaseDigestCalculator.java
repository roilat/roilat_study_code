package org.bouncycastle.cms;

import org.bouncycastle.util.Arrays;

class BaseDigestCalculator
  implements IntDigestCalculator
{
  private final byte[] digest;

  BaseDigestCalculator(byte[] paramArrayOfByte)
  {
    this.digest = paramArrayOfByte;
  }

  public byte[] getDigest()
  {
    return Arrays.clone(this.digest);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.BaseDigestCalculator
 * JD-Core Version:    0.6.0
 */