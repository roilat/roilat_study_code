package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;

public class CMSAbsentContent
  implements CMSTypedData, CMSReadable
{
  private final ASN1ObjectIdentifier type;

  public CMSAbsentContent()
  {
    this(new ASN1ObjectIdentifier(CMSObjectIdentifiers.data.getId()));
  }

  public CMSAbsentContent(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    this.type = paramASN1ObjectIdentifier;
  }

  public InputStream getInputStream()
  {
    return null;
  }

  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
  }

  public Object getContent()
  {
    return null;
  }

  public ASN1ObjectIdentifier getContentType()
  {
    return this.type;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSAbsentContent
 * JD-Core Version:    0.6.0
 */