package org.bouncycastle.cms;

import java.util.Map;
import org.bouncycastle.asn1.cms.AttributeTable;

public abstract interface CMSAttributeTableGenerator
{
  public static final String CONTENT_TYPE = "contentType";
  public static final String DIGEST = "digest";
  public static final String SIGNATURE = "encryptedDigest";
  public static final String DIGEST_ALGORITHM_IDENTIFIER = "digestAlgID";

  public abstract AttributeTable getAttributes(Map paramMap)
    throws CMSAttributeTableGenerationException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSAttributeTableGenerator
 * JD-Core Version:    0.6.0
 */