package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.security.AlgorithmParameters;
import java.security.NoSuchProviderException;
import java.security.Provider;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.AuthenticatedData;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.util.Arrays;

public class CMSAuthenticatedData
{
  RecipientInformationStore recipientInfoStore;
  ContentInfo contentInfo;
  private AlgorithmIdentifier macAlg;
  private ASN1Set authAttrs;
  private ASN1Set unauthAttrs;
  private byte[] mac;

  public CMSAuthenticatedData(byte[] paramArrayOfByte)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramArrayOfByte));
  }

  public CMSAuthenticatedData(byte[] paramArrayOfByte, DigestCalculatorProvider paramDigestCalculatorProvider)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramArrayOfByte), paramDigestCalculatorProvider);
  }

  public CMSAuthenticatedData(InputStream paramInputStream)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramInputStream));
  }

  public CMSAuthenticatedData(InputStream paramInputStream, DigestCalculatorProvider paramDigestCalculatorProvider)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramInputStream), paramDigestCalculatorProvider);
  }

  public CMSAuthenticatedData(ContentInfo paramContentInfo)
    throws CMSException
  {
    this(paramContentInfo, null);
  }

  public CMSAuthenticatedData(ContentInfo paramContentInfo, DigestCalculatorProvider paramDigestCalculatorProvider)
    throws CMSException
  {
    this.contentInfo = paramContentInfo;
    AuthenticatedData localAuthenticatedData = AuthenticatedData.getInstance(paramContentInfo.getContent());
    ASN1Set localASN1Set = localAuthenticatedData.getRecipientInfos();
    this.macAlg = localAuthenticatedData.getMacAlgorithm();
    this.authAttrs = localAuthenticatedData.getAuthAttrs();
    this.mac = localAuthenticatedData.getMac().getOctets();
    this.unauthAttrs = localAuthenticatedData.getUnauthAttrs();
    ContentInfo localContentInfo = localAuthenticatedData.getEncapsulatedContentInfo();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray(ASN1OctetString.getInstance(localContentInfo.getContent()).getOctets());
    if (this.authAttrs != null)
    {
      if (paramDigestCalculatorProvider == null)
        throw new CMSException("a digest calculator provider is required if authenticated attributes are present");
      try
      {
        CMSEnvelopedHelper.CMSDigestAuthenticatedSecureReadable localCMSDigestAuthenticatedSecureReadable = new CMSEnvelopedHelper.CMSDigestAuthenticatedSecureReadable(paramDigestCalculatorProvider.get(localAuthenticatedData.getDigestAlgorithm()), localCMSProcessableByteArray);
        this.recipientInfoStore = CMSEnvelopedHelper.buildRecipientInformationStore(localASN1Set, this.macAlg, localCMSDigestAuthenticatedSecureReadable, new AuthAttributesProvider()
        {
          public ASN1Set getAuthAttributes()
          {
            return CMSAuthenticatedData.this.authAttrs;
          }
        });
      }
      catch (OperatorCreationException localOperatorCreationException)
      {
        throw new CMSException("unable to create digest calculator: " + localOperatorCreationException.getMessage(), localOperatorCreationException);
      }
    }
    else
    {
      CMSEnvelopedHelper.CMSAuthenticatedSecureReadable localCMSAuthenticatedSecureReadable = new CMSEnvelopedHelper.CMSAuthenticatedSecureReadable(this.macAlg, localCMSProcessableByteArray);
      this.recipientInfoStore = CMSEnvelopedHelper.buildRecipientInformationStore(localASN1Set, this.macAlg, localCMSAuthenticatedSecureReadable);
    }
  }

  public byte[] getMac()
  {
    return Arrays.clone(this.mac);
  }

  private byte[] encodeObj(DEREncodable paramDEREncodable)
    throws IOException
  {
    if (paramDEREncodable != null)
      return paramDEREncodable.getDERObject().getEncoded();
    return null;
  }

  public String getMacAlgOID()
  {
    return this.macAlg.getObjectId().getId();
  }

  public byte[] getMacAlgParams()
  {
    try
    {
      return encodeObj(this.macAlg.getParameters());
    }
    catch (Exception localException)
    {
    }
    throw new RuntimeException("exception getting encryption parameters " + localException);
  }

  public AlgorithmParameters getMacAlgorithmParameters(String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getMacAlgorithmParameters(CMSUtils.getProvider(paramString));
  }

  public AlgorithmParameters getMacAlgorithmParameters(Provider paramProvider)
    throws CMSException
  {
    return CMSEnvelopedHelper.INSTANCE.getEncryptionAlgorithmParameters(getMacAlgOID(), getMacAlgParams(), paramProvider);
  }

  public RecipientInformationStore getRecipientInfos()
  {
    return this.recipientInfoStore;
  }

  public ContentInfo getContentInfo()
  {
    return this.contentInfo;
  }

  public AttributeTable getAuthAttrs()
  {
    if (this.authAttrs == null)
      return null;
    return new AttributeTable(this.authAttrs);
  }

  public AttributeTable getUnauthAttrs()
  {
    if (this.unauthAttrs == null)
      return null;
    return new AttributeTable(this.unauthAttrs);
  }

  public byte[] getEncoded()
    throws IOException
  {
    return this.contentInfo.getEncoded();
  }

  public byte[] getContentDigest()
  {
    if (this.authAttrs != null)
      return ASN1OctetString.getInstance(getAuthAttrs().get(CMSAttributes.messageDigest).getAttrValues().getObjectAt(0)).getOctets();
    return null;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSAuthenticatedData
 * JD-Core Version:    0.6.0
 */