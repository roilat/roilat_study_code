package org.bouncycastle.cms;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidParameterSpecException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERConstructedOctetString;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.AuthenticatedData;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.MacCalculator;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.util.io.TeeOutputStream;

public class CMSAuthenticatedDataGenerator extends CMSAuthenticatedGenerator
{
  public CMSAuthenticatedDataGenerator()
  {
  }

  public CMSAuthenticatedData generate(CMSTypedData paramCMSTypedData, MacCalculator paramMacCalculator)
    throws CMSException
  {
    return generate(paramCMSTypedData, paramMacCalculator, null);
  }

  public CMSAuthenticatedData generate(CMSTypedData paramCMSTypedData, MacCalculator paramMacCalculator, DigestCalculator paramDigestCalculator)
    throws CMSException
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Object localObject1 = this.recipientInfoGenerators.iterator();
    Object localObject2;
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (RecipientInfoGenerator)((Iterator)localObject1).next();
      localASN1EncodableVector.add(((RecipientInfoGenerator)localObject2).generate(paramMacCalculator.getKey()));
    }
    Object localObject5;
    BERConstructedOctetString localBERConstructedOctetString;
    Object localObject3;
    DEROctetString localDEROctetString;
    if (paramDigestCalculator != null)
    {
      try
      {
        localObject2 = new ByteArrayOutputStream();
        localObject5 = new TeeOutputStream(paramDigestCalculator.getOutputStream(), (OutputStream)localObject2);
        paramCMSTypedData.write((OutputStream)localObject5);
        ((OutputStream)localObject5).close();
        localBERConstructedOctetString = new BERConstructedOctetString(((ByteArrayOutputStream)localObject2).toByteArray());
      }
      catch (IOException localIOException1)
      {
        throw new CMSException("unable to perform digest calculation: " + localIOException1.getMessage(), localIOException1);
      }
      localObject3 = getBaseParameters(paramCMSTypedData.getContentType(), paramDigestCalculator.getAlgorithmIdentifier(), paramDigestCalculator.getDigest());
      if (this.authGen == null)
        this.authGen = new DefaultAuthenticatedAttributeTableGenerator();
      localObject5 = new DERSet(this.authGen.getAttributes(Collections.unmodifiableMap((Map)localObject3)).toASN1EncodableVector());
      try
      {
        OutputStream localOutputStream = paramMacCalculator.getOutputStream();
        localOutputStream.write(((ASN1Set)localObject5).getDEREncoded());
        localOutputStream.close();
        localDEROctetString = new DEROctetString(paramMacCalculator.getMac());
      }
      catch (IOException localIOException3)
      {
        throw new CMSException("exception decoding algorithm parameters.", localIOException3);
      }
      ASN1Set localASN1Set = this.unauthGen != null ? new BERSet(this.unauthGen.getAttributes(Collections.unmodifiableMap((Map)localObject3)).toASN1EncodableVector()) : null;
      ContentInfo localContentInfo = new ContentInfo(CMSObjectIdentifiers.data, localBERConstructedOctetString);
      localObject1 = new AuthenticatedData(null, new DERSet(localASN1EncodableVector), paramMacCalculator.getAlgorithmIdentifier(), paramDigestCalculator.getAlgorithmIdentifier(), localContentInfo, (ASN1Set)localObject5, localDEROctetString, localASN1Set);
    }
    else
    {
      try
      {
        localObject3 = new ByteArrayOutputStream();
        localObject5 = new TeeOutputStream((OutputStream)localObject3, paramMacCalculator.getOutputStream());
        paramCMSTypedData.write((OutputStream)localObject5);
        ((OutputStream)localObject5).close();
        localBERConstructedOctetString = new BERConstructedOctetString(((ByteArrayOutputStream)localObject3).toByteArray());
        localDEROctetString = new DEROctetString(paramMacCalculator.getMac());
      }
      catch (IOException localIOException2)
      {
        throw new CMSException("exception decoding algorithm parameters.", localIOException2);
      }
      localObject4 = this.unauthGen != null ? new BERSet(this.unauthGen.getAttributes(Collections.EMPTY_MAP).toASN1EncodableVector()) : null;
      localObject5 = new ContentInfo(CMSObjectIdentifiers.data, localBERConstructedOctetString);
      localObject1 = new AuthenticatedData(null, new DERSet(localASN1EncodableVector), paramMacCalculator.getAlgorithmIdentifier(), null, (ContentInfo)localObject5, null, localDEROctetString, (ASN1Set)localObject4);
    }
    Object localObject4 = new ContentInfo(CMSObjectIdentifiers.authenticatedData, (DEREncodable)localObject1);
    return (CMSAuthenticatedData)(CMSAuthenticatedData)(CMSAuthenticatedData)(CMSAuthenticatedData)(CMSAuthenticatedData)new CMSAuthenticatedData((ContentInfo)localObject4, new DigestCalculatorProvider(paramDigestCalculator)
    {
      public DigestCalculator get(AlgorithmIdentifier paramAlgorithmIdentifier)
        throws OperatorCreationException
      {
        return this.val$digestCalculator;
      }
    });
  }

  /** @deprecated */
  public CMSAuthenticatedDataGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }

  /** @deprecated */
  private CMSAuthenticatedData generate(CMSProcessable paramCMSProcessable, String paramString, KeyGenerator paramKeyGenerator, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    Provider localProvider = paramKeyGenerator.getProvider();
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    SecretKey localSecretKey;
    AlgorithmIdentifier localAlgorithmIdentifier;
    BERConstructedOctetString localBERConstructedOctetString;
    DEROctetString localDEROctetString;
    try
    {
      Mac localMac = CMSEnvelopedHelper.INSTANCE.getMac(paramString, localProvider);
      localSecretKey = paramKeyGenerator.generateKey();
      localObject = generateParameterSpec(paramString, localSecretKey, localProvider);
      localMac.init(localSecretKey, (AlgorithmParameterSpec)localObject);
      localAlgorithmIdentifier = getAlgorithmIdentifier(paramString, (AlgorithmParameterSpec)localObject, localProvider);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      TeeOutputStream localTeeOutputStream = new TeeOutputStream(localByteArrayOutputStream, new MacOutputStream(localMac));
      paramCMSProcessable.write(localTeeOutputStream);
      localTeeOutputStream.close();
      localByteArrayOutputStream.close();
      localBERConstructedOctetString = new BERConstructedOctetString(localByteArrayOutputStream.toByteArray());
      localDEROctetString = new DEROctetString(localMac.doFinal());
    }
    catch (InvalidKeyException localInvalidKeyException1)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException1);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameters invalid.", localInvalidAlgorithmParameterException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception decoding algorithm parameters.", localIOException);
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException)
    {
      throw new CMSException("exception setting up parameters.", localInvalidParameterSpecException);
    }
    Iterator localIterator = this.oldRecipientInfoGenerators.iterator();
    while (localIterator.hasNext())
    {
      localObject = (IntRecipientInfoGenerator)localIterator.next();
      try
      {
        localASN1EncodableVector.add(((IntRecipientInfoGenerator)localObject).generate(localSecretKey, this.rand, paramProvider));
      }
      catch (InvalidKeyException localInvalidKeyException2)
      {
        throw new CMSException("key inappropriate for algorithm.", localInvalidKeyException2);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CMSException("error making encrypted content.", localGeneralSecurityException);
      }
    }
    localIterator = this.recipientInfoGenerators.iterator();
    while (localIterator.hasNext())
    {
      localObject = (RecipientInfoGenerator)localIterator.next();
      localASN1EncodableVector.add(((RecipientInfoGenerator)localObject).generate(new GenericKey(localSecretKey)));
    }
    Object localObject = new ContentInfo(CMSObjectIdentifiers.data, localBERConstructedOctetString);
    ContentInfo localContentInfo = new ContentInfo(CMSObjectIdentifiers.authenticatedData, new AuthenticatedData(null, new DERSet(localASN1EncodableVector), localAlgorithmIdentifier, null, (ContentInfo)localObject, null, localDEROctetString, null));
    return (CMSAuthenticatedData)new CMSAuthenticatedData(localContentInfo);
  }

  /** @deprecated */
  public CMSAuthenticatedData generate(CMSProcessable paramCMSProcessable, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramCMSProcessable, paramString1, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public CMSAuthenticatedData generate(CMSProcessable paramCMSProcessable, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(this.rand);
    return generate(paramCMSProcessable, paramString, localKeyGenerator, paramProvider);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSAuthenticatedDataGenerator
 * JD-Core Version:    0.6.0
 */