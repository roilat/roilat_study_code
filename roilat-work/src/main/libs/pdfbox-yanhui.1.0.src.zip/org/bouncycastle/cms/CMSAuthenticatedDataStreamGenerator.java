package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidParameterSpecException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERSequenceGenerator;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.AuthenticatedData;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.MacCalculator;
import org.bouncycastle.util.io.TeeOutputStream;

public class CMSAuthenticatedDataStreamGenerator extends CMSAuthenticatedGenerator
{
  private int bufferSize;
  private boolean berEncodeRecipientSet;
  private MacCalculator macCalculator;

  public CMSAuthenticatedDataStreamGenerator()
  {
  }

  public void setBufferSize(int paramInt)
  {
    this.bufferSize = paramInt;
  }

  public void setBEREncodeRecipients(boolean paramBoolean)
  {
    this.berEncodeRecipientSet = paramBoolean;
  }

  public OutputStream open(OutputStream paramOutputStream, MacCalculator paramMacCalculator)
    throws CMSException
  {
    return open(CMSObjectIdentifiers.data, paramOutputStream, paramMacCalculator);
  }

  public OutputStream open(OutputStream paramOutputStream, MacCalculator paramMacCalculator, DigestCalculator paramDigestCalculator)
    throws CMSException
  {
    return open(CMSObjectIdentifiers.data, paramOutputStream, paramMacCalculator, paramDigestCalculator);
  }

  public OutputStream open(ASN1ObjectIdentifier paramASN1ObjectIdentifier, OutputStream paramOutputStream, MacCalculator paramMacCalculator)
    throws CMSException
  {
    return open(paramASN1ObjectIdentifier, paramOutputStream, paramMacCalculator, null);
  }

  public OutputStream open(ASN1ObjectIdentifier paramASN1ObjectIdentifier, OutputStream paramOutputStream, MacCalculator paramMacCalculator, DigestCalculator paramDigestCalculator)
    throws CMSException
  {
    this.macCalculator = paramMacCalculator;
    try
    {
      ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
      Object localObject1 = this.recipientInfoGenerators.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (RecipientInfoGenerator)((Iterator)localObject1).next();
        localASN1EncodableVector.add(((RecipientInfoGenerator)localObject2).generate(paramMacCalculator.getKey()));
      }
      localObject1 = new BERSequenceGenerator(paramOutputStream);
      ((BERSequenceGenerator)localObject1).addObject(CMSObjectIdentifiers.authenticatedData);
      Object localObject2 = new BERSequenceGenerator(((BERSequenceGenerator)localObject1).getRawOutputStream(), 0, true);
      ((BERSequenceGenerator)localObject2).addObject(new DERInteger(AuthenticatedData.calculateVersion(null)));
      if (this.berEncodeRecipientSet)
        ((BERSequenceGenerator)localObject2).getRawOutputStream().write(new BERSet(localASN1EncodableVector).getEncoded());
      else
        ((BERSequenceGenerator)localObject2).getRawOutputStream().write(new DERSet(localASN1EncodableVector).getEncoded());
      AlgorithmIdentifier localAlgorithmIdentifier = paramMacCalculator.getAlgorithmIdentifier();
      ((BERSequenceGenerator)localObject2).getRawOutputStream().write(localAlgorithmIdentifier.getEncoded());
      if (paramDigestCalculator != null)
        ((BERSequenceGenerator)localObject2).addObject(new DERTaggedObject(false, 1, paramDigestCalculator.getAlgorithmIdentifier()));
      BERSequenceGenerator localBERSequenceGenerator = new BERSequenceGenerator(((BERSequenceGenerator)localObject2).getRawOutputStream());
      localBERSequenceGenerator.addObject(paramASN1ObjectIdentifier);
      OutputStream localOutputStream = CMSUtils.createBEROctetOutputStream(localBERSequenceGenerator.getRawOutputStream(), 0, false, this.bufferSize);
      TeeOutputStream localTeeOutputStream;
      if (paramDigestCalculator != null)
        localTeeOutputStream = new TeeOutputStream(localOutputStream, paramDigestCalculator.getOutputStream());
      else
        localTeeOutputStream = new TeeOutputStream(localOutputStream, paramMacCalculator.getOutputStream());
      return new CmsAuthenticatedDataOutputStream(paramMacCalculator, paramDigestCalculator, paramASN1ObjectIdentifier, localTeeOutputStream, (BERSequenceGenerator)localObject1, (BERSequenceGenerator)localObject2, localBERSequenceGenerator);
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("exception decoding algorithm parameters.", localIOException);
  }

  /** @deprecated */
  public CMSAuthenticatedDataStreamGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }

  /** @deprecated */
  private OutputStream open(OutputStream paramOutputStream, String paramString, KeyGenerator paramKeyGenerator, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    Provider localProvider = paramKeyGenerator.getProvider();
    SecretKey localSecretKey = paramKeyGenerator.generateKey();
    AlgorithmParameterSpec localAlgorithmParameterSpec = generateParameterSpec(paramString, localSecretKey, localProvider);
    Iterator localIterator = this.oldRecipientInfoGenerators.iterator();
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Object localObject;
    while (localIterator.hasNext())
    {
      localObject = (IntRecipientInfoGenerator)localIterator.next();
      try
      {
        localASN1EncodableVector.add(((IntRecipientInfoGenerator)localObject).generate(localSecretKey, this.rand, paramProvider));
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        throw new CMSException("key inappropriate for algorithm.", localInvalidKeyException);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CMSException("error making encrypted content.", localGeneralSecurityException);
      }
    }
    localIterator = this.recipientInfoGenerators.iterator();
    while (localIterator.hasNext())
    {
      localObject = (RecipientInfoGenerator)localIterator.next();
      localASN1EncodableVector.add(((RecipientInfoGenerator)localObject).generate(new GenericKey(localSecretKey)));
    }
    return (OutputStream)open(paramOutputStream, paramString, localSecretKey, localAlgorithmParameterSpec, localASN1EncodableVector, localProvider);
  }

  protected OutputStream open(OutputStream paramOutputStream, String paramString1, SecretKey paramSecretKey, AlgorithmParameterSpec paramAlgorithmParameterSpec, ASN1EncodableVector paramASN1EncodableVector, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return open(paramOutputStream, paramString1, paramSecretKey, paramAlgorithmParameterSpec, paramASN1EncodableVector, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  protected OutputStream open(OutputStream paramOutputStream, String paramString, SecretKey paramSecretKey, AlgorithmParameterSpec paramAlgorithmParameterSpec, ASN1EncodableVector paramASN1EncodableVector, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    try
    {
      BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream);
      localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.authenticatedData);
      BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
      localBERSequenceGenerator2.addObject(new DERInteger(AuthenticatedData.calculateVersion(null)));
      if (this.berEncodeRecipientSet)
        localBERSequenceGenerator2.getRawOutputStream().write(new BERSet(paramASN1EncodableVector).getEncoded());
      else
        localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(paramASN1EncodableVector).getEncoded());
      Mac localMac = CMSEnvelopedHelper.INSTANCE.getMac(paramString, paramProvider);
      localMac.init(paramSecretKey, paramAlgorithmParameterSpec);
      AlgorithmIdentifier localAlgorithmIdentifier = getAlgorithmIdentifier(paramString, paramAlgorithmParameterSpec, paramProvider);
      localBERSequenceGenerator2.getRawOutputStream().write(localAlgorithmIdentifier.getEncoded());
      BERSequenceGenerator localBERSequenceGenerator3 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
      localBERSequenceGenerator3.addObject(CMSObjectIdentifiers.data);
      OutputStream localOutputStream = CMSUtils.createBEROctetOutputStream(localBERSequenceGenerator3.getRawOutputStream(), 0, false, this.bufferSize);
      TeeOutputStream localTeeOutputStream = new TeeOutputStream(localOutputStream, new MacOutputStream(localMac));
      return new OldCmsAuthenticatedDataOutputStream(localTeeOutputStream, localMac, localBERSequenceGenerator1, localBERSequenceGenerator2, localBERSequenceGenerator3);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameter invalid.", localInvalidAlgorithmParameterException);
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException)
    {
      throw new CMSException("algorithm parameter spec invalid.", localInvalidParameterSpecException);
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("exception decoding algorithm parameters.", localIOException);
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException, IOException
  {
    return open(paramOutputStream, paramString1, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException, IOException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(this.rand);
    return open(paramOutputStream, paramString, localKeyGenerator, paramProvider);
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream, String paramString1, int paramInt, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException, IOException
  {
    return open(paramOutputStream, paramString1, paramInt, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException, IOException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(paramInt, this.rand);
    return open(paramOutputStream, paramString, localKeyGenerator, paramProvider);
  }

  private class CmsAuthenticatedDataOutputStream extends OutputStream
  {
    private OutputStream dataStream;
    private BERSequenceGenerator cGen;
    private BERSequenceGenerator envGen;
    private BERSequenceGenerator eiGen;
    private MacCalculator macCalculator;
    private DigestCalculator digestCalculator;
    private ASN1ObjectIdentifier contentType;

    public CmsAuthenticatedDataOutputStream(MacCalculator paramDigestCalculator, DigestCalculator paramASN1ObjectIdentifier, ASN1ObjectIdentifier paramOutputStream, OutputStream paramBERSequenceGenerator1, BERSequenceGenerator paramBERSequenceGenerator2, BERSequenceGenerator paramBERSequenceGenerator3, BERSequenceGenerator arg8)
    {
      this.macCalculator = paramDigestCalculator;
      this.digestCalculator = paramASN1ObjectIdentifier;
      this.contentType = paramOutputStream;
      this.dataStream = paramBERSequenceGenerator1;
      this.cGen = paramBERSequenceGenerator2;
      this.envGen = paramBERSequenceGenerator3;
      Object localObject;
      this.eiGen = localObject;
    }

    public void write(int paramInt)
      throws IOException
    {
      this.dataStream.write(paramInt);
    }

    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this.dataStream.write(paramArrayOfByte, paramInt1, paramInt2);
    }

    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this.dataStream.write(paramArrayOfByte);
    }

    public void close()
      throws IOException
    {
      this.dataStream.close();
      this.eiGen.close();
      Map localMap;
      if (this.digestCalculator != null)
      {
        localMap = Collections.unmodifiableMap(CMSAuthenticatedDataStreamGenerator.this.getBaseParameters(this.contentType, this.digestCalculator.getAlgorithmIdentifier(), this.digestCalculator.getDigest()));
        if (CMSAuthenticatedDataStreamGenerator.this.authGen == null)
          CMSAuthenticatedDataStreamGenerator.this.authGen = new DefaultAuthenticatedAttributeTableGenerator();
        DERSet localDERSet = new DERSet(CMSAuthenticatedDataStreamGenerator.this.authGen.getAttributes(localMap).toASN1EncodableVector());
        OutputStream localOutputStream = this.macCalculator.getOutputStream();
        localOutputStream.write(localDERSet.getDEREncoded());
        localOutputStream.close();
        this.envGen.addObject(new DERTaggedObject(false, 2, localDERSet));
      }
      else
      {
        localMap = Collections.unmodifiableMap(new HashMap());
      }
      this.envGen.addObject(new DEROctetString(this.macCalculator.getMac()));
      if (CMSAuthenticatedDataStreamGenerator.this.unauthGen != null)
        this.envGen.addObject(new DERTaggedObject(false, 3, new BERSet(CMSAuthenticatedDataStreamGenerator.this.unauthGen.getAttributes(localMap).toASN1EncodableVector())));
      this.envGen.close();
      this.cGen.close();
    }
  }

  private class OldCmsAuthenticatedDataOutputStream extends OutputStream
  {
    private OutputStream dataStream;
    private Mac mac;
    private BERSequenceGenerator cGen;
    private BERSequenceGenerator envGen;
    private BERSequenceGenerator eiGen;

    public OldCmsAuthenticatedDataOutputStream(OutputStream paramMac, Mac paramBERSequenceGenerator1, BERSequenceGenerator paramBERSequenceGenerator2, BERSequenceGenerator paramBERSequenceGenerator3, BERSequenceGenerator arg6)
    {
      this.dataStream = paramMac;
      this.mac = paramBERSequenceGenerator1;
      this.cGen = paramBERSequenceGenerator2;
      this.envGen = paramBERSequenceGenerator3;
      Object localObject;
      this.eiGen = localObject;
    }

    public void write(int paramInt)
      throws IOException
    {
      this.dataStream.write(paramInt);
    }

    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this.dataStream.write(paramArrayOfByte, paramInt1, paramInt2);
    }

    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this.dataStream.write(paramArrayOfByte);
    }

    public void close()
      throws IOException
    {
      this.dataStream.close();
      this.eiGen.close();
      this.envGen.addObject(new DEROctetString(this.mac.doFinal()));
      this.envGen.close();
      this.cGen.close();
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSAuthenticatedDataStreamGenerator
 * JD-Core Version:    0.6.0
 */