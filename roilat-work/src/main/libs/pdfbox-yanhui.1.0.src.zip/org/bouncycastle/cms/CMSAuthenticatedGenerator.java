package org.bouncycastle.cms;

import B;
import java.io.IOException;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidParameterSpecException;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.RC2ParameterSpec;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSAuthenticatedGenerator extends CMSEnvelopedGenerator
{
  protected CMSAttributeTableGenerator authGen;
  protected CMSAttributeTableGenerator unauthGen;

  public CMSAuthenticatedGenerator()
  {
  }

  public CMSAuthenticatedGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }

  protected AlgorithmIdentifier getAlgorithmIdentifier(String paramString, AlgorithmParameterSpec paramAlgorithmParameterSpec, Provider paramProvider)
    throws IOException, NoSuchAlgorithmException, InvalidParameterSpecException
  {
    AlgorithmParameters localAlgorithmParameters = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameters(paramString, paramProvider);
    localAlgorithmParameters.init(paramAlgorithmParameterSpec);
    return getAlgorithmIdentifier(paramString, localAlgorithmParameters);
  }

  protected AlgorithmParameterSpec generateParameterSpec(String paramString, SecretKey paramSecretKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      if (paramString.equals(RC2_CBC))
      {
        localObject = new byte[8];
        this.rand.nextBytes(localObject);
        return new RC2ParameterSpec(paramSecretKey.getEncoded().length * 8, localObject);
      }
      Object localObject = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameterGenerator(paramString, paramProvider);
      AlgorithmParameters localAlgorithmParameters = ((AlgorithmParameterGenerator)localObject).generateParameters();
      return localAlgorithmParameters.getParameterSpec(IvParameterSpec.class);
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    return (AlgorithmParameterSpec)null;
  }

  public void setAuthenticatedAttributeGenerator(CMSAttributeTableGenerator paramCMSAttributeTableGenerator)
  {
    this.authGen = paramCMSAttributeTableGenerator;
  }

  public void setUnauthenticatedAttributeGenerator(CMSAttributeTableGenerator paramCMSAttributeTableGenerator)
  {
    this.unauthGen = paramCMSAttributeTableGenerator;
  }

  protected Map getBaseParameters(DERObjectIdentifier paramDERObjectIdentifier, AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
  {
    HashMap localHashMap = new HashMap();
    localHashMap.put("contentType", paramDERObjectIdentifier);
    localHashMap.put("digestAlgID", paramAlgorithmIdentifier);
    localHashMap.put("digest", paramArrayOfByte.clone());
    return localHashMap;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSAuthenticatedGenerator
 * JD-Core Version:    0.6.0
 */