package org.bouncycastle.cms;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import org.bouncycastle.asn1.BERConstructedOctetString;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.CompressedData;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.OutputCompressor;

public class CMSCompressedDataGenerator
{
  public static final String ZLIB = "1.2.840.113549.1.9.16.3.8";

  /** @deprecated */
  public CMSCompressedData generate(CMSProcessable paramCMSProcessable, String paramString)
    throws CMSException
  {
    AlgorithmIdentifier localAlgorithmIdentifier;
    BERConstructedOctetString localBERConstructedOctetString;
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      localObject = new DeflaterOutputStream(localByteArrayOutputStream);
      paramCMSProcessable.write((OutputStream)localObject);
      ((DeflaterOutputStream)localObject).close();
      localAlgorithmIdentifier = new AlgorithmIdentifier(new DERObjectIdentifier(paramString));
      localBERConstructedOctetString = new BERConstructedOctetString(localByteArrayOutputStream.toByteArray());
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception encoding data.", localIOException);
    }
    ContentInfo localContentInfo = new ContentInfo(CMSObjectIdentifiers.data, localBERConstructedOctetString);
    Object localObject = new ContentInfo(CMSObjectIdentifiers.compressedData, new CompressedData(localAlgorithmIdentifier, localContentInfo));
    return (CMSCompressedData)new CMSCompressedData((ContentInfo)localObject);
  }

  public CMSCompressedData generate(CMSTypedData paramCMSTypedData, OutputCompressor paramOutputCompressor)
    throws CMSException
  {
    AlgorithmIdentifier localAlgorithmIdentifier;
    BERConstructedOctetString localBERConstructedOctetString;
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      localObject = paramOutputCompressor.getOutputStream(localByteArrayOutputStream);
      paramCMSTypedData.write((OutputStream)localObject);
      ((OutputStream)localObject).close();
      localAlgorithmIdentifier = paramOutputCompressor.getAlgorithmIdentifier();
      localBERConstructedOctetString = new BERConstructedOctetString(localByteArrayOutputStream.toByteArray());
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception encoding data.", localIOException);
    }
    ContentInfo localContentInfo = new ContentInfo(paramCMSTypedData.getContentType(), localBERConstructedOctetString);
    Object localObject = new ContentInfo(CMSObjectIdentifiers.compressedData, new CompressedData(localAlgorithmIdentifier, localContentInfo));
    return (CMSCompressedData)new CMSCompressedData((ContentInfo)localObject);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSCompressedDataGenerator
 * JD-Core Version:    0.6.0
 */