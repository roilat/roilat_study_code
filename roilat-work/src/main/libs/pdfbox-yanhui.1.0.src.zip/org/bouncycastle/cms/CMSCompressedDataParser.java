package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.InflaterInputStream;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetStringParser;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.cms.CompressedDataParser;
import org.bouncycastle.asn1.cms.ContentInfoParser;
import org.bouncycastle.operator.InputExpander;
import org.bouncycastle.operator.InputExpanderProvider;

public class CMSCompressedDataParser extends CMSContentInfoParser
{
  public CMSCompressedDataParser(byte[] paramArrayOfByte)
    throws CMSException
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }

  public CMSCompressedDataParser(InputStream paramInputStream)
    throws CMSException
  {
    super(paramInputStream);
  }

  /** @deprecated */
  public CMSTypedStream getContent()
    throws CMSException
  {
    try
    {
      CompressedDataParser localCompressedDataParser = new CompressedDataParser((ASN1SequenceParser)this._contentInfo.getContent(16));
      ContentInfoParser localContentInfoParser = localCompressedDataParser.getEncapContentInfo();
      ASN1OctetStringParser localASN1OctetStringParser = (ASN1OctetStringParser)localContentInfoParser.getContent(4);
      return new CMSTypedStream(localContentInfoParser.getContentType().toString(), new InflaterInputStream(localASN1OctetStringParser.getOctetStream()));
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("IOException reading compressed content.", localIOException);
  }

  public CMSTypedStream getContent(InputExpanderProvider paramInputExpanderProvider)
    throws CMSException
  {
    try
    {
      CompressedDataParser localCompressedDataParser = new CompressedDataParser((ASN1SequenceParser)this._contentInfo.getContent(16));
      ContentInfoParser localContentInfoParser = localCompressedDataParser.getEncapContentInfo();
      InputExpander localInputExpander = paramInputExpanderProvider.get(localCompressedDataParser.getCompressionAlgorithmIdentifier());
      ASN1OctetStringParser localASN1OctetStringParser = (ASN1OctetStringParser)localContentInfoParser.getContent(4);
      return new CMSTypedStream(localContentInfoParser.getContentType().getId(), localInputExpander.getInputStream(localASN1OctetStringParser.getOctetStream()));
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("IOException reading compressed content.", localIOException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSCompressedDataParser
 * JD-Core Version:    0.6.0
 */