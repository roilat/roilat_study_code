package org.bouncycastle.cms;

import org.bouncycastle.asn1.DERObjectIdentifier;

public class CMSConfig
{
  public static void setSigningEncryptionAlgorithmMapping(String paramString1, String paramString2)
  {
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier(paramString1);
    CMSSignedHelper.INSTANCE.setSigningEncryptionAlgorithmMapping(localDERObjectIdentifier, paramString2);
  }

  public static void setSigningDigestAlgorithmMapping(String paramString1, String paramString2)
  {
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier(paramString1);
    CMSSignedHelper.INSTANCE.setSigningDigestAlgorithmMapping(localDERObjectIdentifier, paramString2);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSConfig
 * JD-Core Version:    0.6.0
 */