package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1StreamParser;
import org.bouncycastle.asn1.cms.ContentInfoParser;

public class CMSContentInfoParser
{
  protected ContentInfoParser _contentInfo;
  protected InputStream _data;

  protected CMSContentInfoParser(InputStream paramInputStream)
    throws CMSException
  {
    this._data = paramInputStream;
    try
    {
      ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(paramInputStream);
      this._contentInfo = new ContentInfoParser((ASN1SequenceParser)localASN1StreamParser.readObject());
    }
    catch (IOException localIOException)
    {
      throw new CMSException("IOException reading content.", localIOException);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CMSException("Unexpected object reading content.", localClassCastException);
    }
  }

  public void close()
    throws IOException
  {
    this._data.close();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSContentInfoParser
 * JD-Core Version:    0.6.0
 */