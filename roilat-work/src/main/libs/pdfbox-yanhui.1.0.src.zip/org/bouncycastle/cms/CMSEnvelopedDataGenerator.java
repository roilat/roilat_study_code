package org.bouncycastle.cms;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERConstructedOctetString;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.cms.EncryptedContentInfo;
import org.bouncycastle.asn1.cms.EnvelopedData;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.OutputEncryptor;

public class CMSEnvelopedDataGenerator extends CMSEnvelopedGenerator
{
  public CMSEnvelopedDataGenerator()
  {
  }

  public CMSEnvelopedDataGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }

  private CMSEnvelopedData generate(CMSProcessable paramCMSProcessable, String paramString, KeyGenerator paramKeyGenerator, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    Provider localProvider = paramKeyGenerator.getProvider();
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    SecretKey localSecretKey;
    AlgorithmIdentifier localAlgorithmIdentifier;
    BERConstructedOctetString localBERConstructedOctetString;
    try
    {
      Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createSymmetricCipher(paramString, localProvider);
      localSecretKey = paramKeyGenerator.generateKey();
      localObject2 = generateParameters(paramString, localSecretKey, localProvider);
      localCipher.init(1, localSecretKey, (AlgorithmParameters)localObject2, this.rand);
      if (localObject2 == null)
        localObject2 = localCipher.getParameters();
      localAlgorithmIdentifier = getAlgorithmIdentifier(paramString, (AlgorithmParameters)localObject2);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher);
      paramCMSProcessable.write(localCipherOutputStream);
      localCipherOutputStream.close();
      localBERConstructedOctetString = new BERConstructedOctetString(localByteArrayOutputStream.toByteArray());
    }
    catch (InvalidKeyException localInvalidKeyException1)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException1);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameters invalid.", localInvalidAlgorithmParameterException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception decoding algorithm parameters.", localIOException);
    }
    Object localObject1 = this.oldRecipientInfoGenerators.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (IntRecipientInfoGenerator)((Iterator)localObject1).next();
      try
      {
        localASN1EncodableVector.add(((IntRecipientInfoGenerator)localObject2).generate(localSecretKey, this.rand, paramProvider));
      }
      catch (InvalidKeyException localInvalidKeyException2)
      {
        throw new CMSException("key inappropriate for algorithm.", localInvalidKeyException2);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CMSException("error making encrypted content.", localGeneralSecurityException);
      }
    }
    localObject1 = this.recipientInfoGenerators.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (RecipientInfoGenerator)((Iterator)localObject1).next();
      localASN1EncodableVector.add(((RecipientInfoGenerator)localObject2).generate(new GenericKey(localSecretKey)));
    }
    if ((paramCMSProcessable instanceof CMSTypedData))
      localObject1 = new EncryptedContentInfo(((CMSTypedData)paramCMSProcessable).getContentType(), localAlgorithmIdentifier, localBERConstructedOctetString);
    else
      localObject1 = new EncryptedContentInfo(CMSObjectIdentifiers.data, localAlgorithmIdentifier, localBERConstructedOctetString);
    Object localObject2 = null;
    if (this.unprotectedAttributeGenerator != null)
    {
      localObject3 = this.unprotectedAttributeGenerator.getAttributes(new HashMap());
      localObject2 = new BERSet(((AttributeTable)localObject3).toASN1EncodableVector());
    }
    Object localObject3 = new ContentInfo(CMSObjectIdentifiers.envelopedData, new EnvelopedData(null, new DERSet(localASN1EncodableVector), (EncryptedContentInfo)localObject1, (ASN1Set)localObject2));
    return (CMSEnvelopedData)(CMSEnvelopedData)(CMSEnvelopedData)new CMSEnvelopedData((ContentInfo)localObject3);
  }

  private CMSEnvelopedData doGenerate(CMSTypedData paramCMSTypedData, OutputEncryptor paramOutputEncryptor)
    throws CMSException
  {
    if (!this.oldRecipientInfoGenerators.isEmpty())
      throw new IllegalStateException("can only use addRecipientGenerator() with this method");
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    try
    {
      OutputStream localOutputStream = paramOutputEncryptor.getOutputStream(localByteArrayOutputStream);
      paramCMSTypedData.write(localOutputStream);
      localOutputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new CMSException("");
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    AlgorithmIdentifier localAlgorithmIdentifier = paramOutputEncryptor.getAlgorithmIdentifier();
    BERConstructedOctetString localBERConstructedOctetString = new BERConstructedOctetString(arrayOfByte);
    GenericKey localGenericKey = paramOutputEncryptor.getKey();
    Object localObject1 = this.recipientInfoGenerators.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (RecipientInfoGenerator)((Iterator)localObject1).next();
      localASN1EncodableVector.add(((RecipientInfoGenerator)localObject2).generate(localGenericKey));
    }
    localObject1 = new EncryptedContentInfo(paramCMSTypedData.getContentType(), localAlgorithmIdentifier, localBERConstructedOctetString);
    Object localObject2 = null;
    if (this.unprotectedAttributeGenerator != null)
    {
      localObject3 = this.unprotectedAttributeGenerator.getAttributes(new HashMap());
      localObject2 = new BERSet(((AttributeTable)localObject3).toASN1EncodableVector());
    }
    Object localObject3 = new ContentInfo(CMSObjectIdentifiers.envelopedData, new EnvelopedData(null, new DERSet(localASN1EncodableVector), (EncryptedContentInfo)localObject1, (ASN1Set)localObject2));
    return (CMSEnvelopedData)(CMSEnvelopedData)(CMSEnvelopedData)new CMSEnvelopedData((ContentInfo)localObject3);
  }

  /** @deprecated */
  public CMSEnvelopedData generate(CMSProcessable paramCMSProcessable, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramCMSProcessable, paramString1, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public CMSEnvelopedData generate(CMSProcessable paramCMSProcessable, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(this.rand);
    return generate(paramCMSProcessable, paramString, localKeyGenerator, paramProvider);
  }

  /** @deprecated */
  public CMSEnvelopedData generate(CMSProcessable paramCMSProcessable, String paramString1, int paramInt, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramCMSProcessable, paramString1, paramInt, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public CMSEnvelopedData generate(CMSProcessable paramCMSProcessable, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(paramInt, this.rand);
    return generate(paramCMSProcessable, paramString, localKeyGenerator, paramProvider);
  }

  public CMSEnvelopedData generate(CMSTypedData paramCMSTypedData, OutputEncryptor paramOutputEncryptor)
    throws CMSException
  {
    return doGenerate(paramCMSTypedData, paramOutputEncryptor);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSEnvelopedDataGenerator
 * JD-Core Version:    0.6.0
 */