package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.AlgorithmParameters;
import java.security.NoSuchProviderException;
import java.security.Provider;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetStringParser;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1SetParser;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.ContentInfoParser;
import org.bouncycastle.asn1.cms.EncryptedContentInfoParser;
import org.bouncycastle.asn1.cms.EnvelopedDataParser;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSEnvelopedDataParser extends CMSContentInfoParser
{
  RecipientInformationStore _recipientInfoStore;
  EnvelopedDataParser _envelopedData = new EnvelopedDataParser((ASN1SequenceParser)this._contentInfo.getContent(16));
  private AlgorithmIdentifier _encAlg;
  private AttributeTable _unprotectedAttributes;
  private boolean _attrNotRead = true;

  public CMSEnvelopedDataParser(byte[] paramArrayOfByte)
    throws CMSException, IOException
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }

  public CMSEnvelopedDataParser(InputStream paramInputStream)
    throws CMSException, IOException
  {
    super(paramInputStream);
    ASN1Set localASN1Set = ASN1Set.getInstance(this._envelopedData.getRecipientInfos().getDERObject());
    EncryptedContentInfoParser localEncryptedContentInfoParser = this._envelopedData.getEncryptedContentInfo();
    this._encAlg = localEncryptedContentInfoParser.getContentEncryptionAlgorithm();
    CMSProcessableInputStream localCMSProcessableInputStream = new CMSProcessableInputStream(((ASN1OctetStringParser)localEncryptedContentInfoParser.getEncryptedContent(4)).getOctetStream());
    CMSEnvelopedHelper.CMSEnvelopedSecureReadable localCMSEnvelopedSecureReadable = new CMSEnvelopedHelper.CMSEnvelopedSecureReadable(this._encAlg, localCMSProcessableInputStream);
    this._recipientInfoStore = CMSEnvelopedHelper.buildRecipientInformationStore(localASN1Set, this._encAlg, localCMSEnvelopedSecureReadable);
  }

  public String getEncryptionAlgOID()
  {
    return this._encAlg.getObjectId().toString();
  }

  public byte[] getEncryptionAlgParams()
  {
    try
    {
      return encodeObj(this._encAlg.getParameters());
    }
    catch (Exception localException)
    {
    }
    throw new RuntimeException("exception getting encryption parameters " + localException);
  }

  public AlgorithmParameters getEncryptionAlgorithmParameters(String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getEncryptionAlgorithmParameters(CMSUtils.getProvider(paramString));
  }

  public AlgorithmParameters getEncryptionAlgorithmParameters(Provider paramProvider)
    throws CMSException
  {
    return CMSEnvelopedHelper.INSTANCE.getEncryptionAlgorithmParameters(getEncryptionAlgOID(), getEncryptionAlgParams(), paramProvider);
  }

  public RecipientInformationStore getRecipientInfos()
  {
    return this._recipientInfoStore;
  }

  public AttributeTable getUnprotectedAttributes()
    throws IOException
  {
    if ((this._unprotectedAttributes == null) && (this._attrNotRead))
    {
      ASN1SetParser localASN1SetParser = this._envelopedData.getUnprotectedAttrs();
      this._attrNotRead = false;
      if (localASN1SetParser != null)
      {
        ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
        DEREncodable localDEREncodable;
        while ((localDEREncodable = localASN1SetParser.readObject()) != null)
        {
          ASN1SequenceParser localASN1SequenceParser = (ASN1SequenceParser)localDEREncodable;
          localASN1EncodableVector.add(localASN1SequenceParser.getDERObject());
        }
        this._unprotectedAttributes = new AttributeTable(new DERSet(localASN1EncodableVector));
      }
    }
    return this._unprotectedAttributes;
  }

  private byte[] encodeObj(DEREncodable paramDEREncodable)
    throws IOException
  {
    if (paramDEREncodable != null)
      return paramDEREncodable.getDERObject().getEncoded();
    return null;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSEnvelopedDataParser
 * JD-Core Version:    0.6.0
 */