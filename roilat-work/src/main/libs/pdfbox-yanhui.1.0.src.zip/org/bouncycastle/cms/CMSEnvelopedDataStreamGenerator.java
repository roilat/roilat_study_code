package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.BERSequenceGenerator;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.OutputEncryptor;

public class CMSEnvelopedDataStreamGenerator extends CMSEnvelopedGenerator
{
  private Object _originatorInfo = null;
  private Object _unprotectedAttributes = null;
  private int _bufferSize;
  private boolean _berEncodeRecipientSet;

  public CMSEnvelopedDataStreamGenerator()
  {
  }

  public CMSEnvelopedDataStreamGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }

  public void setBufferSize(int paramInt)
  {
    this._bufferSize = paramInt;
  }

  public void setBEREncodeRecipients(boolean paramBoolean)
  {
    this._berEncodeRecipientSet = paramBoolean;
  }

  private DERInteger getVersion()
  {
    if ((this._originatorInfo != null) || (this._unprotectedAttributes != null))
      return new DERInteger(2);
    return new DERInteger(0);
  }

  /** @deprecated */
  private OutputStream open(OutputStream paramOutputStream, String paramString, KeyGenerator paramKeyGenerator, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    Provider localProvider = paramKeyGenerator.getProvider();
    SecretKey localSecretKey = paramKeyGenerator.generateKey();
    AlgorithmParameters localAlgorithmParameters = generateParameters(paramString, localSecretKey, localProvider);
    Iterator localIterator = this.oldRecipientInfoGenerators.iterator();
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Object localObject;
    while (localIterator.hasNext())
    {
      localObject = (IntRecipientInfoGenerator)localIterator.next();
      try
      {
        localASN1EncodableVector.add(((IntRecipientInfoGenerator)localObject).generate(localSecretKey, this.rand, paramProvider));
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        throw new CMSException("key inappropriate for algorithm.", localInvalidKeyException);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CMSException("error making encrypted content.", localGeneralSecurityException);
      }
    }
    localIterator = this.recipientInfoGenerators.iterator();
    while (localIterator.hasNext())
    {
      localObject = (RecipientInfoGenerator)localIterator.next();
      localASN1EncodableVector.add(((RecipientInfoGenerator)localObject).generate(new GenericKey(localSecretKey)));
    }
    return (OutputStream)open(paramOutputStream, paramString, localSecretKey, localAlgorithmParameters, localASN1EncodableVector, localProvider);
  }

  private OutputStream doOpen(ASN1ObjectIdentifier paramASN1ObjectIdentifier, OutputStream paramOutputStream, OutputEncryptor paramOutputEncryptor)
    throws IOException, CMSException
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    GenericKey localGenericKey = paramOutputEncryptor.getKey();
    Iterator localIterator = this.recipientInfoGenerators.iterator();
    while (localIterator.hasNext())
    {
      RecipientInfoGenerator localRecipientInfoGenerator = (RecipientInfoGenerator)localIterator.next();
      localASN1EncodableVector.add(localRecipientInfoGenerator.generate(localGenericKey));
    }
    return open(paramASN1ObjectIdentifier, paramOutputStream, localASN1EncodableVector, paramOutputEncryptor);
  }

  protected OutputStream open(ASN1ObjectIdentifier paramASN1ObjectIdentifier, OutputStream paramOutputStream, ASN1EncodableVector paramASN1EncodableVector, OutputEncryptor paramOutputEncryptor)
    throws IOException
  {
    BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream);
    localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.envelopedData);
    BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
    localBERSequenceGenerator2.addObject(getVersion());
    if (this._berEncodeRecipientSet)
      localBERSequenceGenerator2.getRawOutputStream().write(new BERSet(paramASN1EncodableVector).getEncoded());
    else
      localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(paramASN1EncodableVector).getEncoded());
    BERSequenceGenerator localBERSequenceGenerator3 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
    localBERSequenceGenerator3.addObject(paramASN1ObjectIdentifier);
    AlgorithmIdentifier localAlgorithmIdentifier = paramOutputEncryptor.getAlgorithmIdentifier();
    localBERSequenceGenerator3.getRawOutputStream().write(localAlgorithmIdentifier.getEncoded());
    OutputStream localOutputStream1 = CMSUtils.createBEROctetOutputStream(localBERSequenceGenerator3.getRawOutputStream(), 0, false, this._bufferSize);
    OutputStream localOutputStream2 = paramOutputEncryptor.getOutputStream(localOutputStream1);
    return new CmsEnvelopedDataOutputStream(localOutputStream2, localBERSequenceGenerator1, localBERSequenceGenerator2, localBERSequenceGenerator3);
  }

  protected OutputStream open(OutputStream paramOutputStream, String paramString1, SecretKey paramSecretKey, AlgorithmParameters paramAlgorithmParameters, ASN1EncodableVector paramASN1EncodableVector, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return open(paramOutputStream, paramString1, paramSecretKey, paramAlgorithmParameters, paramASN1EncodableVector, CMSUtils.getProvider(paramString2));
  }

  protected OutputStream open(OutputStream paramOutputStream, String paramString, SecretKey paramSecretKey, AlgorithmParameters paramAlgorithmParameters, ASN1EncodableVector paramASN1EncodableVector, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    try
    {
      BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream);
      localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.envelopedData);
      BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
      localBERSequenceGenerator2.addObject(getVersion());
      if (this._berEncodeRecipientSet)
        localBERSequenceGenerator2.getRawOutputStream().write(new BERSet(paramASN1EncodableVector).getEncoded());
      else
        localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(paramASN1EncodableVector).getEncoded());
      BERSequenceGenerator localBERSequenceGenerator3 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
      localBERSequenceGenerator3.addObject(CMSObjectIdentifiers.data);
      Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createSymmetricCipher(paramString, paramProvider);
      localCipher.init(1, paramSecretKey, paramAlgorithmParameters, this.rand);
      if (paramAlgorithmParameters == null)
        paramAlgorithmParameters = localCipher.getParameters();
      AlgorithmIdentifier localAlgorithmIdentifier = getAlgorithmIdentifier(paramString, paramAlgorithmParameters);
      localBERSequenceGenerator3.getRawOutputStream().write(localAlgorithmIdentifier.getEncoded());
      OutputStream localOutputStream = CMSUtils.createBEROctetOutputStream(localBERSequenceGenerator3.getRawOutputStream(), 0, false, this._bufferSize);
      CipherOutputStream localCipherOutputStream = new CipherOutputStream(localOutputStream, localCipher);
      return new CmsEnvelopedDataOutputStream(localCipherOutputStream, localBERSequenceGenerator1, localBERSequenceGenerator2, localBERSequenceGenerator3);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameters invalid.", localInvalidAlgorithmParameterException);
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("exception decoding algorithm parameters.", localIOException);
  }

  protected OutputStream open(OutputStream paramOutputStream, ASN1EncodableVector paramASN1EncodableVector, OutputEncryptor paramOutputEncryptor)
    throws CMSException
  {
    try
    {
      BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream);
      localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.envelopedData);
      BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
      localBERSequenceGenerator2.addObject(getVersion());
      if (this._berEncodeRecipientSet)
        localBERSequenceGenerator2.getRawOutputStream().write(new BERSet(paramASN1EncodableVector).getEncoded());
      else
        localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(paramASN1EncodableVector).getEncoded());
      BERSequenceGenerator localBERSequenceGenerator3 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
      localBERSequenceGenerator3.addObject(CMSObjectIdentifiers.data);
      AlgorithmIdentifier localAlgorithmIdentifier = paramOutputEncryptor.getAlgorithmIdentifier();
      localBERSequenceGenerator3.getRawOutputStream().write(localAlgorithmIdentifier.getEncoded());
      OutputStream localOutputStream = CMSUtils.createBEROctetOutputStream(localBERSequenceGenerator3.getRawOutputStream(), 0, false, this._bufferSize);
      return new CmsEnvelopedDataOutputStream(paramOutputEncryptor.getOutputStream(localOutputStream), localBERSequenceGenerator1, localBERSequenceGenerator2, localBERSequenceGenerator3);
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("exception decoding algorithm parameters.", localIOException);
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException, IOException
  {
    return open(paramOutputStream, paramString1, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException, IOException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(this.rand);
    return open(paramOutputStream, paramString, localKeyGenerator, paramProvider);
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream, String paramString1, int paramInt, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException, IOException
  {
    return open(paramOutputStream, paramString1, paramInt, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException, IOException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(paramInt, this.rand);
    return open(paramOutputStream, paramString, localKeyGenerator, paramProvider);
  }

  public OutputStream open(OutputStream paramOutputStream, OutputEncryptor paramOutputEncryptor)
    throws CMSException, IOException
  {
    return doOpen(new ASN1ObjectIdentifier(CMSObjectIdentifiers.data.getId()), paramOutputStream, paramOutputEncryptor);
  }

  public OutputStream open(ASN1ObjectIdentifier paramASN1ObjectIdentifier, OutputStream paramOutputStream, OutputEncryptor paramOutputEncryptor)
    throws CMSException, IOException
  {
    return doOpen(paramASN1ObjectIdentifier, paramOutputStream, paramOutputEncryptor);
  }

  private class CmsEnvelopedDataOutputStream extends OutputStream
  {
    private OutputStream _out;
    private BERSequenceGenerator _cGen;
    private BERSequenceGenerator _envGen;
    private BERSequenceGenerator _eiGen;

    public CmsEnvelopedDataOutputStream(OutputStream paramBERSequenceGenerator1, BERSequenceGenerator paramBERSequenceGenerator2, BERSequenceGenerator paramBERSequenceGenerator3, BERSequenceGenerator arg5)
    {
      this._out = paramBERSequenceGenerator1;
      this._cGen = paramBERSequenceGenerator2;
      this._envGen = paramBERSequenceGenerator3;
      Object localObject;
      this._eiGen = localObject;
    }

    public void write(int paramInt)
      throws IOException
    {
      this._out.write(paramInt);
    }

    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this._out.write(paramArrayOfByte, paramInt1, paramInt2);
    }

    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this._out.write(paramArrayOfByte);
    }

    public void close()
      throws IOException
    {
      this._out.close();
      this._eiGen.close();
      if (CMSEnvelopedDataStreamGenerator.this.unprotectedAttributeGenerator != null)
      {
        AttributeTable localAttributeTable = CMSEnvelopedDataStreamGenerator.this.unprotectedAttributeGenerator.getAttributes(new HashMap());
        BERSet localBERSet = new BERSet(localAttributeTable.toASN1EncodableVector());
        this._envGen.addObject(new DERTaggedObject(false, 1, localBERSet));
      }
      this._envGen.close();
      this._cGen.close();
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSEnvelopedDataStreamGenerator
 * JD-Core Version:    0.6.0
 */