package org.bouncycastle.cms;

import java.io.IOException;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import javax.crypto.SecretKey;
import javax.crypto.spec.RC2ParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.KEKIdentifier;
import org.bouncycastle.asn1.kisa.KISAObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.ntt.NTTObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PBKDF2Params;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;

public class CMSEnvelopedGenerator
{
  public static final String DES_EDE3_CBC = PKCSObjectIdentifiers.des_EDE3_CBC.getId();
  public static final String RC2_CBC = PKCSObjectIdentifiers.RC2_CBC.getId();
  public static final String IDEA_CBC = "1.3.6.1.4.1.188.7.1.1.2";
  public static final String CAST5_CBC = "1.2.840.113533.7.66.10";
  public static final String AES128_CBC = NISTObjectIdentifiers.id_aes128_CBC.getId();
  public static final String AES192_CBC = NISTObjectIdentifiers.id_aes192_CBC.getId();
  public static final String AES256_CBC = NISTObjectIdentifiers.id_aes256_CBC.getId();
  public static final String CAMELLIA128_CBC = NTTObjectIdentifiers.id_camellia128_cbc.getId();
  public static final String CAMELLIA192_CBC = NTTObjectIdentifiers.id_camellia192_cbc.getId();
  public static final String CAMELLIA256_CBC = NTTObjectIdentifiers.id_camellia256_cbc.getId();
  public static final String SEED_CBC = KISAObjectIdentifiers.id_seedCBC.getId();
  public static final String DES_EDE3_WRAP = PKCSObjectIdentifiers.id_alg_CMS3DESwrap.getId();
  public static final String AES128_WRAP = NISTObjectIdentifiers.id_aes128_wrap.getId();
  public static final String AES192_WRAP = NISTObjectIdentifiers.id_aes192_wrap.getId();
  public static final String AES256_WRAP = NISTObjectIdentifiers.id_aes256_wrap.getId();
  public static final String CAMELLIA128_WRAP = NTTObjectIdentifiers.id_camellia128_wrap.getId();
  public static final String CAMELLIA192_WRAP = NTTObjectIdentifiers.id_camellia192_wrap.getId();
  public static final String CAMELLIA256_WRAP = NTTObjectIdentifiers.id_camellia256_wrap.getId();
  public static final String SEED_WRAP = KISAObjectIdentifiers.id_npki_app_cmsSeed_wrap.getId();
  public static final String ECDH_SHA1KDF = X9ObjectIdentifiers.dhSinglePass_stdDH_sha1kdf_scheme.getId();
  public static final String ECMQV_SHA1KDF = X9ObjectIdentifiers.mqvSinglePass_sha1kdf_scheme.getId();
  final List oldRecipientInfoGenerators = new ArrayList();
  final List recipientInfoGenerators = new ArrayList();
  protected CMSAttributeTableGenerator unprotectedAttributeGenerator = null;
  final SecureRandom rand;

  public CMSEnvelopedGenerator()
  {
    this(new SecureRandom());
  }

  public CMSEnvelopedGenerator(SecureRandom paramSecureRandom)
  {
    this.rand = paramSecureRandom;
  }

  public void setUnprotectedAttributeGenerator(CMSAttributeTableGenerator paramCMSAttributeTableGenerator)
  {
    this.unprotectedAttributeGenerator = paramCMSAttributeTableGenerator;
  }

  /** @deprecated */
  public void addKeyTransRecipient(X509Certificate paramX509Certificate)
    throws IllegalArgumentException
  {
    KeyTransIntRecipientInfoGenerator localKeyTransIntRecipientInfoGenerator = new KeyTransIntRecipientInfoGenerator();
    localKeyTransIntRecipientInfoGenerator.setRecipientCert(paramX509Certificate);
    this.oldRecipientInfoGenerators.add(localKeyTransIntRecipientInfoGenerator);
  }

  /** @deprecated */
  public void addKeyTransRecipient(PublicKey paramPublicKey, byte[] paramArrayOfByte)
    throws IllegalArgumentException
  {
    KeyTransIntRecipientInfoGenerator localKeyTransIntRecipientInfoGenerator = new KeyTransIntRecipientInfoGenerator();
    localKeyTransIntRecipientInfoGenerator.setRecipientPublicKey(paramPublicKey);
    localKeyTransIntRecipientInfoGenerator.setSubjectKeyIdentifier(new DEROctetString(paramArrayOfByte));
    this.oldRecipientInfoGenerators.add(localKeyTransIntRecipientInfoGenerator);
  }

  /** @deprecated */
  public void addKEKRecipient(SecretKey paramSecretKey, byte[] paramArrayOfByte)
  {
    addKEKRecipient(paramSecretKey, new KEKIdentifier(paramArrayOfByte, null, null));
  }

  /** @deprecated */
  public void addKEKRecipient(SecretKey paramSecretKey, KEKIdentifier paramKEKIdentifier)
  {
    KEKIntRecipientInfoGenerator localKEKIntRecipientInfoGenerator = new KEKIntRecipientInfoGenerator();
    localKEKIntRecipientInfoGenerator.setKEKIdentifier(paramKEKIdentifier);
    localKEKIntRecipientInfoGenerator.setKeyEncryptionKey(paramSecretKey);
    this.oldRecipientInfoGenerators.add(localKEKIntRecipientInfoGenerator);
  }

  /** @deprecated */
  public void addPasswordRecipient(CMSPBEKey paramCMSPBEKey, String paramString)
  {
    PBKDF2Params localPBKDF2Params = new PBKDF2Params(paramCMSPBEKey.getSalt(), paramCMSPBEKey.getIterationCount());
    PasswordIntRecipientInfoGenerator localPasswordIntRecipientInfoGenerator = new PasswordIntRecipientInfoGenerator();
    localPasswordIntRecipientInfoGenerator.setKeyDerivationAlgorithm(new AlgorithmIdentifier(PKCSObjectIdentifiers.id_PBKDF2, localPBKDF2Params));
    localPasswordIntRecipientInfoGenerator.setKeyEncryptionKey(new SecretKeySpec(paramCMSPBEKey.getEncoded(paramString), paramString));
    this.oldRecipientInfoGenerators.add(localPasswordIntRecipientInfoGenerator);
  }

  /** @deprecated */
  public void addKeyAgreementRecipient(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, X509Certificate paramX509Certificate, String paramString2, String paramString3)
    throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException
  {
    addKeyAgreementRecipient(paramString1, paramPrivateKey, paramPublicKey, paramX509Certificate, paramString2, CMSUtils.getProvider(paramString3));
  }

  /** @deprecated */
  public void addKeyAgreementRecipient(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, X509Certificate paramX509Certificate, String paramString2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addKeyAgreementRecipients(paramString1, paramPrivateKey, paramPublicKey, Collections.singletonList(paramX509Certificate), paramString2, paramProvider);
  }

  /** @deprecated */
  public void addKeyAgreementRecipients(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, Collection paramCollection, String paramString2, String paramString3)
    throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException
  {
    addKeyAgreementRecipients(paramString1, paramPrivateKey, paramPublicKey, paramCollection, paramString2, CMSUtils.getProvider(paramString3));
  }

  /** @deprecated */
  public void addKeyAgreementRecipients(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, Collection paramCollection, String paramString2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    KeyAgreeIntRecipientInfoGenerator localKeyAgreeIntRecipientInfoGenerator = new KeyAgreeIntRecipientInfoGenerator();
    localKeyAgreeIntRecipientInfoGenerator.setKeyAgreementOID(new DERObjectIdentifier(paramString1));
    localKeyAgreeIntRecipientInfoGenerator.setKeyEncryptionOID(new DERObjectIdentifier(paramString2));
    localKeyAgreeIntRecipientInfoGenerator.setRecipientCerts(paramCollection);
    localKeyAgreeIntRecipientInfoGenerator.setSenderKeyPair(new KeyPair(paramPublicKey, paramPrivateKey));
    this.oldRecipientInfoGenerators.add(localKeyAgreeIntRecipientInfoGenerator);
  }

  public void addRecipientInfoGenerator(RecipientInfoGenerator paramRecipientInfoGenerator)
  {
    this.recipientInfoGenerators.add(paramRecipientInfoGenerator);
  }

  protected AlgorithmIdentifier getAlgorithmIdentifier(String paramString, AlgorithmParameters paramAlgorithmParameters)
    throws IOException
  {
    Object localObject;
    if (paramAlgorithmParameters != null)
      localObject = ASN1Object.fromByteArray(paramAlgorithmParameters.getEncoded("ASN.1"));
    else
      localObject = DERNull.INSTANCE;
    return (AlgorithmIdentifier)new AlgorithmIdentifier(new DERObjectIdentifier(paramString), (DEREncodable)localObject);
  }

  protected AlgorithmParameters generateParameters(String paramString, SecretKey paramSecretKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      AlgorithmParameterGenerator localAlgorithmParameterGenerator = AlgorithmParameterGenerator.getInstance(paramString, paramProvider);
      if (paramString.equals(RC2_CBC))
      {
        byte[] arrayOfByte = new byte[8];
        this.rand.nextBytes(arrayOfByte);
        try
        {
          localAlgorithmParameterGenerator.init(new RC2ParameterSpec(paramSecretKey.getEncoded().length * 8, arrayOfByte), this.rand);
        }
        catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
        {
          throw new CMSException("parameters generation error: " + localInvalidAlgorithmParameterException, localInvalidAlgorithmParameterException);
        }
      }
      return localAlgorithmParameterGenerator.generateParameters();
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
    }
    return null;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSEnvelopedGenerator
 * JD-Core Version:    0.6.0
 */