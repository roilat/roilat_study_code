package org.bouncycastle.cms;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.spec.InvalidParameterSpecException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import org.bouncycastle.asn1.ASN1Null;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.KEKRecipientInfo;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientInfo;
import org.bouncycastle.asn1.cms.KeyTransRecipientInfo;
import org.bouncycastle.asn1.cms.PasswordRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.util.io.TeeInputStream;

class CMSEnvelopedHelper
{
  static final CMSEnvelopedHelper INSTANCE = new CMSEnvelopedHelper();
  private static final Map KEYSIZES = new HashMap();
  private static final Map BASE_CIPHER_NAMES = new HashMap();
  private static final Map CIPHER_ALG_NAMES = new HashMap();
  private static final Map MAC_ALG_NAMES = new HashMap();

  String getAsymmetricEncryptionAlgName(String paramString)
  {
    if (PKCSObjectIdentifiers.rsaEncryption.getId().equals(paramString))
      return "RSA/ECB/PKCS1Padding";
    return paramString;
  }

  Cipher createAsymmetricCipher(String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException
  {
    String str = getAsymmetricEncryptionAlgName(paramString1);
    if (!str.equals(paramString1))
      try
      {
        return Cipher.getInstance(str, paramString2);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
      }
    return Cipher.getInstance(paramString1, paramString2);
  }

  Cipher createAsymmetricCipher(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    String str = getAsymmetricEncryptionAlgName(paramString);
    if (!str.equals(paramString))
      try
      {
        return getCipherInstance(str, paramProvider);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
      }
    return getCipherInstance(paramString, paramProvider);
  }

  KeyGenerator createSymmetricKeyGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    try
    {
      return createKeyGenerator(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      try
      {
        String str = (String)BASE_CIPHER_NAMES.get(paramString);
        if (str != null)
          return createKeyGenerator(str, paramProvider);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
      {
      }
      if (paramProvider != null)
        return createSymmetricKeyGenerator(paramString, null);
    }
    throw localNoSuchAlgorithmException1;
  }

  AlgorithmParameters createAlgorithmParameters(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    try
    {
      return createAlgorithmParams(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      try
      {
        String str = (String)BASE_CIPHER_NAMES.get(paramString);
        if (str != null)
          return createAlgorithmParams(str, paramProvider);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
      {
      }
    }
    throw localNoSuchAlgorithmException1;
  }

  AlgorithmParameterGenerator createAlgorithmParameterGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    try
    {
      return createAlgorithmParamsGenerator(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      try
      {
        String str = (String)BASE_CIPHER_NAMES.get(paramString);
        if (str != null)
          return createAlgorithmParamsGenerator(str, paramProvider);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
      {
      }
    }
    throw localNoSuchAlgorithmException1;
  }

  String getRFC3211WrapperName(String paramString)
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramString);
    if (str == null)
      throw new IllegalArgumentException("no name for " + paramString);
    return str + "RFC3211Wrap";
  }

  int getKeySize(String paramString)
  {
    Integer localInteger = (Integer)KEYSIZES.get(paramString);
    if (localInteger == null)
      throw new IllegalArgumentException("no keysize for " + paramString);
    return localInteger.intValue();
  }

  private Cipher getCipherInstance(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    if (paramProvider != null)
      return Cipher.getInstance(paramString, paramProvider);
    return Cipher.getInstance(paramString);
  }

  private AlgorithmParameters createAlgorithmParams(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    if (paramProvider != null)
      return AlgorithmParameters.getInstance(paramString, paramProvider);
    return AlgorithmParameters.getInstance(paramString);
  }

  private AlgorithmParameterGenerator createAlgorithmParamsGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    if (paramProvider != null)
      return AlgorithmParameterGenerator.getInstance(paramString, paramProvider);
    return AlgorithmParameterGenerator.getInstance(paramString);
  }

  private KeyGenerator createKeyGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    if (paramProvider != null)
      return KeyGenerator.getInstance(paramString, paramProvider);
    return KeyGenerator.getInstance(paramString);
  }

  Cipher createSymmetricCipher(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    try
    {
      return getCipherInstance(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      String str = (String)CIPHER_ALG_NAMES.get(paramString);
      try
      {
        return getCipherInstance(str, paramProvider);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
      {
        if (paramProvider != null)
          return createSymmetricCipher(paramString, null);
      }
    }
    throw localNoSuchAlgorithmException1;
  }

  private Mac createMac(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    if (paramProvider != null)
      return Mac.getInstance(paramString, paramProvider);
    return Mac.getInstance(paramString);
  }

  Mac getMac(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    try
    {
      return createMac(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      String str = (String)MAC_ALG_NAMES.get(paramString);
      try
      {
        return createMac(str, paramProvider);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
      {
        if (paramProvider != null)
          return getMac(paramString, null);
      }
    }
    throw localNoSuchAlgorithmException1;
  }

  AlgorithmParameters getEncryptionAlgorithmParameters(String paramString, byte[] paramArrayOfByte, Provider paramProvider)
    throws CMSException
  {
    if (paramArrayOfByte == null)
      return null;
    try
    {
      AlgorithmParameters localAlgorithmParameters = createAlgorithmParameters(paramString, paramProvider);
      localAlgorithmParameters.init(paramArrayOfByte, "ASN.1");
      return localAlgorithmParameters;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find parameters for algorithm", localNoSuchAlgorithmException);
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("can't find parse parameters", localIOException);
  }

  String getSymmetricCipherName(String paramString)
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramString);
    if (str != null)
      return str;
    return paramString;
  }

  static RecipientInformationStore buildRecipientInformationStore(ASN1Set paramASN1Set, AlgorithmIdentifier paramAlgorithmIdentifier, CMSSecureReadable paramCMSSecureReadable)
  {
    return buildRecipientInformationStore(paramASN1Set, paramAlgorithmIdentifier, paramCMSSecureReadable, null);
  }

  static RecipientInformationStore buildRecipientInformationStore(ASN1Set paramASN1Set, AlgorithmIdentifier paramAlgorithmIdentifier, CMSSecureReadable paramCMSSecureReadable, AuthAttributesProvider paramAuthAttributesProvider)
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i != paramASN1Set.size(); i++)
    {
      RecipientInfo localRecipientInfo = RecipientInfo.getInstance(paramASN1Set.getObjectAt(i));
      readRecipientInfo(localArrayList, localRecipientInfo, paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider);
    }
    return new RecipientInformationStore(localArrayList);
  }

  private static void readRecipientInfo(List paramList, RecipientInfo paramRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier, CMSSecureReadable paramCMSSecureReadable, AuthAttributesProvider paramAuthAttributesProvider)
  {
    DEREncodable localDEREncodable = paramRecipientInfo.getInfo();
    if ((localDEREncodable instanceof KeyTransRecipientInfo))
      paramList.add(new KeyTransRecipientInformation((KeyTransRecipientInfo)localDEREncodable, paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider));
    else if ((localDEREncodable instanceof KEKRecipientInfo))
      paramList.add(new KEKRecipientInformation((KEKRecipientInfo)localDEREncodable, paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider));
    else if ((localDEREncodable instanceof KeyAgreeRecipientInfo))
      KeyAgreeRecipientInformation.readRecipientInfo(paramList, (KeyAgreeRecipientInfo)localDEREncodable, paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider);
    else if ((localDEREncodable instanceof PasswordRecipientInfo))
      paramList.add(new PasswordRecipientInformation((PasswordRecipientInfo)localDEREncodable, paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider));
  }

  static Object execute(JCECallback paramJCECallback)
    throws CMSException
  {
    try
    {
      return paramJCECallback.doInJCE();
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameters invalid.", localInvalidAlgorithmParameterException);
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException)
    {
    }
    throw new CMSException("MAC algorithm parameter spec invalid.", localInvalidParameterSpecException);
  }

  static
  {
    KEYSIZES.put(CMSEnvelopedGenerator.DES_EDE3_CBC, new Integer(192));
    KEYSIZES.put(CMSEnvelopedGenerator.AES128_CBC, new Integer(128));
    KEYSIZES.put(CMSEnvelopedGenerator.AES192_CBC, new Integer(192));
    KEYSIZES.put(CMSEnvelopedGenerator.AES256_CBC, new Integer(256));
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.DES_EDE3_CBC, "DESEDE");
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.AES128_CBC, "AES");
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.AES192_CBC, "AES");
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.AES256_CBC, "AES");
    CIPHER_ALG_NAMES.put(CMSEnvelopedGenerator.DES_EDE3_CBC, "DESEDE/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSEnvelopedGenerator.AES128_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSEnvelopedGenerator.AES192_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSEnvelopedGenerator.AES256_CBC, "AES/CBC/PKCS5Padding");
    MAC_ALG_NAMES.put(CMSEnvelopedGenerator.DES_EDE3_CBC, "DESEDEMac");
    MAC_ALG_NAMES.put(CMSEnvelopedGenerator.AES128_CBC, "AESMac");
    MAC_ALG_NAMES.put(CMSEnvelopedGenerator.AES192_CBC, "AESMac");
    MAC_ALG_NAMES.put(CMSEnvelopedGenerator.AES256_CBC, "AESMac");
  }

  static class CMSAuthenticatedSecureReadable
    implements CMSSecureReadable
  {
    private AlgorithmIdentifier algorithm;
    private Mac mac;
    private CMSReadable readable;

    CMSAuthenticatedSecureReadable(AlgorithmIdentifier paramAlgorithmIdentifier, CMSReadable paramCMSReadable)
    {
      this.algorithm = paramAlgorithmIdentifier;
      this.readable = paramCMSReadable;
    }

    public AlgorithmIdentifier getAlgorithm()
    {
      return this.algorithm;
    }

    public Object getCryptoObject()
    {
      return this.mac;
    }

    public InputStream getInputStream()
      throws IOException, CMSException
    {
      return this.readable.getInputStream();
    }

    public CMSReadable getReadable(SecretKey paramSecretKey, Provider paramProvider)
      throws CMSException
    {
      String str = this.algorithm.getObjectId().getId();
      ASN1Object localASN1Object = (ASN1Object)this.algorithm.getParameters();
      this.mac = ((Mac)CMSEnvelopedHelper.execute(new CMSEnvelopedHelper.JCECallback(str, paramProvider, localASN1Object, paramSecretKey)
      {
        public Object doInJCE()
          throws CMSException, InvalidAlgorithmParameterException, InvalidKeyException, InvalidParameterSpecException, NoSuchAlgorithmException, NoSuchPaddingException
        {
          Mac localMac = CMSEnvelopedHelper.INSTANCE.getMac(this.val$macAlg, this.val$provider);
          if ((this.val$sParams != null) && (!(this.val$sParams instanceof ASN1Null)))
          {
            AlgorithmParameters localAlgorithmParameters = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameters(this.val$macAlg, this.val$provider);
            try
            {
              localAlgorithmParameters.init(this.val$sParams.getEncoded(), "ASN.1");
            }
            catch (IOException localIOException)
            {
              throw new CMSException("error decoding algorithm parameters.", localIOException);
            }
            localMac.init(this.val$sKey, localAlgorithmParameters.getParameterSpec(IvParameterSpec.class));
          }
          else
          {
            localMac.init(this.val$sKey);
          }
          return localMac;
        }
      }));
      try
      {
        return new CMSProcessableInputStream(new TeeInputStream(this.readable.getInputStream(), new MacOutputStream(this.mac)));
      }
      catch (IOException localIOException)
      {
      }
      throw new CMSException("error reading content.", localIOException);
    }
  }

  static class CMSDigestAuthenticatedSecureReadable
    implements CMSSecureReadable
  {
    private DigestCalculator digestCalculator;
    private CMSReadable readable;

    public CMSDigestAuthenticatedSecureReadable(DigestCalculator paramDigestCalculator, CMSReadable paramCMSReadable)
    {
      this.digestCalculator = paramDigestCalculator;
      this.readable = paramCMSReadable;
    }

    public AlgorithmIdentifier getAlgorithm()
    {
      return null;
    }

    public Object getCryptoObject()
    {
      return null;
    }

    public CMSReadable getReadable(SecretKey paramSecretKey, Provider paramProvider)
      throws CMSException
    {
      return null;
    }

    public InputStream getInputStream()
      throws IOException, CMSException
    {
      return new FilterInputStream(this.readable.getInputStream())
      {
        public int read()
          throws IOException
        {
          int i = this.in.read();
          if (i >= 0)
            CMSEnvelopedHelper.CMSDigestAuthenticatedSecureReadable.this.digestCalculator.getOutputStream().write(i);
          return i;
        }

        public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
          throws IOException
        {
          int i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
          if (i >= 0)
            CMSEnvelopedHelper.CMSDigestAuthenticatedSecureReadable.this.digestCalculator.getOutputStream().write(paramArrayOfByte, paramInt1, i);
          return i;
        }
      };
    }

    public byte[] getDigest()
    {
      return this.digestCalculator.getDigest();
    }
  }

  static class CMSEnvelopedSecureReadable
    implements CMSSecureReadable
  {
    private AlgorithmIdentifier algorithm;
    private Cipher cipher;
    private CMSReadable readable;

    CMSEnvelopedSecureReadable(AlgorithmIdentifier paramAlgorithmIdentifier, CMSReadable paramCMSReadable)
    {
      this.algorithm = paramAlgorithmIdentifier;
      this.readable = paramCMSReadable;
    }

    public AlgorithmIdentifier getAlgorithm()
    {
      return this.algorithm;
    }

    public InputStream getInputStream()
      throws IOException, CMSException
    {
      return this.readable.getInputStream();
    }

    public Object getCryptoObject()
    {
      return this.cipher;
    }

    public CMSReadable getReadable(SecretKey paramSecretKey, Provider paramProvider)
      throws CMSException
    {
      String str = this.algorithm.getObjectId().getId();
      ASN1Object localASN1Object = (ASN1Object)this.algorithm.getParameters();
      this.cipher = ((Cipher)CMSEnvelopedHelper.execute(new CMSEnvelopedHelper.JCECallback(str, paramProvider, localASN1Object, paramSecretKey)
      {
        public Object doInJCE()
          throws CMSException, InvalidAlgorithmParameterException, InvalidKeyException, InvalidParameterSpecException, NoSuchAlgorithmException, NoSuchPaddingException
        {
          Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createSymmetricCipher(this.val$encAlg, this.val$provider);
          if ((this.val$sParams != null) && (!(this.val$sParams instanceof ASN1Null)))
            try
            {
              AlgorithmParameters localAlgorithmParameters = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameters(this.val$encAlg, localCipher.getProvider());
              try
              {
                localAlgorithmParameters.init(this.val$sParams.getEncoded(), "ASN.1");
              }
              catch (IOException localIOException)
              {
                throw new CMSException("error decoding algorithm parameters.", localIOException);
              }
              localCipher.init(2, this.val$sKey, localAlgorithmParameters);
            }
            catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
            {
              if ((this.val$encAlg.equals(CMSEnvelopedDataGenerator.DES_EDE3_CBC)) || (this.val$encAlg.equals("1.3.6.1.4.1.188.7.1.1.2")) || (this.val$encAlg.equals(CMSEnvelopedDataGenerator.AES128_CBC)) || (this.val$encAlg.equals(CMSEnvelopedDataGenerator.AES192_CBC)) || (this.val$encAlg.equals(CMSEnvelopedDataGenerator.AES256_CBC)))
                localCipher.init(2, this.val$sKey, new IvParameterSpec(ASN1OctetString.getInstance(this.val$sParams).getOctets()));
              else
                throw localNoSuchAlgorithmException;
            }
          else if ((this.val$encAlg.equals(CMSEnvelopedDataGenerator.DES_EDE3_CBC)) || (this.val$encAlg.equals("1.3.6.1.4.1.188.7.1.1.2")) || (this.val$encAlg.equals("1.2.840.113533.7.66.10")))
            localCipher.init(2, this.val$sKey, new IvParameterSpec(new byte[8]));
          else
            localCipher.init(2, this.val$sKey);
          return localCipher;
        }
      }));
      try
      {
        return new CMSProcessableInputStream(new CipherInputStream(this.readable.getInputStream(), this.cipher));
      }
      catch (IOException localIOException)
      {
      }
      throw new CMSException("error reading content.", localIOException);
    }
  }

  static abstract interface JCECallback
  {
    public abstract Object doInJCE()
      throws CMSException, InvalidAlgorithmParameterException, InvalidKeyException, InvalidParameterSpecException, NoSuchAlgorithmException, NoSuchPaddingException;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSEnvelopedHelper
 * JD-Core Version:    0.6.0
 */