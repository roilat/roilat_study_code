package org.bouncycastle.cms;

import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.spec.InvalidParameterSpecException;
import javax.crypto.interfaces.PBEKey;
import javax.crypto.spec.PBEParameterSpec;

public abstract class CMSPBEKey
  implements PBEKey
{
  private char[] password;
  private byte[] salt;
  private int iterationCount;

  protected static PBEParameterSpec getParamSpec(AlgorithmParameters paramAlgorithmParameters)
    throws InvalidAlgorithmParameterException
  {
    try
    {
      return (PBEParameterSpec)paramAlgorithmParameters.getParameterSpec(PBEParameterSpec.class);
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException)
    {
    }
    throw new InvalidAlgorithmParameterException("cannot process PBE spec: " + localInvalidParameterSpecException.getMessage());
  }

  public CMSPBEKey(char[] paramArrayOfChar, byte[] paramArrayOfByte, int paramInt)
  {
    this.password = paramArrayOfChar;
    this.salt = paramArrayOfByte;
    this.iterationCount = paramInt;
  }

  public CMSPBEKey(char[] paramArrayOfChar, PBEParameterSpec paramPBEParameterSpec)
  {
    this(paramArrayOfChar, paramPBEParameterSpec.getSalt(), paramPBEParameterSpec.getIterationCount());
  }

  public char[] getPassword()
  {
    return this.password;
  }

  public byte[] getSalt()
  {
    return this.salt;
  }

  public int getIterationCount()
  {
    return this.iterationCount;
  }

  public String getAlgorithm()
  {
    return "PKCS5S2";
  }

  public String getFormat()
  {
    return "RAW";
  }

  public byte[] getEncoded()
  {
    return null;
  }

  abstract byte[] getEncoded(String paramString);
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSPBEKey
 * JD-Core Version:    0.6.0
 */