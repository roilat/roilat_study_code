package org.bouncycastle.cms;

import B;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;

public class CMSProcessableByteArray
  implements CMSTypedData, CMSReadable
{
  private final ASN1ObjectIdentifier type;
  private final byte[] bytes;

  public CMSProcessableByteArray(byte[] paramArrayOfByte)
  {
    this(new ASN1ObjectIdentifier(CMSObjectIdentifiers.data.getId()), paramArrayOfByte);
  }

  public CMSProcessableByteArray(ASN1ObjectIdentifier paramASN1ObjectIdentifier, byte[] paramArrayOfByte)
  {
    this.type = paramASN1ObjectIdentifier;
    this.bytes = paramArrayOfByte;
  }

  public InputStream getInputStream()
  {
    return new ByteArrayInputStream(this.bytes);
  }

  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
    paramOutputStream.write(this.bytes);
  }

  public Object getContent()
  {
    return this.bytes.clone();
  }

  public ASN1ObjectIdentifier getContentType()
  {
    return this.type;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSProcessableByteArray
 * JD-Core Version:    0.6.0
 */