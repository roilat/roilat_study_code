package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;

abstract interface CMSReadable
{
  public abstract InputStream getInputStream()
    throws IOException, CMSException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSReadable
 * JD-Core Version:    0.6.0
 */