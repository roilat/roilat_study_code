package org.bouncycastle.cms;

public class CMSRuntimeException extends RuntimeException
{
  Exception e;

  public CMSRuntimeException(String paramString)
  {
    super(paramString);
  }

  public CMSRuntimeException(String paramString, Exception paramException)
  {
    super(paramString);
    this.e = paramException;
  }

  public Exception getUnderlyingException()
  {
    return this.e;
  }

  public Throwable getCause()
  {
    return this.e;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSRuntimeException
 * JD-Core Version:    0.6.0
 */