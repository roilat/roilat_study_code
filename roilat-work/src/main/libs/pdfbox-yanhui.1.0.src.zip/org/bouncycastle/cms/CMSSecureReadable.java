package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.security.Provider;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

abstract interface CMSSecureReadable
{
  public abstract AlgorithmIdentifier getAlgorithm();

  public abstract Object getCryptoObject();

  public abstract CMSReadable getReadable(SecretKey paramSecretKey, Provider paramProvider)
    throws CMSException;

  public abstract InputStream getInputStream()
    throws IOException, CMSException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSSecureReadable
 * JD-Core Version:    0.6.0
 */