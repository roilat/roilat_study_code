package org.bouncycastle.cms;

import B;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERConstructedOctetString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DEROutputStream;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.cms.SignedData;
import org.bouncycastle.asn1.cms.SignerIdentifier;
import org.bouncycastle.asn1.cms.SignerInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSSignedDataGenerator extends CMSSignedGenerator
{
  private List signerInfs = new ArrayList();

  public CMSSignedDataGenerator()
  {
  }

  public CMSSignedDataGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramX509Certificate, getEncOID(paramPrivateKey, paramString), paramString);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2)
    throws IllegalArgumentException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramX509Certificate), paramString1, paramString2, new DefaultSignedAttributeTableGenerator(), null, null);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, getEncOID(paramPrivateKey, paramString), paramString);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2)
    throws IllegalArgumentException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramArrayOfByte), paramString1, paramString2, new DefaultSignedAttributeTableGenerator(), null, null);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramX509Certificate, getEncOID(paramPrivateKey, paramString), paramString, paramAttributeTable1, paramAttributeTable2);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramX509Certificate), paramString1, paramString2, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramAttributeTable1);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, getEncOID(paramPrivateKey, paramString), paramString, paramAttributeTable1, paramAttributeTable2);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramArrayOfByte), paramString1, paramString2, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramAttributeTable1);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramX509Certificate, getEncOID(paramPrivateKey, paramString), paramString, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
    throws IllegalArgumentException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramX509Certificate), paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, null);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, getEncOID(paramPrivateKey, paramString), paramString, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
    throws IllegalArgumentException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramArrayOfByte), paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, null);
  }

  private void doAddSigner(PrivateKey paramPrivateKey, SignerIdentifier paramSignerIdentifier, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, AttributeTable paramAttributeTable)
    throws IllegalArgumentException
  {
    this.signerInfs.add(new SignerInf(paramPrivateKey, paramSignerIdentifier, paramString2, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramAttributeTable));
  }

  public CMSSignedData generate(CMSProcessable paramCMSProcessable, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramCMSProcessable, CMSUtils.getProvider(paramString));
  }

  public CMSSignedData generate(CMSProcessable paramCMSProcessable, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    return generate(paramCMSProcessable, false, paramProvider);
  }

  /** @deprecated */
  public CMSSignedData generate(String paramString1, CMSProcessable paramCMSProcessable, boolean paramBoolean, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramString1, paramCMSProcessable, paramBoolean, CMSUtils.getProvider(paramString2), true);
  }

  /** @deprecated */
  public CMSSignedData generate(String paramString, CMSProcessable paramCMSProcessable, boolean paramBoolean, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    return generate(paramString, paramCMSProcessable, paramBoolean, paramProvider, true);
  }

  /** @deprecated */
  public CMSSignedData generate(String paramString1, CMSProcessable paramCMSProcessable, boolean paramBoolean1, String paramString2, boolean paramBoolean2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramString1, paramCMSProcessable, paramBoolean1, CMSUtils.getProvider(paramString2), paramBoolean2);
  }

  public CMSSignedData generate(String paramString, CMSProcessable paramCMSProcessable, boolean paramBoolean1, Provider paramProvider, boolean paramBoolean2)
    throws NoSuchAlgorithmException, CMSException
  {
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
    this.digests.clear();
    Iterator localIterator = this._signers.iterator();
    while (localIterator.hasNext())
    {
      localObject1 = (SignerInformation)localIterator.next();
      localASN1EncodableVector1.add(CMSSignedHelper.INSTANCE.fixAlgID(((SignerInformation)localObject1).getDigestAlgorithmID()));
      localASN1EncodableVector2.add(((SignerInformation)localObject1).toSignerInfo());
    }
    int i = paramString == null ? 1 : 0;
    Object localObject1 = i != 0 ? null : new ASN1ObjectIdentifier(paramString);
    Object localObject2 = this.signerGens.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (SignerInfoGenerator)((Iterator)localObject2).next();
      if (paramCMSProcessable != null)
      {
        localObject4 = ((SignerInfoGenerator)localObject3).getCalculatingOutputStream();
        try
        {
          paramCMSProcessable.write((OutputStream)localObject4);
          ((OutputStream)localObject4).close();
        }
        catch (IOException localIOException2)
        {
          throw new CMSException("data processing exception: " + localIOException2.getMessage(), localIOException2);
        }
      }
      Object localObject4 = ((SignerInfoGenerator)localObject3).generate((ASN1ObjectIdentifier)localObject1);
      localASN1EncodableVector1.add(((SignerInfo)localObject4).getDigestAlgorithm());
      localASN1EncodableVector2.add((DEREncodable)localObject4);
    }
    localObject2 = this.signerInfs.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (SignerInf)((Iterator)localObject2).next();
      try
      {
        localASN1EncodableVector1.add(((SignerInf)localObject3).getDigestAlgorithmID());
        localASN1EncodableVector2.add(((SignerInf)localObject3).toSignerInfo((DERObjectIdentifier)localObject1, paramCMSProcessable, this.rand, paramProvider, paramBoolean2));
      }
      catch (IOException localIOException1)
      {
        throw new CMSException("encoding error.", localIOException1);
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        throw new CMSException("key inappropriate for signature.", localInvalidKeyException);
      }
      catch (SignatureException localSignatureException)
      {
        throw new CMSException("error creating signature.", localSignatureException);
      }
      catch (CertificateEncodingException localCertificateEncodingException)
      {
        throw new CMSException("error creating sid.", localCertificateEncodingException);
      }
    }
    localObject2 = null;
    if (this.certs.size() != 0)
      localObject2 = CMSUtils.createBerSetFromList(this.certs);
    Object localObject3 = null;
    if (this.crls.size() != 0)
      localObject3 = CMSUtils.createBerSetFromList(this.crls);
    BERConstructedOctetString localBERConstructedOctetString = null;
    if (paramBoolean1)
    {
      localObject5 = new ByteArrayOutputStream();
      if (paramCMSProcessable != null)
        try
        {
          paramCMSProcessable.write((OutputStream)localObject5);
        }
        catch (IOException localIOException3)
        {
          throw new CMSException("encapsulation error.", localIOException3);
        }
      localBERConstructedOctetString = new BERConstructedOctetString(((ByteArrayOutputStream)localObject5).toByteArray());
    }
    Object localObject5 = new ContentInfo((ASN1ObjectIdentifier)localObject1, localBERConstructedOctetString);
    SignedData localSignedData = new SignedData(new DERSet(localASN1EncodableVector1), (ContentInfo)localObject5, (ASN1Set)localObject2, (ASN1Set)localObject3, new DERSet(localASN1EncodableVector2));
    ContentInfo localContentInfo = new ContentInfo(CMSObjectIdentifiers.signedData, localSignedData);
    return (CMSSignedData)(CMSSignedData)(CMSSignedData)(CMSSignedData)(CMSSignedData)new CMSSignedData(paramCMSProcessable, localContentInfo);
  }

  /** @deprecated */
  public CMSSignedData generate(CMSProcessable paramCMSProcessable, boolean paramBoolean, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    if ((paramCMSProcessable instanceof CMSTypedData))
      return generate(((CMSTypedData)paramCMSProcessable).getContentType().getId(), paramCMSProcessable, paramBoolean, paramString);
    return generate(DATA, paramCMSProcessable, paramBoolean, paramString);
  }

  /** @deprecated */
  public CMSSignedData generate(CMSProcessable paramCMSProcessable, boolean paramBoolean, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    if ((paramCMSProcessable instanceof CMSTypedData))
      return generate(((CMSTypedData)paramCMSProcessable).getContentType().getId(), paramCMSProcessable, paramBoolean, paramProvider);
    return generate(DATA, paramCMSProcessable, paramBoolean, paramProvider);
  }

  public CMSSignedData generate(CMSTypedData paramCMSTypedData)
    throws CMSException
  {
    return generate(paramCMSTypedData, false);
  }

  public CMSSignedData generate(CMSTypedData paramCMSTypedData, boolean paramBoolean)
    throws CMSException
  {
    if (!this.signerInfs.isEmpty())
      throw new IllegalStateException("this method can only be used with SignerInfoGenerator");
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
    this.digests.clear();
    Object localObject1 = this._signers.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (SignerInformation)((Iterator)localObject1).next();
      localASN1EncodableVector1.add(CMSSignedHelper.INSTANCE.fixAlgID(((SignerInformation)localObject2).getDigestAlgorithmID()));
      localASN1EncodableVector2.add(((SignerInformation)localObject2).toSignerInfo());
    }
    localObject1 = paramCMSTypedData.getContentType();
    Object localObject2 = null;
    if (paramBoolean)
    {
      localObject3 = new ByteArrayOutputStream();
      if (paramCMSTypedData != null)
        try
        {
          paramCMSTypedData.write((OutputStream)localObject3);
        }
        catch (IOException localIOException1)
        {
          throw new CMSException("encapsulation error.", localIOException1);
        }
      localObject2 = new BERConstructedOctetString(((ByteArrayOutputStream)localObject3).toByteArray());
    }
    if (paramCMSTypedData != null)
    {
      localObject3 = null;
      if (paramBoolean)
        localObject3 = new ByteArrayOutputStream();
      localObject4 = CMSUtils.attachSignersToOutputStream(this.signerGens, (OutputStream)localObject3);
      localObject4 = CMSUtils.getSafeOutputStream((OutputStream)localObject4);
      try
      {
        paramCMSTypedData.write((OutputStream)localObject4);
        ((OutputStream)localObject4).close();
      }
      catch (IOException localIOException2)
      {
        throw new CMSException("data processing exception: " + localIOException2.getMessage(), localIOException2);
      }
      if (paramBoolean)
        localObject2 = new BERConstructedOctetString(((ByteArrayOutputStream)localObject3).toByteArray());
    }
    Object localObject3 = this.signerGens.iterator();
    while (((Iterator)localObject3).hasNext())
    {
      localObject4 = (SignerInfoGenerator)((Iterator)localObject3).next();
      localObject5 = ((SignerInfoGenerator)localObject4).generate((ASN1ObjectIdentifier)localObject1);
      localASN1EncodableVector1.add(((SignerInfo)localObject5).getDigestAlgorithm());
      localASN1EncodableVector2.add((DEREncodable)localObject5);
      localObject6 = ((SignerInfoGenerator)localObject4).getCalculatedDigest();
      if (localObject6 != null)
        this.digests.put(((SignerInfo)localObject5).getDigestAlgorithm().getAlgorithm().getId(), localObject6);
    }
    localObject3 = null;
    if (this.certs.size() != 0)
      localObject3 = CMSUtils.createBerSetFromList(this.certs);
    Object localObject4 = null;
    if (this.crls.size() != 0)
      localObject4 = CMSUtils.createBerSetFromList(this.crls);
    Object localObject5 = new ContentInfo((ASN1ObjectIdentifier)localObject1, (DEREncodable)localObject2);
    Object localObject6 = new SignedData(new DERSet(localASN1EncodableVector1), (ContentInfo)localObject5, (ASN1Set)localObject3, (ASN1Set)localObject4, new DERSet(localASN1EncodableVector2));
    ContentInfo localContentInfo = new ContentInfo(CMSObjectIdentifiers.signedData, (DEREncodable)localObject6);
    return (CMSSignedData)(CMSSignedData)(CMSSignedData)(CMSSignedData)(CMSSignedData)(CMSSignedData)new CMSSignedData(paramCMSTypedData, localContentInfo);
  }

  /** @deprecated */
  public SignerInformationStore generateCounterSigners(SignerInformation paramSignerInformation, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    return generate(null, new CMSProcessableByteArray(paramSignerInformation.getSignature()), false, paramProvider).getSignerInfos();
  }

  /** @deprecated */
  public SignerInformationStore generateCounterSigners(SignerInformation paramSignerInformation, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(null, new CMSProcessableByteArray(paramSignerInformation.getSignature()), false, CMSUtils.getProvider(paramString)).getSignerInfos();
  }

  public SignerInformationStore generateCounterSigners(SignerInformation paramSignerInformation)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(new CMSProcessableByteArray(null, paramSignerInformation.getSignature()), false).getSignerInfos();
  }

  private class SignerInf
  {
    final PrivateKey key;
    final SignerIdentifier signerIdentifier;
    final String digestOID;
    final String encOID;
    final CMSAttributeTableGenerator sAttr;
    final CMSAttributeTableGenerator unsAttr;
    final AttributeTable baseSignedTable;

    SignerInf(PrivateKey paramSignerIdentifier, SignerIdentifier paramString1, String paramString2, String paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, CMSAttributeTableGenerator paramAttributeTable, AttributeTable arg8)
    {
      this.key = paramSignerIdentifier;
      this.signerIdentifier = paramString1;
      this.digestOID = paramString2;
      this.encOID = paramCMSAttributeTableGenerator1;
      this.sAttr = paramCMSAttributeTableGenerator2;
      this.unsAttr = paramAttributeTable;
      Object localObject;
      this.baseSignedTable = localObject;
    }

    AlgorithmIdentifier getDigestAlgorithmID()
    {
      return new AlgorithmIdentifier(new DERObjectIdentifier(this.digestOID), new DERNull());
    }

    SignerInfo toSignerInfo(DERObjectIdentifier paramDERObjectIdentifier, CMSProcessable paramCMSProcessable, SecureRandom paramSecureRandom, Provider paramProvider, boolean paramBoolean)
      throws IOException, SignatureException, InvalidKeyException, NoSuchAlgorithmException, CertificateEncodingException, CMSException
    {
      AlgorithmIdentifier localAlgorithmIdentifier1 = getDigestAlgorithmID();
      String str1 = CMSSignedHelper.INSTANCE.getDigestAlgName(this.digestOID);
      String str2 = str1 + "with" + CMSSignedHelper.INSTANCE.getEncryptionAlgName(this.encOID);
      Signature localSignature = CMSSignedHelper.INSTANCE.getSignatureInstance(str2, paramProvider);
      MessageDigest localMessageDigest = CMSSignedHelper.INSTANCE.getDigestInstance(str1, paramProvider);
      AlgorithmIdentifier localAlgorithmIdentifier2 = CMSSignedDataGenerator.this.getEncAlgorithmIdentifier(this.encOID, localSignature);
      if (paramCMSProcessable != null)
        paramCMSProcessable.write(new DigOutputStream(localMessageDigest));
      byte[] arrayOfByte = localMessageDigest.digest();
      CMSSignedDataGenerator.this.digests.put(this.digestOID, arrayOfByte.clone());
      AttributeTable localAttributeTable1;
      if (paramBoolean)
      {
        localObject1 = CMSSignedDataGenerator.this.getBaseParameters(paramDERObjectIdentifier, localAlgorithmIdentifier1, arrayOfByte);
        localAttributeTable1 = this.sAttr != null ? this.sAttr.getAttributes(Collections.unmodifiableMap((Map)localObject1)) : null;
      }
      else
      {
        localAttributeTable1 = this.baseSignedTable;
      }
      localSignature.initSign(this.key, paramSecureRandom);
      Object localObject1 = new BufferedOutputStream(new SigOutputStream(localSignature));
      ASN1Set localASN1Set1 = null;
      if (localAttributeTable1 != null)
      {
        if ((paramDERObjectIdentifier == null) && (localAttributeTable1.get(CMSAttributes.contentType) != null))
        {
          localObject2 = localAttributeTable1.toHashtable();
          ((Hashtable)localObject2).remove(CMSAttributes.contentType);
          localAttributeTable1 = new AttributeTable((Hashtable)localObject2);
        }
        localASN1Set1 = CMSSignedDataGenerator.this.getAttributeSet(localAttributeTable1);
        new DEROutputStream((OutputStream)localObject1).writeObject(localASN1Set1);
      }
      else if (paramCMSProcessable != null)
      {
        paramCMSProcessable.write((OutputStream)localObject1);
      }
      ((OutputStream)localObject1).close();
      Object localObject2 = localSignature.sign();
      ASN1Set localASN1Set2 = null;
      if (this.unsAttr != null)
      {
        Map localMap = CMSSignedDataGenerator.this.getBaseParameters(paramDERObjectIdentifier, localAlgorithmIdentifier1, arrayOfByte);
        localMap.put("encryptedDigest", ((byte[])localObject2).clone());
        AttributeTable localAttributeTable2 = this.unsAttr.getAttributes(Collections.unmodifiableMap(localMap));
        localASN1Set2 = CMSSignedDataGenerator.this.getAttributeSet(localAttributeTable2);
      }
      return (SignerInfo)(SignerInfo)new SignerInfo(this.signerIdentifier, localAlgorithmIdentifier1, localASN1Set1, localAlgorithmIdentifier2, new DEROctetString(localObject2), localASN1Set2);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSSignedDataGenerator
 * JD-Core Version:    0.6.0
 */