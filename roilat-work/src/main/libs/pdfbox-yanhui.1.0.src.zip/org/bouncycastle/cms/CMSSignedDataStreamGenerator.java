package org.bouncycastle.cms;

import B;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.BERSequenceGenerator;
import org.bouncycastle.asn1.BERTaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.SignerIdentifier;
import org.bouncycastle.asn1.cms.SignerInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.DigestInfo;

public class CMSSignedDataStreamGenerator extends CMSSignedGenerator
{
  private List _signerInfs = new ArrayList();
  private List _messageDigests = new ArrayList();
  private int _bufferSize;

  public CMSSignedDataStreamGenerator()
  {
  }

  public CMSSignedDataStreamGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }

  public void setBufferSize(int paramInt)
  {
    this._bufferSize = paramInt;
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, CMSUtils.getProvider(paramString3));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramAttributeTable1, paramAttributeTable2, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, paramAttributeTable1, paramAttributeTable2, CMSUtils.getProvider(paramString3));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, getEncOID(paramPrivateKey, paramString), paramString, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, CMSUtils.getProvider(paramString3));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramX509Certificate), paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramProvider, paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, paramString2, CMSUtils.getProvider(paramString3));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, paramString2, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, paramAttributeTable1, paramAttributeTable2, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, CMSUtils.getProvider(paramString2));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, getEncOID(paramPrivateKey, paramString), paramString, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, CMSUtils.getProvider(paramString3));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramArrayOfByte), paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramProvider, paramProvider);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider1, Provider paramProvider2)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramX509Certificate), paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramProvider1, paramProvider2);
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider1, Provider paramProvider2)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    doAddSigner(paramPrivateKey, getSignerIdentifier(paramArrayOfByte), paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramProvider1, paramProvider2);
  }

  private void doAddSigner(PrivateKey paramPrivateKey, SignerIdentifier paramSignerIdentifier, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider1, Provider paramProvider2)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    String str = CMSSignedHelper.INSTANCE.getDigestAlgName(paramString2);
    MessageDigest localMessageDigest = CMSSignedHelper.INSTANCE.getDigestInstance(str, paramProvider2);
    SignerIntInfoGeneratorImpl localSignerIntInfoGeneratorImpl = new SignerIntInfoGeneratorImpl(paramPrivateKey, paramSignerIdentifier, paramString2, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramProvider1, this.rand);
    this._signerInfs.add(new DigestAndSignerInfoGeneratorHolder(localSignerIntInfoGeneratorImpl, localMessageDigest, paramString2));
    this._messageDigests.add(localMessageDigest);
  }

  public OutputStream open(OutputStream paramOutputStream)
    throws IOException
  {
    return open(paramOutputStream, false);
  }

  public OutputStream open(OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException
  {
    return open(CMSObjectIdentifiers.data, paramOutputStream, paramBoolean);
  }

  public OutputStream open(OutputStream paramOutputStream1, boolean paramBoolean, OutputStream paramOutputStream2)
    throws IOException
  {
    return open(CMSObjectIdentifiers.data, paramOutputStream1, paramBoolean, paramOutputStream2);
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream, String paramString, boolean paramBoolean)
    throws IOException
  {
    return open(paramOutputStream, paramString, paramBoolean, null);
  }

  public OutputStream open(ASN1ObjectIdentifier paramASN1ObjectIdentifier, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException
  {
    return open(paramASN1ObjectIdentifier, paramOutputStream, paramBoolean, null);
  }

  /** @deprecated */
  public OutputStream open(OutputStream paramOutputStream1, String paramString, boolean paramBoolean, OutputStream paramOutputStream2)
    throws IOException
  {
    return open(new ASN1ObjectIdentifier(paramString), paramOutputStream1, paramBoolean, paramOutputStream2);
  }

  public OutputStream open(ASN1ObjectIdentifier paramASN1ObjectIdentifier, OutputStream paramOutputStream1, boolean paramBoolean, OutputStream paramOutputStream2)
    throws IOException
  {
    BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream1);
    localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.signedData);
    BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
    localBERSequenceGenerator2.addObject(calculateVersion(paramASN1ObjectIdentifier));
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Object localObject1 = this._signers.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (SignerInformation)((Iterator)localObject1).next();
      localASN1EncodableVector.add(CMSSignedHelper.INSTANCE.fixAlgID(((SignerInformation)localObject2).getDigestAlgorithmID()));
    }
    localObject1 = this._signerInfs.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (DigestAndSignerInfoGeneratorHolder)((Iterator)localObject1).next();
      localASN1EncodableVector.add(((DigestAndSignerInfoGeneratorHolder)localObject2).getDigestAlgorithm());
    }
    localObject1 = this.signerGens.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (SignerInfoGenerator)((Iterator)localObject1).next();
      localASN1EncodableVector.add(((SignerInfoGenerator)localObject2).getDigestAlgorithm());
    }
    localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(localASN1EncodableVector).getEncoded());
    localObject1 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
    ((BERSequenceGenerator)localObject1).addObject(paramASN1ObjectIdentifier);
    Object localObject2 = paramBoolean ? CMSUtils.createBEROctetOutputStream(((BERSequenceGenerator)localObject1).getRawOutputStream(), 0, true, this._bufferSize) : null;
    OutputStream localOutputStream1 = CMSUtils.getSafeTeeOutputStream(paramOutputStream2, (OutputStream)localObject2);
    OutputStream localOutputStream2 = CMSUtils.attachDigestsToOutputStream(this._messageDigests, localOutputStream1);
    OutputStream localOutputStream3 = CMSUtils.attachSignersToOutputStream(this.signerGens, localOutputStream2);
    return (OutputStream)(OutputStream)new CmsSignedDataOutputStream(localOutputStream3, paramASN1ObjectIdentifier, localBERSequenceGenerator1, localBERSequenceGenerator2, (BERSequenceGenerator)localObject1);
  }

  void generate(OutputStream paramOutputStream1, String paramString, boolean paramBoolean, OutputStream paramOutputStream2, CMSProcessable paramCMSProcessable)
    throws CMSException, IOException
  {
    OutputStream localOutputStream = open(paramOutputStream1, paramString, paramBoolean, paramOutputStream2);
    if (paramCMSProcessable != null)
      paramCMSProcessable.write(localOutputStream);
    localOutputStream.close();
  }

  private DERInteger calculateVersion(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    int i = 0;
    int j = 0;
    int k = 0;
    int m = 0;
    Iterator localIterator;
    Object localObject;
    if (this.certs != null)
    {
      localIterator = this.certs.iterator();
      while (localIterator.hasNext())
      {
        localObject = localIterator.next();
        if ((localObject instanceof ASN1TaggedObject))
        {
          ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)localObject;
          if (localASN1TaggedObject.getTagNo() == 1)
            k = 1;
          else if (localASN1TaggedObject.getTagNo() == 2)
            m = 1;
          else if (localASN1TaggedObject.getTagNo() == 3)
            i = 1;
        }
      }
    }
    if (i != 0)
      return new DERInteger(5);
    if (this.crls != null)
    {
      localIterator = this.crls.iterator();
      while (localIterator.hasNext())
      {
        localObject = localIterator.next();
        if ((localObject instanceof ASN1TaggedObject))
          j = 1;
      }
    }
    if (j != 0)
      return new DERInteger(5);
    if (m != 0)
      return new DERInteger(4);
    if (k != 0)
      return new DERInteger(3);
    if (checkForVersion3(this._signers))
      return new DERInteger(3);
    if (!CMSObjectIdentifiers.data.equals(paramASN1ObjectIdentifier))
      return new DERInteger(3);
    return new DERInteger(1);
  }

  private boolean checkForVersion3(List paramList)
  {
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      SignerInfo localSignerInfo = SignerInfo.getInstance(((SignerInformation)localIterator.next()).toSignerInfo());
      if (localSignerInfo.getVersion().getValue().intValue() == 3)
        return true;
    }
    return false;
  }

  private class CmsSignedDataOutputStream extends OutputStream
  {
    private OutputStream _out;
    private ASN1ObjectIdentifier _contentOID;
    private BERSequenceGenerator _sGen;
    private BERSequenceGenerator _sigGen;
    private BERSequenceGenerator _eiGen;

    public CmsSignedDataOutputStream(OutputStream paramASN1ObjectIdentifier, ASN1ObjectIdentifier paramBERSequenceGenerator1, BERSequenceGenerator paramBERSequenceGenerator2, BERSequenceGenerator paramBERSequenceGenerator3, BERSequenceGenerator arg6)
    {
      this._out = paramASN1ObjectIdentifier;
      this._contentOID = paramBERSequenceGenerator1;
      this._sGen = paramBERSequenceGenerator2;
      this._sigGen = paramBERSequenceGenerator3;
      Object localObject;
      this._eiGen = localObject;
    }

    public void write(int paramInt)
      throws IOException
    {
      this._out.write(paramInt);
    }

    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this._out.write(paramArrayOfByte, paramInt1, paramInt2);
    }

    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this._out.write(paramArrayOfByte);
    }

    public void close()
      throws IOException
    {
      this._out.close();
      this._eiGen.close();
      CMSSignedDataStreamGenerator.this.digests.clear();
      if (CMSSignedDataStreamGenerator.this.certs.size() != 0)
      {
        localObject1 = CMSUtils.createBerSetFromList(CMSSignedDataStreamGenerator.this.certs);
        this._sigGen.getRawOutputStream().write(new BERTaggedObject(false, 0, (DEREncodable)localObject1).getEncoded());
      }
      if (CMSSignedDataStreamGenerator.this.crls.size() != 0)
      {
        localObject1 = CMSUtils.createBerSetFromList(CMSSignedDataStreamGenerator.this.crls);
        this._sigGen.getRawOutputStream().write(new BERTaggedObject(false, 1, (DEREncodable)localObject1).getEncoded());
      }
      Object localObject1 = new ASN1EncodableVector();
      Iterator localIterator = CMSSignedDataStreamGenerator.this._signerInfs.iterator();
      Object localObject2;
      byte[] arrayOfByte;
      while (localIterator.hasNext())
      {
        localObject2 = (CMSSignedDataStreamGenerator.DigestAndSignerInfoGeneratorHolder)localIterator.next();
        arrayOfByte = ((CMSSignedDataStreamGenerator.DigestAndSignerInfoGeneratorHolder)localObject2).digest.digest();
        CMSSignedDataStreamGenerator.this.digests.put(((CMSSignedDataStreamGenerator.DigestAndSignerInfoGeneratorHolder)localObject2).digestOID, arrayOfByte.clone());
        AlgorithmIdentifier localAlgorithmIdentifier = ((CMSSignedDataStreamGenerator.DigestAndSignerInfoGeneratorHolder)localObject2).getDigestAlgorithm();
        ((ASN1EncodableVector)localObject1).add(((CMSSignedDataStreamGenerator.DigestAndSignerInfoGeneratorHolder)localObject2).signerInf.generate(this._contentOID, localAlgorithmIdentifier, arrayOfByte));
      }
      localIterator = CMSSignedDataStreamGenerator.this.signerGens.iterator();
      while (localIterator.hasNext())
      {
        localObject2 = (SignerInfoGenerator)localIterator.next();
        try
        {
          ((ASN1EncodableVector)localObject1).add(((SignerInfoGenerator)localObject2).generate(this._contentOID));
          arrayOfByte = ((SignerInfoGenerator)localObject2).getCalculatedDigest();
          CMSSignedDataStreamGenerator.this.digests.put(((SignerInfoGenerator)localObject2).getDigestAlgorithm().getAlgorithm().getId(), arrayOfByte);
        }
        catch (CMSException localCMSException)
        {
          throw new CMSStreamException("exception generating signers: " + localCMSException.getMessage(), localCMSException);
        }
      }
      localIterator = CMSSignedDataStreamGenerator.this._signers.iterator();
      while (localIterator.hasNext())
      {
        localObject2 = (SignerInformation)localIterator.next();
        ((ASN1EncodableVector)localObject1).add(((SignerInformation)localObject2).toSignerInfo());
      }
      this._sigGen.getRawOutputStream().write(new DERSet((ASN1EncodableVector)localObject1).getEncoded());
      this._sigGen.close();
      this._sGen.close();
    }
  }

  private class DigestAndSignerInfoGeneratorHolder
  {
    SignerIntInfoGenerator signerInf;
    MessageDigest digest;
    String digestOID;

    DigestAndSignerInfoGeneratorHolder(SignerIntInfoGenerator paramMessageDigest, MessageDigest paramString, String arg4)
    {
      this.signerInf = paramMessageDigest;
      this.digest = paramString;
      Object localObject;
      this.digestOID = localObject;
    }

    AlgorithmIdentifier getDigestAlgorithm()
    {
      return new AlgorithmIdentifier(new DERObjectIdentifier(this.digestOID), DERNull.INSTANCE);
    }
  }

  private class SignerIntInfoGeneratorImpl
    implements SignerIntInfoGenerator
  {
    private final SignerIdentifier _signerIdentifier;
    private final String _encOID;
    private final CMSAttributeTableGenerator _sAttr;
    private final CMSAttributeTableGenerator _unsAttr;
    private final String _encName;
    private final Signature _sig;

    SignerIntInfoGeneratorImpl(PrivateKey paramSignerIdentifier, SignerIdentifier paramString1, String paramString2, String paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, CMSAttributeTableGenerator paramProvider, Provider paramSecureRandom, SecureRandom arg9)
      throws NoSuchAlgorithmException, InvalidKeyException
    {
      this._signerIdentifier = paramString1;
      this._encOID = paramCMSAttributeTableGenerator1;
      this._sAttr = paramCMSAttributeTableGenerator2;
      this._unsAttr = paramProvider;
      this._encName = CMSSignedHelper.INSTANCE.getEncryptionAlgName(this._encOID);
      String str1 = CMSSignedHelper.INSTANCE.getDigestAlgName(paramString2);
      String str2 = str1 + "with" + this._encName;
      if (this._sAttr != null)
        this._sig = CMSSignedHelper.INSTANCE.getSignatureInstance(str2, paramSecureRandom);
      else if (this._encName.equals("RSA"))
        this._sig = CMSSignedHelper.INSTANCE.getSignatureInstance("RSA", paramSecureRandom);
      else if (this._encName.equals("DSA"))
        this._sig = CMSSignedHelper.INSTANCE.getSignatureInstance("NONEwithDSA", paramSecureRandom);
      else
        throw new NoSuchAlgorithmException("algorithm: " + this._encName + " not supported in base signatures.");
      SecureRandom localSecureRandom;
      this._sig.initSign(paramSignerIdentifier, localSecureRandom);
    }

    public SignerInfo generate(DERObjectIdentifier paramDERObjectIdentifier, AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
      throws CMSStreamException
    {
      try
      {
        byte[] arrayOfByte = paramArrayOfByte;
        ASN1Set localASN1Set = null;
        if (this._sAttr != null)
        {
          localObject1 = CMSSignedDataStreamGenerator.this.getBaseParameters(paramDERObjectIdentifier, paramAlgorithmIdentifier, paramArrayOfByte);
          localObject2 = this._sAttr.getAttributes(Collections.unmodifiableMap((Map)localObject1));
          if ((paramDERObjectIdentifier == null) && (localObject2 != null) && (((AttributeTable)localObject2).get(CMSAttributes.contentType) != null))
          {
            localObject3 = ((AttributeTable)localObject2).toHashtable();
            ((Hashtable)localObject3).remove(CMSAttributes.contentType);
            localObject2 = new AttributeTable((Hashtable)localObject3);
          }
          localASN1Set = CMSSignedDataStreamGenerator.this.getAttributeSet((AttributeTable)localObject2);
          arrayOfByte = localASN1Set.getEncoded("DER");
        }
        else if (this._encName.equals("RSA"))
        {
          localObject1 = new DigestInfo(paramAlgorithmIdentifier, paramArrayOfByte);
          arrayOfByte = ((DigestInfo)localObject1).getEncoded("DER");
        }
        this._sig.update(arrayOfByte);
        Object localObject1 = this._sig.sign();
        Object localObject2 = null;
        if (this._unsAttr != null)
        {
          localObject3 = CMSSignedDataStreamGenerator.this.getBaseParameters(paramDERObjectIdentifier, paramAlgorithmIdentifier, paramArrayOfByte);
          ((Map)localObject3).put("encryptedDigest", ((byte[])localObject1).clone());
          AttributeTable localAttributeTable = this._unsAttr.getAttributes(Collections.unmodifiableMap((Map)localObject3));
          localObject2 = CMSSignedDataStreamGenerator.this.getAttributeSet(localAttributeTable);
        }
        Object localObject3 = CMSSignedDataStreamGenerator.this.getEncAlgorithmIdentifier(this._encOID, this._sig);
        return new SignerInfo(this._signerIdentifier, paramAlgorithmIdentifier, localASN1Set, (AlgorithmIdentifier)localObject3, new DEROctetString(localObject1), (ASN1Set)localObject2);
      }
      catch (IOException localIOException)
      {
        throw new CMSStreamException("encoding error.", localIOException);
      }
      catch (SignatureException localSignatureException)
      {
      }
      throw new CMSStreamException("error creating signature.", localSignatureException);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSSignedDataStreamGenerator
 * JD-Core Version:    0.6.0
 */