package org.bouncycastle.cms;

public class CMSSignerDigestMismatchException extends CMSException
{
  public CMSSignerDigestMismatchException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSSignerDigestMismatchException
 * JD-Core Version:    0.6.0
 */