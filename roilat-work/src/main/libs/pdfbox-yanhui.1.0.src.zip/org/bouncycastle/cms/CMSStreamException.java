package org.bouncycastle.cms;

import java.io.IOException;

public class CMSStreamException extends IOException
{
  private final Throwable underlying;

  CMSStreamException(String paramString)
  {
    super(paramString);
    this.underlying = null;
  }

  CMSStreamException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    this.underlying = paramThrowable;
  }

  public Throwable getCause()
  {
    return this.underlying;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSStreamException
 * JD-Core Version:    0.6.0
 */