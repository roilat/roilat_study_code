package org.bouncycastle.cms;

import org.bouncycastle.asn1.ASN1ObjectIdentifier;

public abstract interface CMSTypedData extends CMSProcessable
{
  public abstract ASN1ObjectIdentifier getContentType();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSTypedData
 * JD-Core Version:    0.6.0
 */