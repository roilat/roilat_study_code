package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CRLException;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BEROctetStringGenerator;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.x509.CertificateList;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.cert.X509AttributeCertificateHolder;
import org.bouncycastle.cert.X509CRLHolder;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.util.Store;
import org.bouncycastle.util.io.Streams;
import org.bouncycastle.util.io.TeeInputStream;
import org.bouncycastle.util.io.TeeOutputStream;

class CMSUtils
{
  private static final Runtime RUNTIME = Runtime.getRuntime();

  static int getMaximumMemory()
  {
    long l = RUNTIME.maxMemory();
    if (l > 2147483647L)
      return 2147483647;
    return (int)l;
  }

  static ContentInfo readContentInfo(byte[] paramArrayOfByte)
    throws CMSException
  {
    return readContentInfo(new ASN1InputStream(paramArrayOfByte));
  }

  static ContentInfo readContentInfo(InputStream paramInputStream)
    throws CMSException
  {
    return readContentInfo(new ASN1InputStream(paramInputStream, getMaximumMemory()));
  }

  static List getCertificatesFromStore(CertStore paramCertStore)
    throws CertStoreException, CMSException
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      Iterator localIterator = paramCertStore.getCertificates(null).iterator();
      while (localIterator.hasNext())
      {
        X509Certificate localX509Certificate = (X509Certificate)localIterator.next();
        localArrayList.add(X509CertificateStructure.getInstance(ASN1Object.fromByteArray(localX509Certificate.getEncoded())));
      }
      return localArrayList;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new CMSException("error processing certs", localIllegalArgumentException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("error processing certs", localIOException);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
    }
    throw new CMSException("error encoding certs", localCertificateEncodingException);
  }

  static List getCertificatesFromStore(Store paramStore)
    throws CMSException
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      Iterator localIterator = paramStore.getMatches(null).iterator();
      while (localIterator.hasNext())
      {
        X509CertificateHolder localX509CertificateHolder = (X509CertificateHolder)localIterator.next();
        localArrayList.add(localX509CertificateHolder.toASN1Structure());
      }
      return localArrayList;
    }
    catch (ClassCastException localClassCastException)
    {
    }
    throw new CMSException("error processing certs", localClassCastException);
  }

  static List getAttributeCertificatesFromStore(Store paramStore)
    throws CMSException
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      Iterator localIterator = paramStore.getMatches(null).iterator();
      while (localIterator.hasNext())
      {
        X509AttributeCertificateHolder localX509AttributeCertificateHolder = (X509AttributeCertificateHolder)localIterator.next();
        localArrayList.add(new DERTaggedObject(false, 2, localX509AttributeCertificateHolder.toASN1Structure()));
      }
      return localArrayList;
    }
    catch (ClassCastException localClassCastException)
    {
    }
    throw new CMSException("error processing certs", localClassCastException);
  }

  static List getCRLsFromStore(CertStore paramCertStore)
    throws CertStoreException, CMSException
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      Iterator localIterator = paramCertStore.getCRLs(null).iterator();
      while (localIterator.hasNext())
      {
        X509CRL localX509CRL = (X509CRL)localIterator.next();
        localArrayList.add(CertificateList.getInstance(ASN1Object.fromByteArray(localX509CRL.getEncoded())));
      }
      return localArrayList;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new CMSException("error processing crls", localIllegalArgumentException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("error processing crls", localIOException);
    }
    catch (CRLException localCRLException)
    {
    }
    throw new CMSException("error encoding crls", localCRLException);
  }

  static List getCRLsFromStore(Store paramStore)
    throws CMSException
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      Iterator localIterator = paramStore.getMatches(null).iterator();
      while (localIterator.hasNext())
      {
        X509CRLHolder localX509CRLHolder = (X509CRLHolder)localIterator.next();
        localArrayList.add(localX509CRLHolder.toASN1Structure());
      }
      return localArrayList;
    }
    catch (ClassCastException localClassCastException)
    {
    }
    throw new CMSException("error processing certs", localClassCastException);
  }

  static ASN1Set createBerSetFromList(List paramList)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
      localASN1EncodableVector.add((DEREncodable)localIterator.next());
    return new BERSet(localASN1EncodableVector);
  }

  static ASN1Set createDerSetFromList(List paramList)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
      localASN1EncodableVector.add((DEREncodable)localIterator.next());
    return new DERSet(localASN1EncodableVector);
  }

  static OutputStream createBEROctetOutputStream(OutputStream paramOutputStream, int paramInt1, boolean paramBoolean, int paramInt2)
    throws IOException
  {
    BEROctetStringGenerator localBEROctetStringGenerator = new BEROctetStringGenerator(paramOutputStream, paramInt1, paramBoolean);
    if (paramInt2 != 0)
      return localBEROctetStringGenerator.getOctetOutputStream(new byte[paramInt2]);
    return localBEROctetStringGenerator.getOctetOutputStream();
  }

  static TBSCertificateStructure getTBSCertificateStructure(X509Certificate paramX509Certificate)
  {
    try
    {
      return TBSCertificateStructure.getInstance(ASN1Object.fromByteArray(paramX509Certificate.getTBSCertificate()));
    }
    catch (Exception localException)
    {
    }
    throw new IllegalArgumentException("can't extract TBS structure from this cert");
  }

  static IssuerAndSerialNumber getIssuerAndSerialNumber(X509Certificate paramX509Certificate)
  {
    TBSCertificateStructure localTBSCertificateStructure = getTBSCertificateStructure(paramX509Certificate);
    return new IssuerAndSerialNumber(localTBSCertificateStructure.getIssuer(), localTBSCertificateStructure.getSerialNumber().getValue());
  }

  private static ContentInfo readContentInfo(ASN1InputStream paramASN1InputStream)
    throws CMSException
  {
    try
    {
      return ContentInfo.getInstance(paramASN1InputStream.readObject());
    }
    catch (IOException localIOException)
    {
      throw new CMSException("IOException reading content.", localIOException);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CMSException("Malformed content.", localClassCastException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    throw new CMSException("Malformed content.", localIllegalArgumentException);
  }

  public static byte[] streamToByteArray(InputStream paramInputStream)
    throws IOException
  {
    return Streams.readAll(paramInputStream);
  }

  public static byte[] streamToByteArray(InputStream paramInputStream, int paramInt)
    throws IOException
  {
    return Streams.readAllLimited(paramInputStream, paramInt);
  }

  public static Provider getProvider(String paramString)
    throws NoSuchProviderException
  {
    if (paramString != null)
    {
      Provider localProvider = Security.getProvider(paramString);
      if (localProvider != null)
        return localProvider;
      throw new NoSuchProviderException("provider " + paramString + " not found.");
    }
    return null;
  }

  static InputStream attachDigestsToInputStream(Collection paramCollection, InputStream paramInputStream)
  {
    Object localObject = paramInputStream;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      MessageDigest localMessageDigest = (MessageDigest)localIterator.next();
      localObject = new TeeInputStream((InputStream)localObject, new DigOutputStream(localMessageDigest));
    }
    return (InputStream)localObject;
  }

  static OutputStream attachDigestsToOutputStream(Collection paramCollection, OutputStream paramOutputStream)
  {
    OutputStream localOutputStream = paramOutputStream;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      MessageDigest localMessageDigest = (MessageDigest)localIterator.next();
      localOutputStream = getSafeTeeOutputStream(localOutputStream, new DigOutputStream(localMessageDigest));
    }
    return localOutputStream;
  }

  static OutputStream attachSignersToOutputStream(Collection paramCollection, OutputStream paramOutputStream)
  {
    OutputStream localOutputStream = paramOutputStream;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      SignerInfoGenerator localSignerInfoGenerator = (SignerInfoGenerator)localIterator.next();
      localOutputStream = getSafeTeeOutputStream(localOutputStream, localSignerInfoGenerator.getCalculatingOutputStream());
    }
    return localOutputStream;
  }

  static OutputStream getSafeOutputStream(OutputStream paramOutputStream)
  {
    return paramOutputStream == null ? new NullOutputStream() : paramOutputStream;
  }

  static OutputStream getSafeTeeOutputStream(OutputStream paramOutputStream1, OutputStream paramOutputStream2)
  {
    return paramOutputStream2 == null ? getSafeOutputStream(paramOutputStream1) : paramOutputStream1 == null ? getSafeOutputStream(paramOutputStream2) : new TeeOutputStream(paramOutputStream1, paramOutputStream2);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSUtils
 * JD-Core Version:    0.6.0
 */