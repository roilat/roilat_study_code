package org.bouncycastle.cms;

public class CMSVerifierCertificateNotValidException extends CMSException
{
  public CMSVerifierCertificateNotValidException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CMSVerifierCertificateNotValidException
 * JD-Core Version:    0.6.0
 */