package org.bouncycastle.cms;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;

class CounterSignatureDigestCalculator
  implements IntDigestCalculator
{
  private final String alg;
  private final Provider provider;
  private final byte[] data;

  CounterSignatureDigestCalculator(String paramString, Provider paramProvider, byte[] paramArrayOfByte)
  {
    this.alg = paramString;
    this.provider = paramProvider;
    this.data = paramArrayOfByte;
  }

  public byte[] getDigest()
    throws NoSuchAlgorithmException
  {
    MessageDigest localMessageDigest = CMSSignedHelper.INSTANCE.getDigestInstance(this.alg, this.provider);
    return localMessageDigest.digest(this.data);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.CounterSignatureDigestCalculator
 * JD-Core Version:    0.6.0
 */