package org.bouncycastle.cms;

import java.util.Date;
import java.util.Hashtable;
import java.util.Map;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.Time;

public class DefaultSignedAttributeTableGenerator
  implements CMSAttributeTableGenerator
{
  private final Hashtable table;

  public DefaultSignedAttributeTableGenerator()
  {
    this.table = new Hashtable();
  }

  public DefaultSignedAttributeTableGenerator(AttributeTable paramAttributeTable)
  {
    if (paramAttributeTable != null)
      this.table = paramAttributeTable.toHashtable();
    else
      this.table = new Hashtable();
  }

  protected Hashtable createStandardAttributeTable(Map paramMap)
  {
    Hashtable localHashtable = (Hashtable)this.table.clone();
    Object localObject;
    Attribute localAttribute;
    if (!localHashtable.containsKey(CMSAttributes.contentType))
    {
      localObject = (DERObjectIdentifier)paramMap.get("contentType");
      if (localObject != null)
      {
        localAttribute = new Attribute(CMSAttributes.contentType, new DERSet((DEREncodable)localObject));
        localHashtable.put(localAttribute.getAttrType(), localAttribute);
      }
    }
    if (!localHashtable.containsKey(CMSAttributes.signingTime))
    {
      localObject = new Date();
      localAttribute = new Attribute(CMSAttributes.signingTime, new DERSet(new Time((Date)localObject)));
      localHashtable.put(localAttribute.getAttrType(), localAttribute);
    }
    if (!localHashtable.containsKey(CMSAttributes.messageDigest))
    {
      localObject = (byte[])(byte[])paramMap.get("digest");
      localAttribute = new Attribute(CMSAttributes.messageDigest, new DERSet(new DEROctetString(localObject)));
      localHashtable.put(localAttribute.getAttrType(), localAttribute);
    }
    return (Hashtable)localHashtable;
  }

  public AttributeTable getAttributes(Map paramMap)
  {
    return new AttributeTable(createStandardAttributeTable(paramMap));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.DefaultSignedAttributeTableGenerator
 * JD-Core Version:    0.6.0
 */