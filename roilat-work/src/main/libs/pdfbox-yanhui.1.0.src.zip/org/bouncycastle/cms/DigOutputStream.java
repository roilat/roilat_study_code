package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;

class DigOutputStream extends OutputStream
{
  private final MessageDigest dig;

  DigOutputStream(MessageDigest paramMessageDigest)
  {
    this.dig = paramMessageDigest;
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.dig.update(paramArrayOfByte, paramInt1, paramInt2);
  }

  public void write(int paramInt)
    throws IOException
  {
    this.dig.update((byte)paramInt);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.DigOutputStream
 * JD-Core Version:    0.6.0
 */