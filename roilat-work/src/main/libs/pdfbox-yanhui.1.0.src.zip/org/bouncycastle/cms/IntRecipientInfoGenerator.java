package org.bouncycastle.cms;

import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.SecureRandom;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.cms.RecipientInfo;

abstract interface IntRecipientInfoGenerator
{
  public abstract RecipientInfo generate(SecretKey paramSecretKey, SecureRandom paramSecureRandom, Provider paramProvider)
    throws GeneralSecurityException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.IntRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */