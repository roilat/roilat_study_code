package org.bouncycastle.cms;

import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.KEKIdentifier;
import org.bouncycastle.asn1.cms.KEKRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.kisa.KISAObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.ntt.NTTObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

class KEKIntRecipientInfoGenerator
  implements IntRecipientInfoGenerator
{
  private SecretKey keyEncryptionKey;
  private KEKIdentifier kekIdentifier;
  private AlgorithmIdentifier keyEncryptionAlgorithm;

  void setKeyEncryptionKey(SecretKey paramSecretKey)
  {
    this.keyEncryptionKey = paramSecretKey;
    this.keyEncryptionAlgorithm = determineKeyEncAlg(paramSecretKey);
  }

  void setKEKIdentifier(KEKIdentifier paramKEKIdentifier)
  {
    this.kekIdentifier = paramKEKIdentifier;
  }

  public RecipientInfo generate(SecretKey paramSecretKey, SecureRandom paramSecureRandom, Provider paramProvider)
    throws GeneralSecurityException
  {
    Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createSymmetricCipher(this.keyEncryptionAlgorithm.getObjectId().getId(), paramProvider);
    localCipher.init(3, this.keyEncryptionKey, paramSecureRandom);
    byte[] arrayOfByte = localCipher.wrap(paramSecretKey);
    DEROctetString localDEROctetString = new DEROctetString(arrayOfByte);
    return new RecipientInfo(new KEKRecipientInfo(this.kekIdentifier, this.keyEncryptionAlgorithm, localDEROctetString));
  }

  private static AlgorithmIdentifier determineKeyEncAlg(SecretKey paramSecretKey)
  {
    String str = paramSecretKey.getAlgorithm();
    if (str.startsWith("DES"))
      return new AlgorithmIdentifier(new DERObjectIdentifier("1.2.840.113549.1.9.16.3.6"), new DERNull());
    if (str.startsWith("RC2"))
      return new AlgorithmIdentifier(new DERObjectIdentifier("1.2.840.113549.1.9.16.3.7"), new DERInteger(58));
    int i;
    ASN1ObjectIdentifier localASN1ObjectIdentifier;
    if (str.startsWith("AES"))
    {
      i = paramSecretKey.getEncoded().length * 8;
      if (i == 128)
        localASN1ObjectIdentifier = NISTObjectIdentifiers.id_aes128_wrap;
      else if (i == 192)
        localASN1ObjectIdentifier = NISTObjectIdentifiers.id_aes192_wrap;
      else if (i == 256)
        localASN1ObjectIdentifier = NISTObjectIdentifiers.id_aes256_wrap;
      else
        throw new IllegalArgumentException("illegal keysize in AES");
      return new AlgorithmIdentifier(localASN1ObjectIdentifier);
    }
    if (str.startsWith("SEED"))
      return new AlgorithmIdentifier(KISAObjectIdentifiers.id_npki_app_cmsSeed_wrap);
    if (str.startsWith("Camellia"))
    {
      i = paramSecretKey.getEncoded().length * 8;
      if (i == 128)
        localASN1ObjectIdentifier = NTTObjectIdentifiers.id_camellia128_wrap;
      else if (i == 192)
        localASN1ObjectIdentifier = NTTObjectIdentifiers.id_camellia192_wrap;
      else if (i == 256)
        localASN1ObjectIdentifier = NTTObjectIdentifiers.id_camellia256_wrap;
      else
        throw new IllegalArgumentException("illegal keysize in Camellia");
      return new AlgorithmIdentifier(localASN1ObjectIdentifier);
    }
    throw new IllegalArgumentException("unknown algorithm");
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.KEKIntRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */