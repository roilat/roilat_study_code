package org.bouncycastle.cms;

import org.bouncycastle.util.Arrays;

public class KEKRecipientId extends RecipientId
{
  private byte[] keyIdentifier;

  public KEKRecipientId(byte[] paramArrayOfByte)
  {
    super(1);
    this.keyIdentifier = paramArrayOfByte;
  }

  public int hashCode()
  {
    return Arrays.hashCode(this.keyIdentifier);
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof KEKRecipientId))
      return false;
    KEKRecipientId localKEKRecipientId = (KEKRecipientId)paramObject;
    return Arrays.areEqual(this.keyIdentifier, localKEKRecipientId.keyIdentifier);
  }

  public boolean match(Object paramObject)
  {
    if ((paramObject instanceof byte[]))
      return Arrays.areEqual(this.keyIdentifier, (byte[])(byte[])paramObject);
    if ((paramObject instanceof KEKRecipientInformation))
      return ((KEKRecipientInformation)paramObject).getRID().equals(this);
    return false;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.KEKRecipientId
 * JD-Core Version:    0.6.0
 */