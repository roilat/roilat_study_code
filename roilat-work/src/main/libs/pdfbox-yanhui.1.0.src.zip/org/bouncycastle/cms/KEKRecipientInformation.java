package org.bouncycastle.cms;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.KEKIdentifier;
import org.bouncycastle.asn1.cms.KEKRecipientInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class KEKRecipientInformation extends RecipientInformation
{
  private KEKRecipientInfo info;

  KEKRecipientInformation(KEKRecipientInfo paramKEKRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier, CMSSecureReadable paramCMSSecureReadable, AuthAttributesProvider paramAuthAttributesProvider)
  {
    super(paramKEKRecipientInfo.getKeyEncryptionAlgorithm(), paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider);
    this.info = paramKEKRecipientInfo;
    KEKIdentifier localKEKIdentifier = paramKEKRecipientInfo.getKekid();
    this.rid = new KEKRecipientId(localKEKIdentifier.getKeyIdentifier().getOctets());
  }

  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }

  public CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createSymmetricCipher(this.keyEncAlg.getObjectId().getId(), paramProvider);
      localCipher.init(4, paramKey);
      Key localKey = localCipher.unwrap(this.info.getEncryptedKey().getOctets(), getContentAlgorithmName(), 3);
      return getContentFromSessionKey(localKey, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
    }
    throw new CMSException("required padding not supported.", localNoSuchPaddingException);
  }

  protected RecipientOperator getRecipientOperator(Recipient paramRecipient)
    throws CMSException, IOException
  {
    return ((KEKRecipient)paramRecipient).getRecipientOperator(this.keyEncAlg, this.messageAlgorithm, this.info.getEncryptedKey().getOctets());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.KEKRecipientInformation
 * JD-Core Version:    0.6.0
 */