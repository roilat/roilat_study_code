package org.bouncycastle.cms;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECParameterSpec;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientIdentifier;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientInfo;
import org.bouncycastle.asn1.cms.OriginatorIdentifierOrKey;
import org.bouncycastle.asn1.cms.OriginatorPublicKey;
import org.bouncycastle.asn1.cms.RecipientEncryptedKey;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.cms.ecc.MQVuserKeyingMaterial;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.jce.spec.MQVPrivateKeySpec;
import org.bouncycastle.jce.spec.MQVPublicKeySpec;

class KeyAgreeIntRecipientInfoGenerator
  implements IntRecipientInfoGenerator
{
  private DERObjectIdentifier keyAgreementOID;
  private DERObjectIdentifier keyEncryptionOID;
  private ArrayList recipientCerts;
  private KeyPair senderKeyPair;

  void setKeyAgreementOID(DERObjectIdentifier paramDERObjectIdentifier)
  {
    this.keyAgreementOID = paramDERObjectIdentifier;
  }

  void setKeyEncryptionOID(DERObjectIdentifier paramDERObjectIdentifier)
  {
    this.keyEncryptionOID = paramDERObjectIdentifier;
  }

  void setRecipientCerts(Collection paramCollection)
  {
    this.recipientCerts = new ArrayList(paramCollection);
  }

  void setSenderKeyPair(KeyPair paramKeyPair)
  {
    this.senderKeyPair = paramKeyPair;
  }

  public RecipientInfo generate(SecretKey paramSecretKey, SecureRandom paramSecureRandom, Provider paramProvider)
    throws GeneralSecurityException
  {
    PublicKey localPublicKey = this.senderKeyPair.getPublic();
    Object localObject1 = this.senderKeyPair.getPrivate();
    OriginatorIdentifierOrKey localOriginatorIdentifierOrKey;
    try
    {
      localOriginatorIdentifierOrKey = new OriginatorIdentifierOrKey(createOriginatorPublicKey(localPublicKey));
    }
    catch (IOException localIOException1)
    {
      throw new InvalidKeyException("cannot extract originator public key: " + localIOException1);
    }
    DEROctetString localDEROctetString1 = null;
    if (this.keyAgreementOID.getId().equals(CMSEnvelopedGenerator.ECMQV_SHA1KDF))
      try
      {
        ECParameterSpec localECParameterSpec = ((ECPublicKey)localPublicKey).getParams();
        localObject2 = KeyPairGenerator.getInstance(this.keyAgreementOID.getId(), paramProvider);
        ((KeyPairGenerator)localObject2).initialize(localECParameterSpec, paramSecureRandom);
        localObject3 = ((KeyPairGenerator)localObject2).generateKeyPair();
        localDEROctetString1 = new DEROctetString(new MQVuserKeyingMaterial(createOriginatorPublicKey(((KeyPair)localObject3).getPublic()), null));
        localObject1 = new MQVPrivateKeySpec((PrivateKey)localObject1, ((KeyPair)localObject3).getPrivate(), ((KeyPair)localObject3).getPublic());
      }
      catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
      {
        throw new InvalidKeyException("cannot determine MQV ephemeral key pair parameters from public key: " + localInvalidAlgorithmParameterException);
      }
      catch (IOException localIOException2)
      {
        throw new InvalidKeyException("cannot extract MQV ephemeral public key: " + localIOException2);
      }
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.keyEncryptionOID);
    localASN1EncodableVector.add(DERNull.INSTANCE);
    Object localObject2 = new AlgorithmIdentifier(this.keyAgreementOID, new DERSequence(localASN1EncodableVector));
    Object localObject3 = new ASN1EncodableVector();
    Iterator localIterator = this.recipientCerts.iterator();
    while (localIterator.hasNext())
    {
      X509Certificate localX509Certificate = (X509Certificate)localIterator.next();
      KeyAgreeRecipientIdentifier localKeyAgreeRecipientIdentifier = new KeyAgreeRecipientIdentifier(CMSUtils.getIssuerAndSerialNumber(localX509Certificate));
      Object localObject4 = localX509Certificate.getPublicKey();
      if (this.keyAgreementOID.getId().equals(CMSEnvelopedGenerator.ECMQV_SHA1KDF))
        localObject4 = new MQVPublicKeySpec((PublicKey)localObject4, (PublicKey)localObject4);
      KeyAgreement localKeyAgreement = KeyAgreement.getInstance(this.keyAgreementOID.getId(), paramProvider);
      localKeyAgreement.init((Key)localObject1, paramSecureRandom);
      localKeyAgreement.doPhase((Key)localObject4, true);
      SecretKey localSecretKey = localKeyAgreement.generateSecret(this.keyEncryptionOID.getId());
      Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createSymmetricCipher(this.keyEncryptionOID.getId(), paramProvider);
      localCipher.init(3, localSecretKey, paramSecureRandom);
      byte[] arrayOfByte = localCipher.wrap(paramSecretKey);
      DEROctetString localDEROctetString2 = new DEROctetString(arrayOfByte);
      ((ASN1EncodableVector)localObject3).add(new RecipientEncryptedKey(localKeyAgreeRecipientIdentifier, localDEROctetString2));
    }
    return (RecipientInfo)(RecipientInfo)(RecipientInfo)(RecipientInfo)new RecipientInfo(new KeyAgreeRecipientInfo(localOriginatorIdentifierOrKey, localDEROctetString1, (AlgorithmIdentifier)localObject2, new DERSequence((ASN1EncodableVector)localObject3)));
  }

  private static OriginatorPublicKey createOriginatorPublicKey(PublicKey paramPublicKey)
    throws IOException
  {
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = SubjectPublicKeyInfo.getInstance(ASN1Object.fromByteArray(paramPublicKey.getEncoded()));
    return new OriginatorPublicKey(new AlgorithmIdentifier(localSubjectPublicKeyInfo.getAlgorithmId().getObjectId(), DERNull.INSTANCE), localSubjectPublicKeyInfo.getPublicKeyData().getBytes());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.KeyAgreeIntRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */