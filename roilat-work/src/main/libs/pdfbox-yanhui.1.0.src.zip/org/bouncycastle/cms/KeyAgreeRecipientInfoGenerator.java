package org.bouncycastle.cms;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientInfo;
import org.bouncycastle.asn1.cms.OriginatorIdentifierOrKey;
import org.bouncycastle.asn1.cms.OriginatorPublicKey;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.operator.GenericKey;

public abstract class KeyAgreeRecipientInfoGenerator
  implements RecipientInfoGenerator
{
  private ASN1ObjectIdentifier keyAgreementOID;
  private ASN1ObjectIdentifier keyEncryptionOID;
  private SubjectPublicKeyInfo originatorKeyInfo;

  protected KeyAgreeRecipientInfoGenerator(ASN1ObjectIdentifier paramASN1ObjectIdentifier1, SubjectPublicKeyInfo paramSubjectPublicKeyInfo, ASN1ObjectIdentifier paramASN1ObjectIdentifier2)
  {
    this.originatorKeyInfo = paramSubjectPublicKeyInfo;
    this.keyAgreementOID = paramASN1ObjectIdentifier1;
    this.keyEncryptionOID = paramASN1ObjectIdentifier2;
  }

  public RecipientInfo generate(GenericKey paramGenericKey)
    throws CMSException
  {
    OriginatorIdentifierOrKey localOriginatorIdentifierOrKey = new OriginatorIdentifierOrKey(createOriginatorPublicKey(this.originatorKeyInfo));
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.keyEncryptionOID);
    localASN1EncodableVector.add(DERNull.INSTANCE);
    AlgorithmIdentifier localAlgorithmIdentifier1 = new AlgorithmIdentifier(this.keyEncryptionOID, DERNull.INSTANCE);
    AlgorithmIdentifier localAlgorithmIdentifier2 = new AlgorithmIdentifier(this.keyAgreementOID, localAlgorithmIdentifier1);
    ASN1Sequence localASN1Sequence = generateRecipientEncryptedKeys(localAlgorithmIdentifier2, localAlgorithmIdentifier1, paramGenericKey);
    ASN1Encodable localASN1Encodable = getUserKeyingMaterial(localAlgorithmIdentifier2);
    if (localASN1Encodable != null)
      return new RecipientInfo(new KeyAgreeRecipientInfo(localOriginatorIdentifierOrKey, new DEROctetString(localASN1Encodable), localAlgorithmIdentifier2, localASN1Sequence));
    return new RecipientInfo(new KeyAgreeRecipientInfo(localOriginatorIdentifierOrKey, null, localAlgorithmIdentifier2, localASN1Sequence));
  }

  protected OriginatorPublicKey createOriginatorPublicKey(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    return new OriginatorPublicKey(new AlgorithmIdentifier(paramSubjectPublicKeyInfo.getAlgorithmId().getAlgorithm(), DERNull.INSTANCE), paramSubjectPublicKeyInfo.getPublicKeyData().getBytes());
  }

  protected abstract ASN1Sequence generateRecipientEncryptedKeys(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, GenericKey paramGenericKey)
    throws CMSException;

  protected abstract ASN1Encodable getUserKeyingMaterial(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws CMSException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.KeyAgreeRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */