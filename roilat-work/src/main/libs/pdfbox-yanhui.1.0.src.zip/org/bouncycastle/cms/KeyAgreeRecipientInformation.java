package org.bouncycastle.cms;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientIdentifier;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientInfo;
import org.bouncycastle.asn1.cms.OriginatorIdentifierOrKey;
import org.bouncycastle.asn1.cms.OriginatorPublicKey;
import org.bouncycastle.asn1.cms.RecipientEncryptedKey;
import org.bouncycastle.asn1.cms.RecipientKeyIdentifier;
import org.bouncycastle.asn1.cms.ecc.MQVuserKeyingMaterial;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.jce.spec.MQVPrivateKeySpec;
import org.bouncycastle.jce.spec.MQVPublicKeySpec;

public class KeyAgreeRecipientInformation extends RecipientInformation
{
  private KeyAgreeRecipientInfo info;
  private ASN1OctetString encryptedKey;

  static void readRecipientInfo(List paramList, KeyAgreeRecipientInfo paramKeyAgreeRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier, CMSSecureReadable paramCMSSecureReadable, AuthAttributesProvider paramAuthAttributesProvider)
  {
    ASN1Sequence localASN1Sequence = paramKeyAgreeRecipientInfo.getRecipientEncryptedKeys();
    for (int i = 0; i < localASN1Sequence.size(); i++)
    {
      RecipientEncryptedKey localRecipientEncryptedKey = RecipientEncryptedKey.getInstance(localASN1Sequence.getObjectAt(i));
      KeyAgreeRecipientIdentifier localKeyAgreeRecipientIdentifier = localRecipientEncryptedKey.getIdentifier();
      IssuerAndSerialNumber localIssuerAndSerialNumber = localKeyAgreeRecipientIdentifier.getIssuerAndSerialNumber();
      KeyAgreeRecipientId localKeyAgreeRecipientId;
      if (localIssuerAndSerialNumber != null)
      {
        localKeyAgreeRecipientId = new KeyAgreeRecipientId(localIssuerAndSerialNumber.getName(), localIssuerAndSerialNumber.getSerialNumber().getValue());
      }
      else
      {
        RecipientKeyIdentifier localRecipientKeyIdentifier = localKeyAgreeRecipientIdentifier.getRKeyID();
        localKeyAgreeRecipientId = new KeyAgreeRecipientId(localRecipientKeyIdentifier.getSubjectKeyIdentifier().getOctets());
      }
      paramList.add(new KeyAgreeRecipientInformation(paramKeyAgreeRecipientInfo, localKeyAgreeRecipientId, localRecipientEncryptedKey.getEncryptedKey(), paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider));
    }
  }

  KeyAgreeRecipientInformation(KeyAgreeRecipientInfo paramKeyAgreeRecipientInfo, RecipientId paramRecipientId, ASN1OctetString paramASN1OctetString, AlgorithmIdentifier paramAlgorithmIdentifier, CMSSecureReadable paramCMSSecureReadable, AuthAttributesProvider paramAuthAttributesProvider)
  {
    super(paramKeyAgreeRecipientInfo.getKeyEncryptionAlgorithm(), paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider);
    this.info = paramKeyAgreeRecipientInfo;
    this.rid = paramRecipientId;
    this.encryptedKey = paramASN1OctetString;
  }

  private SubjectPublicKeyInfo getSenderPublicKeyInfo(AlgorithmIdentifier paramAlgorithmIdentifier, OriginatorIdentifierOrKey paramOriginatorIdentifierOrKey)
    throws CMSException, IOException
  {
    OriginatorPublicKey localOriginatorPublicKey = paramOriginatorIdentifierOrKey.getOriginatorKey();
    if (localOriginatorPublicKey != null)
      return getPublicKeyInfoFromOriginatorPublicKey(paramAlgorithmIdentifier, localOriginatorPublicKey);
    OriginatorId localOriginatorId = new OriginatorId();
    IssuerAndSerialNumber localIssuerAndSerialNumber = paramOriginatorIdentifierOrKey.getIssuerAndSerialNumber();
    if (localIssuerAndSerialNumber != null)
    {
      localOriginatorId.setIssuer(localIssuerAndSerialNumber.getName().getEncoded());
      localOriginatorId.setSerialNumber(localIssuerAndSerialNumber.getSerialNumber().getValue());
    }
    else
    {
      SubjectKeyIdentifier localSubjectKeyIdentifier = paramOriginatorIdentifierOrKey.getSubjectKeyIdentifier();
      localOriginatorId.setSubjectKeyIdentifier(localSubjectKeyIdentifier.getKeyIdentifier());
    }
    return getPublicKeyInfoFromOriginatorId(localOriginatorId);
  }

  private SubjectPublicKeyInfo getPublicKeyInfoFromOriginatorPublicKey(AlgorithmIdentifier paramAlgorithmIdentifier, OriginatorPublicKey paramOriginatorPublicKey)
  {
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo(paramAlgorithmIdentifier, paramOriginatorPublicKey.getPublicKey().getBytes());
    return localSubjectPublicKeyInfo;
  }

  private SubjectPublicKeyInfo getPublicKeyInfoFromOriginatorId(OriginatorId paramOriginatorId)
    throws CMSException
  {
    throw new CMSException("No support for 'originator' as IssuerAndSerialNumber or SubjectKeyIdentifier");
  }

  private PublicKey getSenderPublicKey(Key paramKey, OriginatorIdentifierOrKey paramOriginatorIdentifierOrKey, Provider paramProvider)
    throws CMSException, GeneralSecurityException, IOException
  {
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = getSenderPublicKeyInfo(PrivateKeyInfo.getInstance(paramKey.getEncoded()).getAlgorithmId(), paramOriginatorIdentifierOrKey);
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(localSubjectPublicKeyInfo.getEncoded());
    KeyFactory localKeyFactory = KeyFactory.getInstance(this.keyEncAlg.getAlgorithm().getId(), paramProvider);
    return localKeyFactory.generatePublic(localX509EncodedKeySpec);
  }

  private PublicKey getPublicKeyFromOriginatorPublicKey(Key paramKey, OriginatorPublicKey paramOriginatorPublicKey, Provider paramProvider)
    throws CMSException, GeneralSecurityException, IOException
  {
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = getPublicKeyInfoFromOriginatorPublicKey(PrivateKeyInfo.getInstance(paramKey.getEncoded()).getAlgorithmId(), paramOriginatorPublicKey);
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(localSubjectPublicKeyInfo.getEncoded());
    KeyFactory localKeyFactory = KeyFactory.getInstance(this.keyEncAlg.getAlgorithm().getId(), paramProvider);
    return localKeyFactory.generatePublic(localX509EncodedKeySpec);
  }

  private SecretKey calculateAgreedWrapKey(String paramString, PublicKey paramPublicKey, PrivateKey paramPrivateKey, Provider paramProvider)
    throws CMSException, GeneralSecurityException, IOException
  {
    String str = this.keyEncAlg.getAlgorithm().getId();
    if (str.equals(CMSEnvelopedGenerator.ECMQV_SHA1KDF))
    {
      localObject = this.info.getUserKeyingMaterial().getOctets();
      MQVuserKeyingMaterial localMQVuserKeyingMaterial = MQVuserKeyingMaterial.getInstance(ASN1Object.fromByteArray(localObject));
      PublicKey localPublicKey = getPublicKeyFromOriginatorPublicKey(paramPrivateKey, localMQVuserKeyingMaterial.getEphemeralPublicKey(), paramProvider);
      paramPublicKey = new MQVPublicKeySpec(paramPublicKey, localPublicKey);
      paramPrivateKey = new MQVPrivateKeySpec(paramPrivateKey, paramPrivateKey);
    }
    Object localObject = KeyAgreement.getInstance(str, paramProvider);
    ((KeyAgreement)localObject).init(paramPrivateKey);
    ((KeyAgreement)localObject).doPhase(paramPublicKey, true);
    return (SecretKey)((KeyAgreement)localObject).generateSecret(paramString);
  }

  private Key unwrapSessionKey(String paramString, SecretKey paramSecretKey, Provider paramProvider)
    throws GeneralSecurityException
  {
    Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createSymmetricCipher(paramString, paramProvider);
    localCipher.init(4, paramSecretKey);
    return localCipher.unwrap(this.encryptedKey.getOctets(), getContentAlgorithmName(), 3);
  }

  protected Key getSessionKey(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      String str = AlgorithmIdentifier.getInstance(this.keyEncAlg.getParameters()).getAlgorithm().getId();
      PublicKey localPublicKey = getSenderPublicKey(paramKey, this.info.getOriginator(), paramProvider);
      SecretKey localSecretKey = calculateAgreedWrapKey(str, localPublicKey, (PrivateKey)paramKey, paramProvider);
      return unwrapSessionKey(str, localSecretKey, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (InvalidKeySpecException localInvalidKeySpecException)
    {
      throw new CMSException("originator key spec invalid.", localInvalidKeySpecException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (Exception localException)
    {
    }
    throw new CMSException("originator key invalid.", localException);
  }

  /** @deprecated */
  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }

  /** @deprecated */
  public CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    Key localKey = getSessionKey(paramKey, paramProvider);
    return getContentFromSessionKey(localKey, paramProvider);
  }

  protected RecipientOperator getRecipientOperator(Recipient paramRecipient)
    throws CMSException, IOException
  {
    KeyAgreeRecipient localKeyAgreeRecipient = (KeyAgreeRecipient)paramRecipient;
    AlgorithmIdentifier localAlgorithmIdentifier = localKeyAgreeRecipient.getPrivateKeyAlgorithmIdentifier();
    return ((KeyAgreeRecipient)paramRecipient).getRecipientOperator(this.keyEncAlg, this.messageAlgorithm, getSenderPublicKeyInfo(localAlgorithmIdentifier, this.info.getOriginator()), this.info.getUserKeyingMaterial(), this.encryptedKey.getOctets());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.KeyAgreeRecipientInformation
 * JD-Core Version:    0.6.0
 */