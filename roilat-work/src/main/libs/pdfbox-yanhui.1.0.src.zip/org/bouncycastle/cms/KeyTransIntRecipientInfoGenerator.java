package org.bouncycastle.cms;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.ProviderException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.KeyTransRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientIdentifier;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;

class KeyTransIntRecipientInfoGenerator
  implements IntRecipientInfoGenerator
{
  private TBSCertificateStructure recipientTBSCert;
  private PublicKey recipientPublicKey;
  private ASN1OctetString subjectKeyIdentifier;
  private SubjectPublicKeyInfo info;

  void setRecipientCert(X509Certificate paramX509Certificate)
  {
    this.recipientTBSCert = CMSUtils.getTBSCertificateStructure(paramX509Certificate);
    this.recipientPublicKey = paramX509Certificate.getPublicKey();
    this.info = this.recipientTBSCert.getSubjectPublicKeyInfo();
  }

  void setRecipientPublicKey(PublicKey paramPublicKey)
  {
    this.recipientPublicKey = paramPublicKey;
    try
    {
      this.info = SubjectPublicKeyInfo.getInstance(ASN1Object.fromByteArray(paramPublicKey.getEncoded()));
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("can't extract key algorithm from this key");
    }
  }

  void setSubjectKeyIdentifier(ASN1OctetString paramASN1OctetString)
  {
    this.subjectKeyIdentifier = paramASN1OctetString;
  }

  public RecipientInfo generate(SecretKey paramSecretKey, SecureRandom paramSecureRandom, Provider paramProvider)
    throws GeneralSecurityException
  {
    AlgorithmIdentifier localAlgorithmIdentifier = this.info.getAlgorithmId();
    byte[] arrayOfByte = null;
    Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createAsymmetricCipher(localAlgorithmIdentifier.getObjectId().getId(), paramProvider);
    try
    {
      localCipher.init(3, this.recipientPublicKey, paramSecureRandom);
      arrayOfByte = localCipher.wrap(paramSecretKey);
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    catch (IllegalStateException localIllegalStateException)
    {
    }
    catch (UnsupportedOperationException localUnsupportedOperationException)
    {
    }
    catch (ProviderException localProviderException)
    {
    }
    if (arrayOfByte == null)
    {
      localCipher.init(1, this.recipientPublicKey, paramSecureRandom);
      arrayOfByte = localCipher.doFinal(paramSecretKey.getEncoded());
    }
    RecipientIdentifier localRecipientIdentifier;
    if (this.recipientTBSCert != null)
    {
      IssuerAndSerialNumber localIssuerAndSerialNumber = new IssuerAndSerialNumber(this.recipientTBSCert.getIssuer(), this.recipientTBSCert.getSerialNumber().getValue());
      localRecipientIdentifier = new RecipientIdentifier(localIssuerAndSerialNumber);
    }
    else
    {
      localRecipientIdentifier = new RecipientIdentifier(this.subjectKeyIdentifier);
    }
    return new RecipientInfo(new KeyTransRecipientInfo(localRecipientIdentifier, localAlgorithmIdentifier, new DEROctetString(arrayOfByte)));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.KeyTransIntRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */