package org.bouncycastle.cms;

import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.KeyTransRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientIdentifier;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.operator.AsymmetricKeyWrapper;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.OperatorException;

public abstract class KeyTransRecipientInfoGenerator
  implements RecipientInfoGenerator
{
  protected final AsymmetricKeyWrapper wrapper;
  private IssuerAndSerialNumber issuerAndSerial;
  private byte[] subjectKeyIdentifier;

  protected KeyTransRecipientInfoGenerator(IssuerAndSerialNumber paramIssuerAndSerialNumber, AsymmetricKeyWrapper paramAsymmetricKeyWrapper)
  {
    this.issuerAndSerial = paramIssuerAndSerialNumber;
    this.wrapper = paramAsymmetricKeyWrapper;
  }

  protected KeyTransRecipientInfoGenerator(byte[] paramArrayOfByte, AsymmetricKeyWrapper paramAsymmetricKeyWrapper)
  {
    this.subjectKeyIdentifier = paramArrayOfByte;
    this.wrapper = paramAsymmetricKeyWrapper;
  }

  public final RecipientInfo generate(GenericKey paramGenericKey)
    throws CMSException
  {
    byte[] arrayOfByte;
    try
    {
      arrayOfByte = this.wrapper.generateWrappedKey(paramGenericKey);
    }
    catch (OperatorException localOperatorException)
    {
      throw new CMSException("exception wrapping content key: " + localOperatorException.getMessage(), localOperatorException);
    }
    RecipientIdentifier localRecipientIdentifier;
    if (this.issuerAndSerial != null)
      localRecipientIdentifier = new RecipientIdentifier(this.issuerAndSerial);
    else
      localRecipientIdentifier = new RecipientIdentifier(new DEROctetString(this.subjectKeyIdentifier));
    return new RecipientInfo(new KeyTransRecipientInfo(localRecipientIdentifier, this.wrapper.getAlgorithmIdentifier(), new DEROctetString(arrayOfByte)));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.KeyTransRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */