package org.bouncycastle.cms;

import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.ProviderException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.KeyTransRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class KeyTransRecipientInformation extends RecipientInformation
{
  private KeyTransRecipientInfo info;

  KeyTransRecipientInformation(KeyTransRecipientInfo paramKeyTransRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier, CMSSecureReadable paramCMSSecureReadable, AuthAttributesProvider paramAuthAttributesProvider)
  {
    super(paramKeyTransRecipientInfo.getKeyEncryptionAlgorithm(), paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider);
    this.info = paramKeyTransRecipientInfo;
    RecipientIdentifier localRecipientIdentifier = paramKeyTransRecipientInfo.getRecipientIdentifier();
    Object localObject;
    if (localRecipientIdentifier.isTagged())
    {
      localObject = ASN1OctetString.getInstance(localRecipientIdentifier.getId());
      this.rid = new KeyTransRecipientId(((ASN1OctetString)localObject).getOctets());
    }
    else
    {
      localObject = IssuerAndSerialNumber.getInstance(localRecipientIdentifier.getId());
      this.rid = new KeyTransRecipientId(((IssuerAndSerialNumber)localObject).getName(), ((IssuerAndSerialNumber)localObject).getSerialNumber().getValue());
    }
  }

  private String getExchangeEncryptionAlgorithmName(DERObjectIdentifier paramDERObjectIdentifier)
  {
    if (PKCSObjectIdentifiers.rsaEncryption.equals(paramDERObjectIdentifier))
      return "RSA/ECB/PKCS1Padding";
    return paramDERObjectIdentifier.getId();
  }

  /** @deprecated */
  protected Key getSessionKey(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    CMSEnvelopedHelper localCMSEnvelopedHelper = CMSEnvelopedHelper.INSTANCE;
    String str1 = getExchangeEncryptionAlgorithmName(this.keyEncAlg.getObjectId());
    try
    {
      Object localObject = null;
      Cipher localCipher = localCMSEnvelopedHelper.createAsymmetricCipher(str1, paramProvider);
      byte[] arrayOfByte = this.info.getEncryptedKey().getOctets();
      String str2 = getContentAlgorithmName();
      try
      {
        localCipher.init(4, paramKey);
        localObject = localCipher.unwrap(arrayOfByte, str2, 3);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
      }
      catch (ProviderException localProviderException)
      {
      }
      if (localObject == null)
      {
        localCipher.init(2, paramKey);
        localObject = new SecretKeySpec(localCipher.doFinal(arrayOfByte), str2);
      }
      return localObject;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (IllegalBlockSizeException localIllegalBlockSizeException)
    {
      throw new CMSException("illegal blocksize in message.", localIllegalBlockSizeException);
    }
    catch (BadPaddingException localBadPaddingException)
    {
    }
    throw new CMSException("bad padding in message.", localBadPaddingException);
  }

  /** @deprecated */
  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }

  /** @deprecated */
  public CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    Key localKey = getSessionKey(paramKey, paramProvider);
    return getContentFromSessionKey(localKey, paramProvider);
  }

  protected RecipientOperator getRecipientOperator(Recipient paramRecipient)
    throws CMSException
  {
    return ((KeyTransRecipient)paramRecipient).getRecipientOperator(this.keyEncAlg, this.messageAlgorithm, this.info.getEncryptedKey().getOctets());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.KeyTransRecipientInformation
 * JD-Core Version:    0.6.0
 */