package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;

class NullOutputStream extends OutputStream
{
  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
  }

  public void write(int paramInt)
    throws IOException
  {
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.NullOutputStream
 * JD-Core Version:    0.6.0
 */