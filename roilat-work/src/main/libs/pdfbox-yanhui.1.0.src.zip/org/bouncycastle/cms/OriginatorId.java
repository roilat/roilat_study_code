package org.bouncycastle.cms;

import java.math.BigInteger;
import java.security.cert.X509CertSelector;
import org.bouncycastle.util.Arrays;

class OriginatorId extends X509CertSelector
{
  public int hashCode()
  {
    int i = Arrays.hashCode(getSubjectKeyIdentifier());
    if (getSerialNumber() != null)
      i ^= getSerialNumber().hashCode();
    if (getIssuerAsString() != null)
      i ^= getIssuerAsString().hashCode();
    return i;
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof OriginatorId))
      return false;
    OriginatorId localOriginatorId = (OriginatorId)paramObject;
    return (Arrays.areEqual(getSubjectKeyIdentifier(), localOriginatorId.getSubjectKeyIdentifier())) && (equalsObj(getSerialNumber(), localOriginatorId.getSerialNumber())) && (equalsObj(getIssuerAsString(), localOriginatorId.getIssuerAsString()));
  }

  private boolean equalsObj(Object paramObject1, Object paramObject2)
  {
    return paramObject2 == null ? true : paramObject1 != null ? paramObject1.equals(paramObject2) : false;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.OriginatorId
 * JD-Core Version:    0.6.0
 */