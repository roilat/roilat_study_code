package org.bouncycastle.cms;

import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;

public class PKCS5Scheme2PBEKey extends CMSPBEKey
{
  public PKCS5Scheme2PBEKey(char[] paramArrayOfChar, byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfChar, paramArrayOfByte, paramInt);
  }

  public PKCS5Scheme2PBEKey(char[] paramArrayOfChar, AlgorithmParameters paramAlgorithmParameters)
    throws InvalidAlgorithmParameterException
  {
    super(paramArrayOfChar, getParamSpec(paramAlgorithmParameters));
  }

  byte[] getEncoded(String paramString)
  {
    PKCS5S2ParametersGenerator localPKCS5S2ParametersGenerator = new PKCS5S2ParametersGenerator();
    localPKCS5S2ParametersGenerator.init(PBEParametersGenerator.PKCS5PasswordToBytes(getPassword()), getSalt(), getIterationCount());
    return ((KeyParameter)localPKCS5S2ParametersGenerator.generateDerivedParameters(CMSEnvelopedHelper.INSTANCE.getKeySize(paramString))).getKey();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.PKCS5Scheme2PBEKey
 * JD-Core Version:    0.6.0
 */