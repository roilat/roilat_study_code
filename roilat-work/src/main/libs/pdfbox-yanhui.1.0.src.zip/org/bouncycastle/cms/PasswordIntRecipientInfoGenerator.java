package org.bouncycastle.cms;

import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.cms.PasswordRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

class PasswordIntRecipientInfoGenerator
  implements IntRecipientInfoGenerator
{
  private AlgorithmIdentifier keyDerivationAlgorithm;
  private SecretKey keyEncryptionKey;

  void setKeyDerivationAlgorithm(AlgorithmIdentifier paramAlgorithmIdentifier)
  {
    this.keyDerivationAlgorithm = paramAlgorithmIdentifier;
  }

  void setKeyEncryptionKey(SecretKey paramSecretKey)
  {
    this.keyEncryptionKey = paramSecretKey;
  }

  public RecipientInfo generate(SecretKey paramSecretKey, SecureRandom paramSecureRandom, Provider paramProvider)
    throws GeneralSecurityException
  {
    CMSEnvelopedHelper localCMSEnvelopedHelper = CMSEnvelopedHelper.INSTANCE;
    String str = localCMSEnvelopedHelper.getRFC3211WrapperName(this.keyEncryptionKey.getAlgorithm());
    Cipher localCipher = localCMSEnvelopedHelper.createSymmetricCipher(str, paramProvider);
    localCipher.init(3, this.keyEncryptionKey, paramSecureRandom);
    byte[] arrayOfByte = localCipher.wrap(paramSecretKey);
    DEROctetString localDEROctetString = new DEROctetString(arrayOfByte);
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERObjectIdentifier(this.keyEncryptionKey.getAlgorithm()));
    localASN1EncodableVector.add(new DEROctetString(localCipher.getIV()));
    AlgorithmIdentifier localAlgorithmIdentifier = new AlgorithmIdentifier(PKCSObjectIdentifiers.id_alg_PWRI_KEK, new DERSequence(localASN1EncodableVector));
    return new RecipientInfo(new PasswordRecipientInfo(this.keyDerivationAlgorithm, localAlgorithmIdentifier, localDEROctetString));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.PasswordIntRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */