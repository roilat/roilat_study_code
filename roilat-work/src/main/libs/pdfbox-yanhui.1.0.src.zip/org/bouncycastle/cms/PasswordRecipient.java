package org.bouncycastle.cms;

import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface PasswordRecipient extends Recipient
{
  public static final int PKCS5_SCHEME2 = 0;
  public static final int PKCS5_SCHEME2_UTF8 = 1;

  public abstract RecipientOperator getRecipientOperator(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws CMSException;

  public abstract int getPasswordConversionScheme();

  public abstract char[] getPassword();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.PasswordRecipient
 * JD-Core Version:    0.6.0
 */