package org.bouncycastle.cms;

public class PasswordRecipientId extends RecipientId
{
  public PasswordRecipientId()
  {
    super(3);
  }

  public int hashCode()
  {
    return 3;
  }

  public boolean equals(Object paramObject)
  {
    return (paramObject instanceof PasswordRecipientId);
  }

  public boolean match(Object paramObject)
  {
    return (paramObject instanceof PasswordRecipientInformation);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.PasswordRecipientId
 * JD-Core Version:    0.6.0
 */