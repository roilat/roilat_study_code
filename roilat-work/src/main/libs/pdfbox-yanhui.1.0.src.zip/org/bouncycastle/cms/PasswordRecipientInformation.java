package org.bouncycastle.cms;

import java.io.IOException;
import java.math.BigInteger;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.PasswordRecipientInfo;
import org.bouncycastle.asn1.pkcs.PBKDF2Params;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;

public class PasswordRecipientInformation extends RecipientInformation
{
  static Map KEYSIZES = new HashMap();
  static Map BLOCKSIZES = new HashMap();
  private PasswordRecipientInfo info;

  PasswordRecipientInformation(PasswordRecipientInfo paramPasswordRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier, CMSSecureReadable paramCMSSecureReadable, AuthAttributesProvider paramAuthAttributesProvider)
  {
    super(paramPasswordRecipientInfo.getKeyEncryptionAlgorithm(), paramAlgorithmIdentifier, paramCMSSecureReadable, paramAuthAttributesProvider);
    this.info = paramPasswordRecipientInfo;
    this.rid = new PasswordRecipientId();
  }

  public String getKeyDerivationAlgOID()
  {
    if (this.info.getKeyDerivationAlgorithm() != null)
      return this.info.getKeyDerivationAlgorithm().getObjectId().getId();
    return null;
  }

  public byte[] getKeyDerivationAlgParams()
  {
    try
    {
      if (this.info.getKeyDerivationAlgorithm() != null)
      {
        DEREncodable localDEREncodable = this.info.getKeyDerivationAlgorithm().getParameters();
        if (localDEREncodable != null)
          return localDEREncodable.getDERObject().getEncoded();
      }
      return null;
    }
    catch (Exception localException)
    {
    }
    throw new RuntimeException("exception getting encryption parameters " + localException);
  }

  public AlgorithmParameters getKeyDerivationAlgParameters(String paramString)
    throws NoSuchProviderException
  {
    return getKeyDerivationAlgParameters(CMSUtils.getProvider(paramString));
  }

  public AlgorithmParameters getKeyDerivationAlgParameters(Provider paramProvider)
  {
    try
    {
      if (this.info.getKeyDerivationAlgorithm() != null)
      {
        DEREncodable localDEREncodable = this.info.getKeyDerivationAlgorithm().getParameters();
        if (localDEREncodable != null)
        {
          AlgorithmParameters localAlgorithmParameters = AlgorithmParameters.getInstance(this.info.getKeyDerivationAlgorithm().getObjectId().toString(), paramProvider);
          localAlgorithmParameters.init(localDEREncodable.getDERObject().getEncoded());
          return localAlgorithmParameters;
        }
      }
      return null;
    }
    catch (Exception localException)
    {
    }
    throw new RuntimeException("exception getting encryption parameters " + localException);
  }

  /** @deprecated */
  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }

  /** @deprecated */
  public CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      CMSEnvelopedHelper localCMSEnvelopedHelper = CMSEnvelopedHelper.INSTANCE;
      AlgorithmIdentifier localAlgorithmIdentifier = AlgorithmIdentifier.getInstance(this.info.getKeyEncryptionAlgorithm());
      ASN1Sequence localASN1Sequence = (ASN1Sequence)localAlgorithmIdentifier.getParameters();
      String str1 = DERObjectIdentifier.getInstance(localASN1Sequence.getObjectAt(0)).getId();
      String str2 = localCMSEnvelopedHelper.getRFC3211WrapperName(str1);
      Cipher localCipher = localCMSEnvelopedHelper.createSymmetricCipher(str2, paramProvider);
      IvParameterSpec localIvParameterSpec = new IvParameterSpec(ASN1OctetString.getInstance(localASN1Sequence.getObjectAt(1)).getOctets());
      localCipher.init(4, new SecretKeySpec(((CMSPBEKey)paramKey).getEncoded(str1), str1), localIvParameterSpec);
      Key localKey = localCipher.unwrap(this.info.getEncryptedKey().getOctets(), getContentAlgorithmName(), 3);
      return getContentFromSessionKey(localKey, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
    }
    throw new CMSException("invalid iv.", localInvalidAlgorithmParameterException);
  }

  protected RecipientOperator getRecipientOperator(Recipient paramRecipient)
    throws CMSException, IOException
  {
    PasswordRecipient localPasswordRecipient = (PasswordRecipient)paramRecipient;
    AlgorithmIdentifier localAlgorithmIdentifier = AlgorithmIdentifier.getInstance(this.info.getKeyEncryptionAlgorithm());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localAlgorithmIdentifier.getParameters();
    DERObjectIdentifier localDERObjectIdentifier = DERObjectIdentifier.getInstance(localASN1Sequence.getObjectAt(0));
    PBKDF2Params localPBKDF2Params = PBKDF2Params.getInstance(this.info.getKeyDerivationAlgorithm().getParameters());
    int i = ((Integer)KEYSIZES.get(localDERObjectIdentifier)).intValue();
    PKCS5S2ParametersGenerator localPKCS5S2ParametersGenerator;
    byte[] arrayOfByte;
    if (localPasswordRecipient.getPasswordConversionScheme() == 0)
    {
      localPKCS5S2ParametersGenerator = new PKCS5S2ParametersGenerator();
      localPKCS5S2ParametersGenerator.init(PBEParametersGenerator.PKCS5PasswordToBytes(localPasswordRecipient.getPassword()), localPBKDF2Params.getSalt(), localPBKDF2Params.getIterationCount().intValue());
      arrayOfByte = ((KeyParameter)localPKCS5S2ParametersGenerator.generateDerivedParameters(i)).getKey();
    }
    else
    {
      localPKCS5S2ParametersGenerator = new PKCS5S2ParametersGenerator();
      localPKCS5S2ParametersGenerator.init(PBEParametersGenerator.PKCS5PasswordToUTF8Bytes(localPasswordRecipient.getPassword()), localPBKDF2Params.getSalt(), localPBKDF2Params.getIterationCount().intValue());
      arrayOfByte = ((KeyParameter)localPKCS5S2ParametersGenerator.generateDerivedParameters(i)).getKey();
    }
    return localPasswordRecipient.getRecipientOperator(AlgorithmIdentifier.getInstance(localAlgorithmIdentifier.getParameters()), this.messageAlgorithm, arrayOfByte, this.info.getEncryptedKey().getOctets());
  }

  static
  {
    BLOCKSIZES.put(CMSAlgorithm.DES_EDE3_CBC, new Integer(8));
    BLOCKSIZES.put(CMSAlgorithm.AES128_CBC, new Integer(16));
    BLOCKSIZES.put(CMSAlgorithm.AES192_CBC, new Integer(16));
    BLOCKSIZES.put(CMSAlgorithm.AES256_CBC, new Integer(16));
    KEYSIZES.put(CMSAlgorithm.DES_EDE3_CBC, new Integer(192));
    KEYSIZES.put(CMSAlgorithm.AES128_CBC, new Integer(128));
    KEYSIZES.put(CMSAlgorithm.AES192_CBC, new Integer(192));
    KEYSIZES.put(CMSAlgorithm.AES256_CBC, new Integer(256));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.PasswordRecipientInformation
 * JD-Core Version:    0.6.0
 */