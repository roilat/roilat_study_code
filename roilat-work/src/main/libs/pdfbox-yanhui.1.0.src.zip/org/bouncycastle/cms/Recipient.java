package org.bouncycastle.cms;

public abstract interface Recipient
{
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.Recipient
 * JD-Core Version:    0.6.0
 */