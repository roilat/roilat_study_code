package org.bouncycastle.cms;

import java.security.cert.X509CertSelector;
import org.bouncycastle.util.Selector;

public abstract class RecipientId extends X509CertSelector
  implements Selector
{
  public static final int keyTrans = 0;
  public static final int kek = 1;
  public static final int keyAgree = 2;
  public static final int password = 3;
  private final int type;

  protected RecipientId(int paramInt)
  {
    this.type = paramInt;
  }

  public int getType()
  {
    return this.type;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.RecipientId
 * JD-Core Version:    0.6.0
 */