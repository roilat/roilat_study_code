package org.bouncycastle.cms;

import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.operator.GenericKey;

public abstract interface RecipientInfoGenerator
{
  public abstract RecipientInfo generate(GenericKey paramGenericKey)
    throws CMSException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.RecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */