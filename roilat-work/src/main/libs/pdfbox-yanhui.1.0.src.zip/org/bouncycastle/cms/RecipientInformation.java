package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.AlgorithmParameters;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.util.io.Streams;

public abstract class RecipientInformation
{
  protected RecipientId rid;
  protected AlgorithmIdentifier keyEncAlg;
  protected AlgorithmIdentifier messageAlgorithm;
  private CMSSecureReadable secureReadable;
  private AuthAttributesProvider additionalData;
  private byte[] resultMac;
  private RecipientOperator operator;

  RecipientInformation(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, CMSSecureReadable paramCMSSecureReadable, AuthAttributesProvider paramAuthAttributesProvider)
  {
    this.keyEncAlg = paramAlgorithmIdentifier1;
    this.messageAlgorithm = paramAlgorithmIdentifier2;
    this.secureReadable = paramCMSSecureReadable;
    this.additionalData = paramAuthAttributesProvider;
  }

  String getContentAlgorithmName()
  {
    AlgorithmIdentifier localAlgorithmIdentifier = this.secureReadable.getAlgorithm();
    return CMSEnvelopedHelper.INSTANCE.getSymmetricCipherName(localAlgorithmIdentifier.getObjectId().getId());
  }

  public RecipientId getRID()
  {
    return this.rid;
  }

  private byte[] encodeObj(DEREncodable paramDEREncodable)
    throws IOException
  {
    if (paramDEREncodable != null)
      return paramDEREncodable.getDERObject().getEncoded();
    return null;
  }

  public String getKeyEncryptionAlgOID()
  {
    return this.keyEncAlg.getObjectId().getId();
  }

  public byte[] getKeyEncryptionAlgParams()
  {
    try
    {
      return encodeObj(this.keyEncAlg.getParameters());
    }
    catch (Exception localException)
    {
    }
    throw new RuntimeException("exception getting encryption parameters " + localException);
  }

  public AlgorithmParameters getKeyEncryptionAlgorithmParameters(String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getKeyEncryptionAlgorithmParameters(CMSUtils.getProvider(paramString));
  }

  public AlgorithmParameters getKeyEncryptionAlgorithmParameters(Provider paramProvider)
    throws CMSException
  {
    try
    {
      byte[] arrayOfByte = encodeObj(this.keyEncAlg.getParameters());
      if (arrayOfByte == null)
        return null;
      AlgorithmParameters localAlgorithmParameters = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameters(getKeyEncryptionAlgOID(), paramProvider);
      localAlgorithmParameters.init(arrayOfByte, "ASN.1");
      return localAlgorithmParameters;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find parameters for algorithm", localNoSuchAlgorithmException);
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("can't find parse parameters", localIOException);
  }

  protected CMSTypedStream getContentFromSessionKey(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    CMSReadable localCMSReadable = this.secureReadable.getReadable((SecretKey)paramKey, paramProvider);
    try
    {
      return new CMSTypedStream(localCMSReadable.getInputStream());
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("error getting .", localIOException);
  }

  /** @deprecated */
  public byte[] getContent(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContent(paramKey, CMSUtils.getProvider(paramString));
  }

  /** @deprecated */
  public byte[] getContent(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      return CMSUtils.streamToByteArray(getContentStream(paramKey, paramProvider).getContentStream());
    }
    catch (IOException localIOException)
    {
    }
    throw new RuntimeException("unable to parse internal stream: " + localIOException);
  }

  public byte[] getContentDigest()
  {
    if ((this.secureReadable instanceof CMSEnvelopedHelper.CMSDigestAuthenticatedSecureReadable))
      return ((CMSEnvelopedHelper.CMSDigestAuthenticatedSecureReadable)this.secureReadable).getDigest();
    return null;
  }

  public byte[] getMac()
  {
    if (this.resultMac == null)
      if (this.operator != null)
      {
        if (this.operator.isMacBased())
        {
          if (this.additionalData != null)
            try
            {
              Streams.drain(this.operator.getInputStream(new ByteArrayInputStream(this.additionalData.getAuthAttributes().getDEREncoded())));
            }
            catch (IOException localIOException)
            {
              localIOException.printStackTrace();
            }
          this.resultMac = this.operator.getMac();
        }
      }
      else
      {
        Object localObject = this.secureReadable.getCryptoObject();
        if ((localObject instanceof Mac))
          this.resultMac = ((Mac)localObject).doFinal();
      }
    return this.resultMac;
  }

  public byte[] getContent(Recipient paramRecipient)
    throws CMSException
  {
    try
    {
      return CMSUtils.streamToByteArray(getContentStream(paramRecipient).getContentStream());
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("unable to parse internal stream: " + localIOException.getMessage(), localIOException);
  }

  /** @deprecated */
  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }

  /** @deprecated */
  public abstract CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException;

  public CMSTypedStream getContentStream(Recipient paramRecipient)
    throws CMSException, IOException
  {
    this.operator = getRecipientOperator(paramRecipient);
    if (this.additionalData != null)
      return new CMSTypedStream(this.secureReadable.getInputStream());
    return new CMSTypedStream(this.operator.getInputStream(this.secureReadable.getInputStream()));
  }

  protected abstract RecipientOperator getRecipientOperator(Recipient paramRecipient)
    throws CMSException, IOException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.RecipientInformation
 * JD-Core Version:    0.6.0
 */