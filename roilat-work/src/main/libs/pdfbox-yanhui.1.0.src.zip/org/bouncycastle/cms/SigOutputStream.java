package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;
import java.security.Signature;
import java.security.SignatureException;

class SigOutputStream extends OutputStream
{
  private final Signature sig;

  SigOutputStream(Signature paramSignature)
  {
    this.sig = paramSignature;
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    try
    {
      this.sig.update(paramArrayOfByte, paramInt1, paramInt2);
    }
    catch (SignatureException localSignatureException)
    {
      throw new CMSStreamException("signature problem: " + localSignatureException, localSignatureException);
    }
  }

  public void write(int paramInt)
    throws IOException
  {
    try
    {
      this.sig.update((byte)paramInt);
    }
    catch (SignatureException localSignatureException)
    {
      throw new CMSStreamException("signature problem: " + localSignatureException, localSignatureException);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.SigOutputStream
 * JD-Core Version:    0.6.0
 */