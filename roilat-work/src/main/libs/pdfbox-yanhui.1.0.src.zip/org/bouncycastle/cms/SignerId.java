package org.bouncycastle.cms;

import java.io.IOException;
import java.math.BigInteger;
import java.security.cert.X509CertSelector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.Selector;

public class SignerId extends X509CertSelector
  implements Selector
{
  private byte[] subjectKeyId;
  private X500Name issuer;
  private BigInteger serialNumber;

  /** @deprecated */
  public SignerId()
  {
  }

  public SignerId(byte[] paramArrayOfByte)
  {
    super.setSubjectKeyIdentifier(new DEROctetString(paramArrayOfByte).getDEREncoded());
    this.subjectKeyId = paramArrayOfByte;
  }

  public SignerId(X500Name paramX500Name, BigInteger paramBigInteger)
  {
    this.issuer = paramX500Name;
    this.serialNumber = paramBigInteger;
    try
    {
      setIssuer(paramX500Name.getDEREncoded());
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("invalid issuer: " + localIOException.getMessage());
    }
    setSerialNumber(paramBigInteger);
  }

  public int hashCode()
  {
    int i = Arrays.hashCode(this.subjectKeyId);
    if (this.serialNumber != null)
      i ^= this.serialNumber.hashCode();
    if (this.issuer != null)
      i ^= this.issuer.hashCode();
    return i;
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof SignerId))
      return false;
    SignerId localSignerId = (SignerId)paramObject;
    return (Arrays.areEqual(this.subjectKeyId, localSignerId.subjectKeyId)) && (equalsObj(this.serialNumber, localSignerId.serialNumber)) && (equalsObj(this.issuer, localSignerId.issuer));
  }

  private boolean equalsObj(Object paramObject1, Object paramObject2)
  {
    return paramObject2 == null ? true : paramObject1 != null ? paramObject1.equals(paramObject2) : false;
  }

  public boolean match(Object paramObject)
  {
    if ((paramObject instanceof X509CertificateHolder))
    {
      X509CertificateHolder localX509CertificateHolder = (X509CertificateHolder)paramObject;
      Object localObject1;
      if (getSerialNumber() != null)
      {
        localObject1 = localX509CertificateHolder.getIssuerAndSerialNumber();
        return (((IssuerAndSerialNumber)localObject1).getName().equals(this.issuer)) && (((IssuerAndSerialNumber)localObject1).getSerialNumber().getValue().equals(this.serialNumber));
      }
      if (getSubjectKeyIdentifier() != null)
      {
        localObject1 = localX509CertificateHolder.getExtension(X509Extension.subjectKeyIdentifier);
        if (localObject1 == null)
        {
          localObject2 = new SHA1Digest();
          byte[] arrayOfByte1 = new byte[((Digest)localObject2).getDigestSize()];
          byte[] arrayOfByte2 = localX509CertificateHolder.getSubjectPublicKeyInfo().getDEREncoded();
          ((Digest)localObject2).update(arrayOfByte2, 0, arrayOfByte2.length);
          ((Digest)localObject2).doFinal(arrayOfByte1, 0);
          return Arrays.areEqual(this.subjectKeyId, arrayOfByte1);
        }
        Object localObject2 = ASN1OctetString.getInstance(((X509Extension)localObject1).getParsedValue()).getOctets();
        return Arrays.areEqual(this.subjectKeyId, localObject2);
      }
    }
    else
    {
      if ((paramObject instanceof byte[]))
        return Arrays.areEqual(this.subjectKeyId, (byte[])(byte[])paramObject);
      if ((paramObject instanceof SignerInformation))
        return ((SignerInformation)paramObject).getSID().equals(this);
    }
    return false;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.SignerId
 * JD-Core Version:    0.6.0
 */