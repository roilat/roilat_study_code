package org.bouncycastle.cms;

import B;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.SignerIdentifier;
import org.bouncycastle.asn1.cms.SignerInfo;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.teletrust.TeleTrusTObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.DefaultDigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.util.io.TeeOutputStream;

public class SignerInfoGenerator
{
  private static final Set RSA_PKCS1d5 = new HashSet();
  private final SignerIdentifier signerIdentifier;
  private final CMSAttributeTableGenerator sAttrGen;
  private final CMSAttributeTableGenerator unsAttrGen;
  private final ContentSigner signer;
  private final DigestCalculator digester;
  private final DigestAlgorithmIdentifierFinder digAlgFinder = new DefaultDigestAlgorithmIdentifierFinder();
  private byte[] calculatedDigest = null;
  private X509CertificateHolder certHolder;

  public SignerInfoGenerator(SignerIdentifier paramSignerIdentifier, ContentSigner paramContentSigner, DigestCalculatorProvider paramDigestCalculatorProvider)
    throws OperatorCreationException
  {
    this(paramSignerIdentifier, paramContentSigner, paramDigestCalculatorProvider, false);
  }

  public SignerInfoGenerator(SignerIdentifier paramSignerIdentifier, ContentSigner paramContentSigner, DigestCalculatorProvider paramDigestCalculatorProvider, boolean paramBoolean)
    throws OperatorCreationException
  {
    this.signerIdentifier = paramSignerIdentifier;
    this.signer = paramContentSigner;
    if (paramDigestCalculatorProvider != null)
      this.digester = paramDigestCalculatorProvider.get(this.digAlgFinder.find(paramContentSigner.getAlgorithmIdentifier()));
    else
      this.digester = null;
    if (paramBoolean)
    {
      this.sAttrGen = null;
      this.unsAttrGen = null;
    }
    else
    {
      this.sAttrGen = new DefaultSignedAttributeTableGenerator();
      this.unsAttrGen = null;
    }
  }

  public SignerInfoGenerator(SignerInfoGenerator paramSignerInfoGenerator, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
  {
    this.signerIdentifier = paramSignerInfoGenerator.signerIdentifier;
    this.signer = paramSignerInfoGenerator.signer;
    this.digester = paramSignerInfoGenerator.digester;
    this.sAttrGen = paramCMSAttributeTableGenerator1;
    this.unsAttrGen = paramCMSAttributeTableGenerator2;
  }

  public SignerInfoGenerator(SignerIdentifier paramSignerIdentifier, ContentSigner paramContentSigner, DigestCalculatorProvider paramDigestCalculatorProvider, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
    throws OperatorCreationException
  {
    this.signerIdentifier = paramSignerIdentifier;
    this.signer = paramContentSigner;
    if (paramDigestCalculatorProvider != null)
      this.digester = paramDigestCalculatorProvider.get(this.digAlgFinder.find(paramContentSigner.getAlgorithmIdentifier()));
    else
      this.digester = null;
    this.sAttrGen = paramCMSAttributeTableGenerator1;
    this.unsAttrGen = paramCMSAttributeTableGenerator2;
  }

  public boolean hasAssociatedCertificate()
  {
    return this.certHolder != null;
  }

  public X509CertificateHolder getAssociatedCertificate()
  {
    return this.certHolder;
  }

  public AlgorithmIdentifier getDigestAlgorithm()
  {
    if (this.digester != null)
      return this.digester.getAlgorithmIdentifier();
    return this.digAlgFinder.find(this.signer.getAlgorithmIdentifier());
  }

  public OutputStream getCalculatingOutputStream()
  {
    if (this.digester != null)
    {
      if (this.sAttrGen == null)
        return new TeeOutputStream(this.digester.getOutputStream(), this.signer.getOutputStream());
      return this.digester.getOutputStream();
    }
    return this.signer.getOutputStream();
  }

  public SignerInfo generate(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CMSException
  {
    try
    {
      ASN1Set localASN1Set = null;
      AlgorithmIdentifier localAlgorithmIdentifier = null;
      if (this.sAttrGen != null)
      {
        localAlgorithmIdentifier = this.digester.getAlgorithmIdentifier();
        this.calculatedDigest = this.digester.getDigest();
        localObject1 = getBaseParameters(paramASN1ObjectIdentifier, this.digester.getAlgorithmIdentifier(), this.calculatedDigest);
        localObject2 = this.sAttrGen.getAttributes(Collections.unmodifiableMap((Map)localObject1));
        localASN1Set = getAttributeSet((AttributeTable)localObject2);
        localObject3 = this.signer.getOutputStream();
        ((OutputStream)localObject3).write(localASN1Set.getEncoded("DER"));
        ((OutputStream)localObject3).close();
      }
      else if (this.digester != null)
      {
        localAlgorithmIdentifier = this.digester.getAlgorithmIdentifier();
        this.calculatedDigest = this.digester.getDigest();
      }
      else
      {
        localAlgorithmIdentifier = this.digAlgFinder.find(this.signer.getAlgorithmIdentifier());
        this.calculatedDigest = null;
      }
      Object localObject1 = this.signer.getSignature();
      Object localObject2 = null;
      if (this.unsAttrGen != null)
      {
        localObject3 = getBaseParameters(paramASN1ObjectIdentifier, localAlgorithmIdentifier, this.calculatedDigest);
        ((Map)localObject3).put("encryptedDigest", ((byte[])localObject1).clone());
        AttributeTable localAttributeTable = this.unsAttrGen.getAttributes(Collections.unmodifiableMap((Map)localObject3));
        localObject2 = getAttributeSet(localAttributeTable);
      }
      Object localObject3 = getSignatureAlgorithm(this.signer.getAlgorithmIdentifier());
      return new SignerInfo(this.signerIdentifier, localAlgorithmIdentifier, localASN1Set, (AlgorithmIdentifier)localObject3, new DEROctetString(localObject1), (ASN1Set)localObject2);
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("encoding error.", localIOException);
  }

  void setAssociatedCertificate(X509CertificateHolder paramX509CertificateHolder)
  {
    this.certHolder = paramX509CertificateHolder;
  }

  private ASN1Set getAttributeSet(AttributeTable paramAttributeTable)
  {
    if (paramAttributeTable != null)
      return new DERSet(paramAttributeTable.toASN1EncodableVector());
    return null;
  }

  private Map getBaseParameters(DERObjectIdentifier paramDERObjectIdentifier, AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
  {
    HashMap localHashMap = new HashMap();
    if (paramDERObjectIdentifier != null)
      localHashMap.put("contentType", paramDERObjectIdentifier);
    localHashMap.put("digestAlgID", paramAlgorithmIdentifier);
    localHashMap.put("digest", paramArrayOfByte.clone());
    return localHashMap;
  }

  private AlgorithmIdentifier getSignatureAlgorithm(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws IOException
  {
    if (RSA_PKCS1d5.contains(paramAlgorithmIdentifier.getAlgorithm()))
      return new AlgorithmIdentifier(PKCSObjectIdentifiers.rsaEncryption, DERNull.INSTANCE);
    return paramAlgorithmIdentifier;
  }

  public byte[] getCalculatedDigest()
  {
    if (this.calculatedDigest != null)
      return (byte[])(byte[])this.calculatedDigest.clone();
    return null;
  }

  public CMSAttributeTableGenerator getSignedAttributeTableGenerator()
  {
    return this.sAttrGen;
  }

  public CMSAttributeTableGenerator getUnsignedAttributeTableGenerator()
  {
    return this.unsAttrGen;
  }

  static
  {
    RSA_PKCS1d5.add(PKCSObjectIdentifiers.md2WithRSAEncryption);
    RSA_PKCS1d5.add(PKCSObjectIdentifiers.md4WithRSAEncryption);
    RSA_PKCS1d5.add(PKCSObjectIdentifiers.md5WithRSAEncryption);
    RSA_PKCS1d5.add(PKCSObjectIdentifiers.sha1WithRSAEncryption);
    RSA_PKCS1d5.add(PKCSObjectIdentifiers.sha224WithRSAEncryption);
    RSA_PKCS1d5.add(PKCSObjectIdentifiers.sha256WithRSAEncryption);
    RSA_PKCS1d5.add(PKCSObjectIdentifiers.sha384WithRSAEncryption);
    RSA_PKCS1d5.add(PKCSObjectIdentifiers.sha512WithRSAEncryption);
    RSA_PKCS1d5.add(OIWObjectIdentifiers.md4WithRSAEncryption);
    RSA_PKCS1d5.add(OIWObjectIdentifiers.md4WithRSA);
    RSA_PKCS1d5.add(OIWObjectIdentifiers.md5WithRSA);
    RSA_PKCS1d5.add(OIWObjectIdentifiers.sha1WithRSA);
    RSA_PKCS1d5.add(TeleTrusTObjectIdentifiers.rsaSignatureWithripemd128);
    RSA_PKCS1d5.add(TeleTrusTObjectIdentifiers.rsaSignatureWithripemd160);
    RSA_PKCS1d5.add(TeleTrusTObjectIdentifiers.rsaSignatureWithripemd256);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.SignerInfoGenerator
 * JD-Core Version:    0.6.0
 */