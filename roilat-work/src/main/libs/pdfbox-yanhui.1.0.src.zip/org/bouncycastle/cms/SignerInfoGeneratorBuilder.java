package org.bouncycastle.cms;

import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.SignerIdentifier;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;

public class SignerInfoGeneratorBuilder
{
  private DigestCalculatorProvider digestProvider;
  private boolean directSignature;
  private CMSAttributeTableGenerator signedGen;
  private CMSAttributeTableGenerator unsignedGen;

  public SignerInfoGeneratorBuilder(DigestCalculatorProvider paramDigestCalculatorProvider)
  {
    this.digestProvider = paramDigestCalculatorProvider;
  }

  public SignerInfoGeneratorBuilder setDirectSignature(boolean paramBoolean)
  {
    this.directSignature = paramBoolean;
    return this;
  }

  public SignerInfoGeneratorBuilder setSignedAttributeGenerator(CMSAttributeTableGenerator paramCMSAttributeTableGenerator)
  {
    this.signedGen = paramCMSAttributeTableGenerator;
    return this;
  }

  public SignerInfoGeneratorBuilder setUnsignedAttributeGenerator(CMSAttributeTableGenerator paramCMSAttributeTableGenerator)
  {
    this.unsignedGen = paramCMSAttributeTableGenerator;
    return this;
  }

  public SignerInfoGenerator build(ContentSigner paramContentSigner, X509CertificateHolder paramX509CertificateHolder)
    throws OperatorCreationException
  {
    SignerIdentifier localSignerIdentifier = new SignerIdentifier(paramX509CertificateHolder.getIssuerAndSerialNumber());
    SignerInfoGenerator localSignerInfoGenerator = createGenerator(paramContentSigner, localSignerIdentifier);
    localSignerInfoGenerator.setAssociatedCertificate(paramX509CertificateHolder);
    return localSignerInfoGenerator;
  }

  public SignerInfoGenerator build(ContentSigner paramContentSigner, byte[] paramArrayOfByte)
    throws OperatorCreationException
  {
    SignerIdentifier localSignerIdentifier = new SignerIdentifier(new DEROctetString(paramArrayOfByte));
    return createGenerator(paramContentSigner, localSignerIdentifier);
  }

  private SignerInfoGenerator createGenerator(ContentSigner paramContentSigner, SignerIdentifier paramSignerIdentifier)
    throws OperatorCreationException
  {
    if (this.directSignature)
      return new SignerInfoGenerator(paramSignerIdentifier, paramContentSigner, this.digestProvider, true);
    if ((this.signedGen != null) || (this.unsignedGen != null))
    {
      if (this.signedGen == null)
        this.signedGen = new DefaultSignedAttributeTableGenerator();
      return new SignerInfoGenerator(paramSignerIdentifier, paramContentSigner, this.digestProvider, this.signedGen, this.unsignedGen);
    }
    return new SignerInfoGenerator(paramSignerIdentifier, paramContentSigner, this.digestProvider);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.SignerInfoGeneratorBuilder
 * JD-Core Version:    0.6.0
 */