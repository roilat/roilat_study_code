package org.bouncycastle.cms;

import B;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Null;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.SignerIdentifier;
import org.bouncycastle.asn1.cms.SignerInfo;
import org.bouncycastle.asn1.cms.Time;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.DigestInfo;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.DefaultSignatureAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.RawContentVerifier;
import org.bouncycastle.operator.SignatureAlgorithmIdentifierFinder;
import org.bouncycastle.util.Arrays;

public class SignerInformation
{
  private SignerId sid;
  private SignerInfo info;
  private AlgorithmIdentifier digestAlgorithm;
  private AlgorithmIdentifier encryptionAlgorithm;
  private final ASN1Set signedAttributeSet;
  private final ASN1Set unsignedAttributeSet;
  private CMSProcessable content;
  private byte[] signature;
  private ASN1ObjectIdentifier contentType;
  private IntDigestCalculator digestCalculator;
  private byte[] resultDigest;
  private SignatureAlgorithmIdentifierFinder sigAlgFinder;
  private AttributeTable signedAttributeValues;
  private AttributeTable unsignedAttributeValues;
  private boolean isCounterSignature;

  SignerInformation(SignerInfo paramSignerInfo, ASN1ObjectIdentifier paramASN1ObjectIdentifier, CMSProcessable paramCMSProcessable, IntDigestCalculator paramIntDigestCalculator, SignatureAlgorithmIdentifierFinder paramSignatureAlgorithmIdentifierFinder)
  {
    this.info = paramSignerInfo;
    this.contentType = paramASN1ObjectIdentifier;
    this.sigAlgFinder = paramSignatureAlgorithmIdentifierFinder;
    this.isCounterSignature = (paramASN1ObjectIdentifier == null);
    SignerIdentifier localSignerIdentifier = paramSignerInfo.getSID();
    Object localObject;
    if (localSignerIdentifier.isTagged())
    {
      localObject = ASN1OctetString.getInstance(localSignerIdentifier.getId());
      this.sid = new SignerId(((ASN1OctetString)localObject).getOctets());
    }
    else
    {
      localObject = IssuerAndSerialNumber.getInstance(localSignerIdentifier.getId());
      this.sid = new SignerId(((IssuerAndSerialNumber)localObject).getName(), ((IssuerAndSerialNumber)localObject).getSerialNumber().getValue());
    }
    this.digestAlgorithm = paramSignerInfo.getDigestAlgorithm();
    this.signedAttributeSet = paramSignerInfo.getAuthenticatedAttributes();
    this.unsignedAttributeSet = paramSignerInfo.getUnauthenticatedAttributes();
    this.encryptionAlgorithm = paramSignerInfo.getDigestEncryptionAlgorithm();
    this.signature = paramSignerInfo.getEncryptedDigest().getOctets();
    this.content = paramCMSProcessable;
    this.digestCalculator = paramIntDigestCalculator;
  }

  public boolean isCounterSignature()
  {
    return this.isCounterSignature;
  }

  public ASN1ObjectIdentifier getContentType()
  {
    return this.contentType;
  }

  private byte[] encodeObj(DEREncodable paramDEREncodable)
    throws IOException
  {
    if (paramDEREncodable != null)
      return paramDEREncodable.getDERObject().getEncoded();
    return null;
  }

  public SignerId getSID()
  {
    return this.sid;
  }

  public int getVersion()
  {
    return this.info.getVersion().getValue().intValue();
  }

  public AlgorithmIdentifier getDigestAlgorithmID()
  {
    return this.digestAlgorithm;
  }

  public String getDigestAlgOID()
  {
    return this.digestAlgorithm.getObjectId().getId();
  }

  public byte[] getDigestAlgParams()
  {
    try
    {
      return encodeObj(this.digestAlgorithm.getParameters());
    }
    catch (Exception localException)
    {
    }
    throw new RuntimeException("exception getting digest parameters " + localException);
  }

  public byte[] getContentDigest()
  {
    if (this.resultDigest == null)
      throw new IllegalStateException("method can only be called after verify.");
    return (byte[])(byte[])this.resultDigest.clone();
  }

  public String getEncryptionAlgOID()
  {
    return this.encryptionAlgorithm.getObjectId().getId();
  }

  public byte[] getEncryptionAlgParams()
  {
    try
    {
      return encodeObj(this.encryptionAlgorithm.getParameters());
    }
    catch (Exception localException)
    {
    }
    throw new RuntimeException("exception getting encryption parameters " + localException);
  }

  public AttributeTable getSignedAttributes()
  {
    if ((this.signedAttributeSet != null) && (this.signedAttributeValues == null))
      this.signedAttributeValues = new AttributeTable(this.signedAttributeSet);
    return this.signedAttributeValues;
  }

  public AttributeTable getUnsignedAttributes()
  {
    if ((this.unsignedAttributeSet != null) && (this.unsignedAttributeValues == null))
      this.unsignedAttributeValues = new AttributeTable(this.unsignedAttributeSet);
    return this.unsignedAttributeValues;
  }

  public byte[] getSignature()
  {
    return (byte[])(byte[])this.signature.clone();
  }

  public SignerInformationStore getCounterSignatures()
  {
    AttributeTable localAttributeTable = getUnsignedAttributes();
    if (localAttributeTable == null)
      return new SignerInformationStore(new ArrayList(0));
    ArrayList localArrayList = new ArrayList();
    ASN1EncodableVector localASN1EncodableVector = localAttributeTable.getAll(CMSAttributes.counterSignature);
    for (int i = 0; i < localASN1EncodableVector.size(); i++)
    {
      Attribute localAttribute = (Attribute)localASN1EncodableVector.get(i);
      ASN1Set localASN1Set = localAttribute.getAttrValues();
      if (localASN1Set.size() < 1);
      Enumeration localEnumeration = localASN1Set.getObjects();
      while (localEnumeration.hasMoreElements())
      {
        SignerInfo localSignerInfo = SignerInfo.getInstance(localEnumeration.nextElement());
        String str = CMSSignedHelper.INSTANCE.getDigestAlgName(localSignerInfo.getDigestAlgorithm().getObjectId().getId());
        localArrayList.add(new SignerInformation(localSignerInfo, null, null, new CounterSignatureDigestCalculator(str, null, getSignature()), new DefaultSignatureAlgorithmIdentifierFinder()));
      }
    }
    return new SignerInformationStore(localArrayList);
  }

  public byte[] getEncodedSignedAttributes()
    throws IOException
  {
    if (this.signedAttributeSet != null)
      return this.signedAttributeSet.getEncoded("DER");
    return null;
  }

  /** @deprecated */
  private boolean doVerify(PublicKey paramPublicKey, Provider paramProvider)
    throws CMSException, NoSuchAlgorithmException
  {
    String str1 = CMSSignedHelper.INSTANCE.getDigestAlgName(getDigestAlgOID());
    String str2 = CMSSignedHelper.INSTANCE.getEncryptionAlgName(getEncryptionAlgOID());
    String str3 = str1 + "with" + str2;
    Signature localSignature = CMSSignedHelper.INSTANCE.getSignatureInstance(str3, paramProvider);
    MessageDigest localMessageDigest = CMSSignedHelper.INSTANCE.getDigestInstance(str1, paramProvider);
    try
    {
      if (this.digestCalculator != null)
      {
        this.resultDigest = this.digestCalculator.getDigest();
      }
      else
      {
        if (this.content != null)
          this.content.write(new DigOutputStream(localMessageDigest));
        else if (this.signedAttributeSet == null)
          throw new CMSException("data not encapsulated in signature - use detached constructor.");
        this.resultDigest = localMessageDigest.digest();
      }
    }
    catch (IOException localIOException1)
    {
      throw new CMSException("can't process mime object to create signature.", localIOException1);
    }
    Object localObject1 = getSingleValuedSignedAttribute(CMSAttributes.contentType, "content-type");
    if (localObject1 == null)
    {
      if ((!this.isCounterSignature) && (this.signedAttributeSet != null))
        throw new CMSException("The content-type attribute type MUST be present whenever signed attributes are present in signed-data");
    }
    else
    {
      if (this.isCounterSignature)
        throw new CMSException("[For counter signatures,] the signedAttributes field MUST NOT contain a content-type attribute");
      if (!(localObject1 instanceof DERObjectIdentifier))
        throw new CMSException("content-type attribute value not of ASN.1 type 'OBJECT IDENTIFIER'");
      localObject2 = (DERObjectIdentifier)localObject1;
      if (!((DERObjectIdentifier)localObject2).equals(this.contentType))
        throw new CMSException("content-type attribute value does not match eContentType");
    }
    localObject1 = getSingleValuedSignedAttribute(CMSAttributes.messageDigest, "message-digest");
    if (localObject1 == null)
    {
      if (this.signedAttributeSet != null)
        throw new CMSException("the message-digest signed attribute type MUST be present when there are any signed attributes present");
    }
    else
    {
      if (!(localObject1 instanceof ASN1OctetString))
        throw new CMSException("message-digest attribute value not of ASN.1 type 'OCTET STRING'");
      localObject2 = (ASN1OctetString)localObject1;
      if (!Arrays.constantTimeAreEqual(this.resultDigest, ((ASN1OctetString)localObject2).getOctets()))
        throw new CMSSignerDigestMismatchException("message-digest attribute value does not match calculated value");
    }
    localObject1 = getSignedAttributes();
    if ((localObject1 != null) && (((AttributeTable)localObject1).getAll(CMSAttributes.counterSignature).size() > 0))
      throw new CMSException("A countersignature attribute MUST NOT be a signed attribute");
    Object localObject2 = getUnsignedAttributes();
    if (localObject2 != null)
    {
      ASN1EncodableVector localASN1EncodableVector = ((AttributeTable)localObject2).getAll(CMSAttributes.counterSignature);
      for (int i = 0; i < localASN1EncodableVector.size(); i++)
      {
        Attribute localAttribute = (Attribute)localASN1EncodableVector.get(i);
        if (localAttribute.getAttrValues().size() >= 1)
          continue;
        throw new CMSException("A countersignature attribute MUST contain at least one AttributeValue");
      }
    }
    try
    {
      localSignature.initVerify(paramPublicKey);
      if (this.signedAttributeSet == null)
      {
        if (this.digestCalculator != null)
          return verifyDigest(this.resultDigest, paramPublicKey, getSignature(), paramProvider);
        if (this.content != null)
          this.content.write(new SigOutputStream(localSignature));
      }
      else
      {
        localSignature.update(getEncodedSignedAttributes());
      }
      return localSignature.verify(getSignature());
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key not appropriate to signature in message.", localInvalidKeyException);
    }
    catch (IOException localIOException2)
    {
      throw new CMSException("can't process mime object to create signature.", localIOException2);
    }
    catch (SignatureException localSignatureException)
    {
    }
    throw new CMSException("invalid signature format in message: " + localSignatureException.getMessage(), localSignatureException);
  }

  private boolean doVerify(SignerInformationVerifier paramSignerInformationVerifier)
    throws CMSException
  {
    String str1 = CMSSignedHelper.INSTANCE.getDigestAlgName(getDigestAlgOID());
    String str2 = CMSSignedHelper.INSTANCE.getEncryptionAlgName(getEncryptionAlgOID());
    String str3 = str1 + "with" + str2;
    try
    {
      if (this.digestCalculator != null)
      {
        this.resultDigest = this.digestCalculator.getDigest();
      }
      else
      {
        DigestCalculator localDigestCalculator = paramSignerInformationVerifier.getDigestCalculator(getDigestAlgorithmID());
        if (this.content != null)
        {
          localObject2 = localDigestCalculator.getOutputStream();
          this.content.write((OutputStream)localObject2);
          ((OutputStream)localObject2).close();
        }
        else if (this.signedAttributeSet == null)
        {
          throw new CMSException("data not encapsulated in signature - use detached constructor.");
        }
        this.resultDigest = localDigestCalculator.getDigest();
      }
    }
    catch (IOException localIOException1)
    {
      throw new CMSException("can't process mime object to create signature.", localIOException1);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm: " + localNoSuchAlgorithmException.getMessage(), localNoSuchAlgorithmException);
    }
    catch (OperatorCreationException localOperatorCreationException1)
    {
      throw new CMSException("can't create digest calculator: " + localOperatorCreationException1.getMessage(), localOperatorCreationException1);
    }
    Object localObject1 = getSingleValuedSignedAttribute(CMSAttributes.contentType, "content-type");
    if (localObject1 == null)
    {
      if ((!this.isCounterSignature) && (this.signedAttributeSet != null))
        throw new CMSException("The content-type attribute type MUST be present whenever signed attributes are present in signed-data");
    }
    else
    {
      if (this.isCounterSignature)
        throw new CMSException("[For counter signatures,] the signedAttributes field MUST NOT contain a content-type attribute");
      if (!(localObject1 instanceof DERObjectIdentifier))
        throw new CMSException("content-type attribute value not of ASN.1 type 'OBJECT IDENTIFIER'");
      localObject2 = (DERObjectIdentifier)localObject1;
      if (!((DERObjectIdentifier)localObject2).equals(this.contentType))
        throw new CMSException("content-type attribute value does not match eContentType");
    }
    localObject1 = getSingleValuedSignedAttribute(CMSAttributes.messageDigest, "message-digest");
    if (localObject1 == null)
    {
      if (this.signedAttributeSet != null)
        throw new CMSException("the message-digest signed attribute type MUST be present when there are any signed attributes present");
    }
    else
    {
      if (!(localObject1 instanceof ASN1OctetString))
        throw new CMSException("message-digest attribute value not of ASN.1 type 'OCTET STRING'");
      localObject2 = (ASN1OctetString)localObject1;
      if (!Arrays.constantTimeAreEqual(this.resultDigest, ((ASN1OctetString)localObject2).getOctets()))
        throw new CMSSignerDigestMismatchException("message-digest attribute value does not match calculated value");
    }
    localObject1 = getSignedAttributes();
    if ((localObject1 != null) && (((AttributeTable)localObject1).getAll(CMSAttributes.counterSignature).size() > 0))
      throw new CMSException("A countersignature attribute MUST NOT be a signed attribute");
    Object localObject2 = getUnsignedAttributes();
    Object localObject3;
    if (localObject2 != null)
    {
      localObject3 = ((AttributeTable)localObject2).getAll(CMSAttributes.counterSignature);
      for (int i = 0; i < ((ASN1EncodableVector)localObject3).size(); i++)
      {
        Attribute localAttribute = (Attribute)((ASN1EncodableVector)localObject3).get(i);
        if (localAttribute.getAttrValues().size() >= 1)
          continue;
        throw new CMSException("A countersignature attribute MUST contain at least one AttributeValue");
      }
    }
    try
    {
      localObject1 = paramSignerInformationVerifier.getContentVerifier(this.sigAlgFinder.find(str3));
      localObject2 = ((ContentVerifier)localObject1).getOutputStream();
      if (this.signedAttributeSet == null)
      {
        if (this.digestCalculator != null)
        {
          if ((localObject1 instanceof RawContentVerifier))
          {
            localObject3 = (RawContentVerifier)localObject1;
            if (str2.equals("RSA"))
            {
              DigestInfo localDigestInfo = new DigestInfo(this.digestAlgorithm, this.resultDigest);
              return ((RawContentVerifier)localObject3).verify(localDigestInfo.getDEREncoded(), getSignature());
            }
            return ((RawContentVerifier)localObject3).verify(this.resultDigest, getSignature());
          }
          throw new CMSException("verifier unable to process raw signature");
        }
        if (this.content != null)
          this.content.write((OutputStream)localObject2);
      }
      else
      {
        ((OutputStream)localObject2).write(getEncodedSignedAttributes());
      }
      ((OutputStream)localObject2).close();
      return ((ContentVerifier)localObject1).verify(getSignature());
    }
    catch (IOException localIOException2)
    {
      throw new CMSException("can't process mime object to create signature.", localIOException2);
    }
    catch (OperatorCreationException localOperatorCreationException2)
    {
    }
    throw new CMSException("can't create content verifier: " + localOperatorCreationException2.getMessage(), localOperatorCreationException2);
  }

  private boolean isNull(DEREncodable paramDEREncodable)
  {
    return ((paramDEREncodable instanceof ASN1Null)) || (paramDEREncodable == null);
  }

  private DigestInfo derDecode(byte[] paramArrayOfByte)
    throws IOException, CMSException
  {
    if (paramArrayOfByte[0] != 48)
      throw new IOException("not a digest info object");
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramArrayOfByte);
    DigestInfo localDigestInfo = new DigestInfo((ASN1Sequence)localASN1InputStream.readObject());
    if (localDigestInfo.getEncoded().length != paramArrayOfByte.length)
      throw new CMSException("malformed RSA signature");
    return localDigestInfo;
  }

  /** @deprecated */
  private boolean verifyDigest(byte[] paramArrayOfByte1, PublicKey paramPublicKey, byte[] paramArrayOfByte2, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    String str = CMSSignedHelper.INSTANCE.getEncryptionAlgName(getEncryptionAlgOID());
    try
    {
      Object localObject;
      if (str.equals("RSA"))
      {
        localObject = CMSEnvelopedHelper.INSTANCE.createAsymmetricCipher("RSA/ECB/PKCS1Padding", paramProvider);
        ((Cipher)localObject).init(2, paramPublicKey);
        DigestInfo localDigestInfo = derDecode(((Cipher)localObject).doFinal(paramArrayOfByte2));
        if (!localDigestInfo.getAlgorithmId().getObjectId().equals(this.digestAlgorithm.getObjectId()))
          return false;
        if (!isNull(localDigestInfo.getAlgorithmId().getParameters()))
          return false;
        byte[] arrayOfByte = localDigestInfo.getDigest();
        return Arrays.constantTimeAreEqual(paramArrayOfByte1, arrayOfByte);
      }
      if (str.equals("DSA"))
      {
        localObject = CMSSignedHelper.INSTANCE.getSignatureInstance("NONEwithDSA", paramProvider);
        ((Signature)localObject).initVerify(paramPublicKey);
        ((Signature)localObject).update(paramArrayOfByte1);
        return ((Signature)localObject).verify(paramArrayOfByte2);
      }
      throw new CMSException("algorithm: " + str + " not supported in base signatures.");
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
      throw new CMSException("Exception processing signature: " + localGeneralSecurityException, localGeneralSecurityException);
    }
    catch (IOException localIOException)
    {
    }
    throw new CMSException("Exception decoding signature: " + localIOException, localIOException);
  }

  /** @deprecated */
  public boolean verify(PublicKey paramPublicKey, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return verify(paramPublicKey, CMSUtils.getProvider(paramString));
  }

  /** @deprecated */
  public boolean verify(PublicKey paramPublicKey, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    getSigningTime();
    return doVerify(paramPublicKey, paramProvider);
  }

  /** @deprecated */
  public boolean verify(X509Certificate paramX509Certificate, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, CertificateExpiredException, CertificateNotYetValidException, CMSException
  {
    return verify(paramX509Certificate, CMSUtils.getProvider(paramString));
  }

  /** @deprecated */
  public boolean verify(X509Certificate paramX509Certificate, Provider paramProvider)
    throws NoSuchAlgorithmException, CertificateExpiredException, CertificateNotYetValidException, CMSException
  {
    Time localTime = getSigningTime();
    if (localTime != null)
      paramX509Certificate.checkValidity(localTime.getDate());
    return doVerify(paramX509Certificate.getPublicKey(), paramProvider);
  }

  public boolean verify(SignerInformationVerifier paramSignerInformationVerifier)
    throws CMSException
  {
    Time localTime = getSigningTime();
    if ((paramSignerInformationVerifier.hasAssociatedCertificate()) && (localTime != null))
    {
      X509CertificateHolder localX509CertificateHolder = paramSignerInformationVerifier.getAssociatedCertificate();
      if (!localX509CertificateHolder.isValidOn(localTime.getDate()))
        throw new CMSVerifierCertificateNotValidException("verifier not valid at signingTime");
    }
    return doVerify(paramSignerInformationVerifier);
  }

  /** @deprecated */
  public SignerInfo toSignerInfo()
  {
    return this.info;
  }

  public SignerInfo toASN1Structure()
  {
    return this.info;
  }

  private DERObject getSingleValuedSignedAttribute(DERObjectIdentifier paramDERObjectIdentifier, String paramString)
    throws CMSException
  {
    AttributeTable localAttributeTable1 = getUnsignedAttributes();
    if ((localAttributeTable1 != null) && (localAttributeTable1.getAll(paramDERObjectIdentifier).size() > 0))
      throw new CMSException("The " + paramString + " attribute MUST NOT be an unsigned attribute");
    AttributeTable localAttributeTable2 = getSignedAttributes();
    if (localAttributeTable2 == null)
      return null;
    ASN1EncodableVector localASN1EncodableVector = localAttributeTable2.getAll(paramDERObjectIdentifier);
    switch (localASN1EncodableVector.size())
    {
    case 0:
      return null;
    case 1:
      Attribute localAttribute = (Attribute)localASN1EncodableVector.get(0);
      ASN1Set localASN1Set = localAttribute.getAttrValues();
      if (localASN1Set.size() != 1)
        throw new CMSException("A " + paramString + " attribute MUST have a single attribute value");
      return localASN1Set.getObjectAt(0).getDERObject();
    }
    throw new CMSException("The SignedAttributes in a signerInfo MUST NOT include multiple instances of the " + paramString + " attribute");
  }

  private Time getSigningTime()
    throws CMSException
  {
    DERObject localDERObject = getSingleValuedSignedAttribute(CMSAttributes.signingTime, "signing-time");
    if (localDERObject == null)
      return null;
    try
    {
      return Time.getInstance(localDERObject);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    throw new CMSException("signing-time attribute value not a valid 'Time' structure");
  }

  public static SignerInformation replaceUnsignedAttributes(SignerInformation paramSignerInformation, AttributeTable paramAttributeTable)
  {
    SignerInfo localSignerInfo = paramSignerInformation.info;
    DERSet localDERSet = null;
    if (paramAttributeTable != null)
      localDERSet = new DERSet(paramAttributeTable.toASN1EncodableVector());
    return new SignerInformation(new SignerInfo(localSignerInfo.getSID(), localSignerInfo.getDigestAlgorithm(), localSignerInfo.getAuthenticatedAttributes(), localSignerInfo.getDigestEncryptionAlgorithm(), localSignerInfo.getEncryptedDigest(), localDERSet), paramSignerInformation.contentType, paramSignerInformation.content, null, new DefaultSignatureAlgorithmIdentifierFinder());
  }

  public static SignerInformation addCounterSigners(SignerInformation paramSignerInformation, SignerInformationStore paramSignerInformationStore)
  {
    SignerInfo localSignerInfo = paramSignerInformation.info;
    AttributeTable localAttributeTable = paramSignerInformation.getUnsignedAttributes();
    ASN1EncodableVector localASN1EncodableVector1;
    if (localAttributeTable != null)
      localASN1EncodableVector1 = localAttributeTable.toASN1EncodableVector();
    else
      localASN1EncodableVector1 = new ASN1EncodableVector();
    ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
    Iterator localIterator = paramSignerInformationStore.getSigners().iterator();
    while (localIterator.hasNext())
      localASN1EncodableVector2.add(((SignerInformation)localIterator.next()).toSignerInfo());
    localASN1EncodableVector1.add(new Attribute(CMSAttributes.counterSignature, new DERSet(localASN1EncodableVector2)));
    return new SignerInformation(new SignerInfo(localSignerInfo.getSID(), localSignerInfo.getDigestAlgorithm(), localSignerInfo.getAuthenticatedAttributes(), localSignerInfo.getDigestEncryptionAlgorithm(), localSignerInfo.getEncryptedDigest(), new DERSet(localASN1EncodableVector1)), paramSignerInformation.contentType, paramSignerInformation.content, null, new DefaultSignatureAlgorithmIdentifierFinder());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.SignerInformation
 * JD-Core Version:    0.6.0
 */