package org.bouncycastle.cms;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SignerInformationStore
{
  private ArrayList all = new ArrayList();
  private Map table = new HashMap();

  public SignerInformationStore(Collection paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator.next();
      SignerId localSignerId = localSignerInformation.getSID();
      if (this.table.get(localSignerId) == null)
      {
        this.table.put(localSignerId, localSignerInformation);
      }
      else
      {
        Object localObject = this.table.get(localSignerId);
        if ((localObject instanceof List))
        {
          ((List)localObject).add(localSignerInformation);
        }
        else
        {
          ArrayList localArrayList = new ArrayList();
          localArrayList.add(localObject);
          localArrayList.add(localSignerInformation);
          this.table.put(localSignerId, localArrayList);
        }
      }
      this.all = new ArrayList(paramCollection);
    }
  }

  public SignerInformation get(SignerId paramSignerId)
  {
    Object localObject = this.table.get(paramSignerId);
    if ((localObject instanceof List))
      return (SignerInformation)((List)localObject).get(0);
    return (SignerInformation)localObject;
  }

  public int size()
  {
    return this.all.size();
  }

  public Collection getSigners()
  {
    return new ArrayList(this.all);
  }

  public Collection getSigners(SignerId paramSignerId)
  {
    Object localObject = this.table.get(paramSignerId);
    if ((localObject instanceof List))
      return new ArrayList((List)localObject);
    if (localObject != null)
      return Collections.singletonList(localObject);
    return new ArrayList();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.SignerInformationStore
 * JD-Core Version:    0.6.0
 */