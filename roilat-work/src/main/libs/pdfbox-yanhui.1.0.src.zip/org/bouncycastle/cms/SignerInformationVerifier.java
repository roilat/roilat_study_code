package org.bouncycastle.cms;

import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;

public class SignerInformationVerifier
{
  private ContentVerifierProvider verifierProvider;
  private DigestCalculatorProvider digestProvider;

  public SignerInformationVerifier(ContentVerifierProvider paramContentVerifierProvider, DigestCalculatorProvider paramDigestCalculatorProvider)
  {
    this.verifierProvider = paramContentVerifierProvider;
    this.digestProvider = paramDigestCalculatorProvider;
  }

  public boolean hasAssociatedCertificate()
  {
    return this.verifierProvider.hasAssociatedCertificate();
  }

  public X509CertificateHolder getAssociatedCertificate()
  {
    return this.verifierProvider.getAssociatedCertificate();
  }

  public ContentVerifier getContentVerifier(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws OperatorCreationException
  {
    return this.verifierProvider.get(paramAlgorithmIdentifier);
  }

  public DigestCalculator getDigestCalculator(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws OperatorCreationException
  {
    return this.digestProvider.get(paramAlgorithmIdentifier);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.SignerInformationVerifier
 * JD-Core Version:    0.6.0
 */