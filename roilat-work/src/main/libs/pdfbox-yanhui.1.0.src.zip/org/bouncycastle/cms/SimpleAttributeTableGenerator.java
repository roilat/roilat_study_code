package org.bouncycastle.cms;

import java.util.Map;
import org.bouncycastle.asn1.cms.AttributeTable;

public class SimpleAttributeTableGenerator
  implements CMSAttributeTableGenerator
{
  private final AttributeTable attributes;

  public SimpleAttributeTableGenerator(AttributeTable paramAttributeTable)
  {
    this.attributes = paramAttributeTable;
  }

  public AttributeTable getAttributes(Map paramMap)
  {
    return this.attributes;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.SimpleAttributeTableGenerator
 * JD-Core Version:    0.6.0
 */