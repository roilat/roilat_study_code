package org.bouncycastle.cms.bc;

import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cms.KeyTransRecipientInfoGenerator;
import org.bouncycastle.operator.bc.BcAsymmetricKeyWrapper;

public abstract class BcKeyTransRecipientInfoGenerator extends KeyTransRecipientInfoGenerator
{
  public BcKeyTransRecipientInfoGenerator(X509CertificateHolder paramX509CertificateHolder, BcAsymmetricKeyWrapper paramBcAsymmetricKeyWrapper)
  {
    super(paramX509CertificateHolder.getIssuerAndSerialNumber(), paramBcAsymmetricKeyWrapper);
  }

  public BcKeyTransRecipientInfoGenerator(byte[] paramArrayOfByte, BcAsymmetricKeyWrapper paramBcAsymmetricKeyWrapper)
  {
    super(paramArrayOfByte, paramBcAsymmetricKeyWrapper);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.bc.BcKeyTransRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */