package org.bouncycastle.cms.bc;

import java.security.cert.CertificateException;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cms.SignerInformationVerifier;
import org.bouncycastle.crypto.params.AsymmetricKeyParameter;
import org.bouncycastle.operator.DigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.bc.BcRSAContentVerifierProviderBuilder;

public class BcRSASignerInfoVerifierBuilder
{
  private BcRSAContentVerifierProviderBuilder contentVerifierProviderBuilder;
  private DigestCalculatorProvider digestCalculatorProvider;

  public BcRSASignerInfoVerifierBuilder(DigestAlgorithmIdentifierFinder paramDigestAlgorithmIdentifierFinder, DigestCalculatorProvider paramDigestCalculatorProvider)
  {
    this.contentVerifierProviderBuilder = new BcRSAContentVerifierProviderBuilder(paramDigestAlgorithmIdentifierFinder);
    this.digestCalculatorProvider = paramDigestCalculatorProvider;
  }

  public SignerInformationVerifier build(X509CertificateHolder paramX509CertificateHolder)
    throws OperatorCreationException, CertificateException
  {
    return new SignerInformationVerifier(this.contentVerifierProviderBuilder.build(paramX509CertificateHolder), this.digestCalculatorProvider);
  }

  public SignerInformationVerifier build(AsymmetricKeyParameter paramAsymmetricKeyParameter)
    throws OperatorCreationException
  {
    return new SignerInformationVerifier(this.contentVerifierProviderBuilder.build(paramAsymmetricKeyParameter), this.digestCalculatorProvider);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.bc.BcRSASignerInfoVerifierBuilder
 * JD-Core Version:    0.6.0
 */