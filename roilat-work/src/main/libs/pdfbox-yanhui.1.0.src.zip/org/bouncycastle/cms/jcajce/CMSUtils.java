package org.bouncycastle.cms.jcajce;

import java.security.Key;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.operator.GenericKey;

class CMSUtils
{
  static TBSCertificateStructure getTBSCertificateStructure(X509Certificate paramX509Certificate)
    throws CertificateEncodingException
  {
    return TBSCertificateStructure.getInstance(paramX509Certificate.getTBSCertificate());
  }

  static Key getJceKey(GenericKey paramGenericKey)
  {
    if ((paramGenericKey.getRepresentation() instanceof Key))
      return (Key)paramGenericKey.getRepresentation();
    if ((paramGenericKey.getRepresentation() instanceof byte[]))
      return new SecretKeySpec((byte[])(byte[])paramGenericKey.getRepresentation(), "ENC");
    throw new IllegalArgumentException("unknown generic key type");
  }

  static IssuerAndSerialNumber getIssuerAndSerialNumber(X509Certificate paramX509Certificate)
    throws CertificateEncodingException
  {
    X509CertificateStructure localX509CertificateStructure = X509CertificateStructure.getInstance(paramX509Certificate.getEncoded());
    return new IssuerAndSerialNumber(localX509CertificateStructure.getIssuer(), localX509CertificateStructure.getSerialNumber());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.CMSUtils
 * JD-Core Version:    0.6.0
 */