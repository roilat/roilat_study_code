package org.bouncycastle.cms.jcajce;

import java.io.IOException;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidParameterSpecException;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.RC2ParameterSpec;
import org.bouncycastle.asn1.ASN1Null;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.RC2CBCParameter;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cms.CMSAlgorithm;
import org.bouncycastle.cms.CMSEnvelopedDataGenerator;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.jcajce.JcaJceHelper;
import org.bouncycastle.operator.AsymmetricKeyUnwrapper;
import org.bouncycastle.operator.SymmetricKeyUnwrapper;

class EnvelopedDataHelper
{
  protected static final Map BASE_CIPHER_NAMES = new HashMap();
  protected static final Map CIPHER_ALG_NAMES = new HashMap();
  protected static final Map MAC_ALG_NAMES = new HashMap();
  private static final short[] rc2Table;
  private static final short[] rc2Ekb;
  private JcaJceHelper helper;

  EnvelopedDataHelper(JcaJceHelper paramJcaJceHelper)
  {
    this.helper = paramJcaJceHelper;
  }

  String getBaseCipherName(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
    if (str == null)
      return paramASN1ObjectIdentifier.getId();
    return str;
  }

  Cipher createCipher(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CMSException
  {
    try
    {
      String str = (String)CIPHER_ALG_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createCipher(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createCipher(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("cannot create cipher: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  Mac createMac(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CMSException
  {
    try
    {
      String str = (String)MAC_ALG_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createMac(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createMac(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("cannot create mac: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  Cipher createRFC3211Wrapper(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CMSException
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
    if (str == null)
      throw new CMSException("no name for " + paramASN1ObjectIdentifier);
    str = str + "RFC3211Wrap";
    try
    {
      return this.helper.createCipher(str);
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("cannot create cipher: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  KeyAgreement createKeyAgreement(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CMSException
  {
    try
    {
      String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createKeyAgreement(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createKeyAgreement(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("cannot create key pair generator: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  AlgorithmParameterGenerator createAlgorithmParameterGenerator(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws GeneralSecurityException
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
    if (str != null)
      try
      {
        return this.helper.createAlgorithmParameterGenerator(str);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
      }
    return this.helper.createAlgorithmParameterGenerator(paramASN1ObjectIdentifier.getId());
  }

  Cipher createContentCipher(Key paramKey, AlgorithmIdentifier paramAlgorithmIdentifier)
    throws CMSException
  {
    return (Cipher)execute(new JCECallback(paramAlgorithmIdentifier, paramKey)
    {
      public Object doInJCE()
        throws CMSException, InvalidAlgorithmParameterException, InvalidKeyException, InvalidParameterSpecException, NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException
      {
        Cipher localCipher = EnvelopedDataHelper.this.createCipher(this.val$encryptionAlgID.getAlgorithm());
        ASN1Object localASN1Object = (ASN1Object)this.val$encryptionAlgID.getParameters().getDERObject();
        String str = this.val$encryptionAlgID.getAlgorithm().getId();
        if ((localASN1Object != null) && (!(localASN1Object instanceof ASN1Null)))
          try
          {
            AlgorithmParameters localAlgorithmParameters = EnvelopedDataHelper.this.createAlgorithmParameters(this.val$encryptionAlgID.getAlgorithm());
            try
            {
              localAlgorithmParameters.init(localASN1Object.getEncoded(), "ASN.1");
            }
            catch (IOException localIOException)
            {
              throw new CMSException("error decoding algorithm parameters.", localIOException);
            }
            localCipher.init(2, this.val$sKey, localAlgorithmParameters);
          }
          catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
          {
            if ((str.equals(CMSEnvelopedDataGenerator.DES_EDE3_CBC)) || (str.equals("1.3.6.1.4.1.188.7.1.1.2")) || (str.equals(CMSEnvelopedDataGenerator.AES128_CBC)) || (str.equals(CMSEnvelopedDataGenerator.AES192_CBC)) || (str.equals(CMSEnvelopedDataGenerator.AES256_CBC)))
              localCipher.init(2, this.val$sKey, new IvParameterSpec(ASN1OctetString.getInstance(localASN1Object).getOctets()));
            else
              throw localNoSuchAlgorithmException;
          }
        else if ((str.equals(CMSEnvelopedDataGenerator.DES_EDE3_CBC)) || (str.equals("1.3.6.1.4.1.188.7.1.1.2")) || (str.equals("1.2.840.113533.7.66.10")))
          localCipher.init(2, this.val$sKey, new IvParameterSpec(new byte[8]));
        else
          localCipher.init(2, this.val$sKey);
        return localCipher;
      }
    });
  }

  Mac createContentMac(Key paramKey, AlgorithmIdentifier paramAlgorithmIdentifier)
    throws CMSException
  {
    return (Mac)execute(new JCECallback(paramAlgorithmIdentifier, paramKey)
    {
      public Object doInJCE()
        throws CMSException, InvalidAlgorithmParameterException, InvalidKeyException, InvalidParameterSpecException, NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException
      {
        Mac localMac = EnvelopedDataHelper.this.createMac(this.val$macAlgId.getAlgorithm());
        ASN1Object localASN1Object = (ASN1Object)this.val$macAlgId.getParameters().getDERObject();
        String str = this.val$macAlgId.getAlgorithm().getId();
        if ((localASN1Object != null) && (!(localASN1Object instanceof ASN1Null)))
          try
          {
            AlgorithmParameters localAlgorithmParameters = EnvelopedDataHelper.this.createAlgorithmParameters(this.val$macAlgId.getAlgorithm());
            try
            {
              localAlgorithmParameters.init(localASN1Object.getEncoded(), "ASN.1");
            }
            catch (IOException localIOException)
            {
              throw new CMSException("error decoding algorithm parameters.", localIOException);
            }
            localMac.init(this.val$sKey, localAlgorithmParameters.getParameterSpec(IvParameterSpec.class));
          }
          catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
          {
            throw localNoSuchAlgorithmException;
          }
        else
          localMac.init(this.val$sKey);
        return localMac;
      }
    });
  }

  AlgorithmParameters createAlgorithmParameters(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws NoSuchAlgorithmException, NoSuchProviderException
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
    if (str != null)
      try
      {
        return this.helper.createAlgorithmParameters(str);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
      }
    return this.helper.createAlgorithmParameters(paramASN1ObjectIdentifier.getId());
  }

  KeyPairGenerator createKeyPairGenerator(DERObjectIdentifier paramDERObjectIdentifier)
    throws CMSException
  {
    try
    {
      String str = (String)BASE_CIPHER_NAMES.get(paramDERObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createKeyPairGenerator(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createKeyPairGenerator(paramDERObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("cannot create key pair generator: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  public KeyGenerator createKeyGenerator(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CMSException
  {
    try
    {
      String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createKeyGenerator(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createKeyGenerator(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("cannot create key generator: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  AlgorithmParameters generateParameters(ASN1ObjectIdentifier paramASN1ObjectIdentifier, SecretKey paramSecretKey, SecureRandom paramSecureRandom)
    throws CMSException
  {
    try
    {
      AlgorithmParameterGenerator localAlgorithmParameterGenerator = createAlgorithmParameterGenerator(paramASN1ObjectIdentifier);
      if (paramASN1ObjectIdentifier.equals(CMSEnvelopedDataGenerator.RC2_CBC))
      {
        byte[] arrayOfByte = new byte[8];
        paramSecureRandom.nextBytes(arrayOfByte);
        try
        {
          localAlgorithmParameterGenerator.init(new RC2ParameterSpec(paramSecretKey.getEncoded().length * 8, arrayOfByte), paramSecureRandom);
        }
        catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
        {
          throw new CMSException("parameters generation error: " + localInvalidAlgorithmParameterException, localInvalidAlgorithmParameterException);
        }
      }
      return localAlgorithmParameterGenerator.generateParameters();
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      return null;
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("exception creating algorithm parameter generator: " + localGeneralSecurityException, localGeneralSecurityException);
  }

  AlgorithmIdentifier getAlgorithmIdentifier(ASN1ObjectIdentifier paramASN1ObjectIdentifier, AlgorithmParameters paramAlgorithmParameters)
    throws CMSException
  {
    Object localObject;
    if (paramAlgorithmParameters != null)
      try
      {
        localObject = ASN1Object.fromByteArray(paramAlgorithmParameters.getEncoded("ASN.1"));
      }
      catch (IOException localIOException)
      {
        throw new CMSException("cannot encode parameters: " + localIOException.getMessage(), localIOException);
      }
    else
      localObject = DERNull.INSTANCE;
    return (AlgorithmIdentifier)new AlgorithmIdentifier(paramASN1ObjectIdentifier, (DEREncodable)localObject);
  }

  static Object execute(JCECallback paramJCECallback)
    throws CMSException
  {
    try
    {
      return paramJCECallback.doInJCE();
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
      throw new CMSException("can't find provider.", localNoSuchProviderException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameters invalid.", localInvalidAlgorithmParameterException);
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException)
    {
    }
    throw new CMSException("MAC algorithm parameter spec invalid.", localInvalidParameterSpecException);
  }

  public KeyFactory createKeyFactory(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CMSException
  {
    try
    {
      String str = (String)BASE_CIPHER_NAMES.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createKeyFactory(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createKeyFactory(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("cannot create key factory: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  public AsymmetricKeyUnwrapper createAsymmetricUnwrapper(AlgorithmIdentifier paramAlgorithmIdentifier, PrivateKey paramPrivateKey)
  {
    return this.helper.createAsymmetricUnwrapper(paramAlgorithmIdentifier, paramPrivateKey);
  }

  public SymmetricKeyUnwrapper createSymmetricUnwrapper(AlgorithmIdentifier paramAlgorithmIdentifier, SecretKey paramSecretKey)
  {
    return this.helper.createSymmetricUnwrapper(paramAlgorithmIdentifier, paramSecretKey);
  }

  public AlgorithmIdentifier getAlgorithmIdentifier(ASN1ObjectIdentifier paramASN1ObjectIdentifier, AlgorithmParameterSpec paramAlgorithmParameterSpec)
  {
    if ((paramAlgorithmParameterSpec instanceof IvParameterSpec))
      return new AlgorithmIdentifier(paramASN1ObjectIdentifier, new DEROctetString(((IvParameterSpec)paramAlgorithmParameterSpec).getIV()));
    if ((paramAlgorithmParameterSpec instanceof RC2ParameterSpec))
    {
      RC2ParameterSpec localRC2ParameterSpec = (RC2ParameterSpec)paramAlgorithmParameterSpec;
      int i = ((RC2ParameterSpec)paramAlgorithmParameterSpec).getEffectiveKeyBits();
      if (i != -1)
      {
        int j;
        if (i < 256)
          j = rc2Table[i];
        else
          j = i;
        return new AlgorithmIdentifier(paramASN1ObjectIdentifier, new RC2CBCParameter(j, localRC2ParameterSpec.getIV()));
      }
      return new AlgorithmIdentifier(paramASN1ObjectIdentifier, new RC2CBCParameter(localRC2ParameterSpec.getIV()));
    }
    throw new IllegalStateException("unknown parameter spec");
  }

  static
  {
    BASE_CIPHER_NAMES.put(CMSAlgorithm.DES_EDE3_CBC, "DESEDE");
    BASE_CIPHER_NAMES.put(CMSAlgorithm.AES128_CBC, "AES");
    BASE_CIPHER_NAMES.put(CMSAlgorithm.AES192_CBC, "AES");
    BASE_CIPHER_NAMES.put(CMSAlgorithm.AES256_CBC, "AES");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.DES_EDE3_CBC, "DESEDE/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.AES128_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.AES192_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.AES256_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(new ASN1ObjectIdentifier(PKCSObjectIdentifiers.rsaEncryption.getId()), "RSA/ECB/PKCS1Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.CAST5_CBC, "CAST5/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.CAMELLIA128_CBC, "Camellia/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.CAMELLIA192_CBC, "Camellia/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.CAMELLIA256_CBC, "Camellia/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSAlgorithm.SEED_CBC, "SEED/CBC/PKCS5Padding");
    MAC_ALG_NAMES.put(CMSAlgorithm.DES_EDE3_CBC, "DESEDEMac");
    MAC_ALG_NAMES.put(CMSAlgorithm.AES128_CBC, "AESMac");
    MAC_ALG_NAMES.put(CMSAlgorithm.AES192_CBC, "AESMac");
    MAC_ALG_NAMES.put(CMSAlgorithm.AES256_CBC, "AESMac");
    MAC_ALG_NAMES.put(CMSAlgorithm.RC2_CBC, "RC2Mac");
    rc2Table = new short[] { 189, 86, 234, 242, 162, 241, 172, 42, 176, 147, 209, 156, 27, 51, 253, 208, 48, 4, 182, 220, 125, 223, 50, 75, 247, 203, 69, 155, 49, 187, 33, 90, 65, 159, 225, 217, 74, 77, 158, 218, 160, 104, 44, 195, 39, 95, 128, 54, 62, 238, 251, 149, 26, 254, 206, 168, 52, 169, 19, 240, 166, 63, 216, 12, 120, 36, 175, 35, 82, 193, 103, 23, 245, 102, 144, 231, 232, 7, 184, 96, 72, 230, 30, 83, 243, 146, 164, 114, 140, 8, 21, 110, 134, 0, 132, 250, 244, 127, 138, 66, 25, 246, 219, 205, 20, 141, 80, 18, 186, 60, 6, 78, 236, 179, 53, 17, 161, 136, 142, 43, 148, 153, 183, 113, 116, 211, 228, 191, 58, 222, 150, 14, 188, 10, 237, 119, 252, 55, 107, 3, 121, 137, 98, 198, 215, 192, 210, 124, 106, 139, 34, 163, 91, 5, 93, 2, 117, 213, 97, 227, 24, 143, 85, 81, 173, 31, 11, 94, 133, 229, 194, 87, 99, 202, 61, 108, 180, 197, 204, 112, 178, 145, 89, 13, 71, 32, 200, 79, 88, 224, 1, 226, 22, 56, 196, 111, 59, 15, 101, 70, 190, 126, 45, 123, 130, 249, 64, 181, 29, 115, 248, 235, 38, 199, 135, 151, 37, 84, 177, 40, 170, 152, 157, 165, 100, 109, 122, 212, 16, 129, 68, 239, 73, 214, 174, 46, 221, 118, 92, 47, 167, 28, 201, 9, 105, 154, 131, 207, 41, 57, 185, 233, 76, 255, 67, 171 };
    rc2Ekb = new short[] { 93, 190, 155, 139, 17, 153, 110, 77, 89, 243, 133, 166, 63, 183, 131, 197, 228, 115, 107, 58, 104, 90, 192, 71, 160, 100, 52, 12, 241, 208, 82, 165, 185, 30, 150, 67, 65, 216, 212, 44, 219, 248, 7, 119, 42, 202, 235, 239, 16, 28, 22, 13, 56, 114, 47, 137, 193, 249, 128, 196, 109, 174, 48, 61, 206, 32, 99, 254, 230, 26, 199, 184, 80, 232, 36, 23, 252, 37, 111, 187, 106, 163, 68, 83, 217, 162, 1, 171, 188, 182, 31, 152, 238, 154, 167, 45, 79, 158, 142, 172, 224, 198, 73, 70, 41, 244, 148, 138, 175, 225, 91, 195, 179, 123, 87, 209, 124, 156, 237, 135, 64, 140, 226, 203, 147, 20, 201, 97, 46, 229, 204, 246, 94, 168, 92, 214, 117, 141, 98, 149, 88, 105, 118, 161, 74, 181, 85, 9, 120, 51, 130, 215, 221, 121, 245, 27, 11, 222, 38, 33, 40, 116, 4, 151, 86, 223, 60, 240, 55, 57, 220, 255, 6, 164, 234, 66, 8, 218, 180, 113, 176, 207, 18, 122, 78, 250, 108, 29, 132, 0, 200, 127, 145, 69, 170, 43, 194, 177, 143, 213, 186, 242, 173, 25, 178, 103, 54, 247, 15, 10, 146, 125, 227, 157, 233, 144, 62, 35, 39, 102, 19, 236, 129, 21, 189, 34, 191, 159, 126, 169, 81, 75, 76, 251, 2, 211, 112, 134, 49, 231, 59, 5, 3, 84, 96, 72, 101, 24, 210, 205, 95, 50, 136, 14, 53, 253 };
  }

  static abstract interface JCECallback
  {
    public abstract Object doInJCE()
      throws CMSException, InvalidAlgorithmParameterException, InvalidKeyException, InvalidParameterSpecException, NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.EnvelopedDataHelper
 * JD-Core Version:    0.6.0
 */