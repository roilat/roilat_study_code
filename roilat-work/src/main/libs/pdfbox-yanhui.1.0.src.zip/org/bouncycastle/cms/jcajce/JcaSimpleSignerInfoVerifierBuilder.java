package org.bouncycastle.cms.jcajce;

import java.security.Provider;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cms.SignerInformationVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentVerifierProviderBuilder;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;

public class JcaSimpleSignerInfoVerifierBuilder
{
  private Helper helper = new Helper(null);

  public JcaSimpleSignerInfoVerifierBuilder setProvider(Provider paramProvider)
  {
    this.helper = new ProviderHelper(paramProvider);
    return this;
  }

  public JcaSimpleSignerInfoVerifierBuilder setProvider(String paramString)
  {
    this.helper = new NamedHelper(paramString);
    return this;
  }

  public SignerInformationVerifier build(X509CertificateHolder paramX509CertificateHolder)
    throws OperatorCreationException, CertificateException
  {
    return new SignerInformationVerifier(this.helper.createContentVerifierProvider(paramX509CertificateHolder), this.helper.createDigestCalculatorProvider());
  }

  public SignerInformationVerifier build(X509Certificate paramX509Certificate)
    throws OperatorCreationException
  {
    return new SignerInformationVerifier(this.helper.createContentVerifierProvider(paramX509Certificate), this.helper.createDigestCalculatorProvider());
  }

  public SignerInformationVerifier build(PublicKey paramPublicKey)
    throws OperatorCreationException
  {
    return new SignerInformationVerifier(this.helper.createContentVerifierProvider(paramPublicKey), this.helper.createDigestCalculatorProvider());
  }

  private class Helper
  {
    private Helper()
    {
    }

    ContentVerifierProvider createContentVerifierProvider(PublicKey paramPublicKey)
      throws OperatorCreationException
    {
      return new JcaContentVerifierProviderBuilder().build(paramPublicKey);
    }

    ContentVerifierProvider createContentVerifierProvider(X509Certificate paramX509Certificate)
      throws OperatorCreationException
    {
      return new JcaContentVerifierProviderBuilder().build(paramX509Certificate);
    }

    ContentVerifierProvider createContentVerifierProvider(X509CertificateHolder paramX509CertificateHolder)
      throws OperatorCreationException, CertificateException
    {
      return new JcaContentVerifierProviderBuilder().build(paramX509CertificateHolder);
    }

    DigestCalculatorProvider createDigestCalculatorProvider()
      throws OperatorCreationException
    {
      return new JcaDigestCalculatorProviderBuilder().build();
    }
  }

  private class NamedHelper extends JcaSimpleSignerInfoVerifierBuilder.Helper
  {
    private final String providerName;

    public NamedHelper(String arg2)
    {
      super(null);
      Object localObject;
      this.providerName = localObject;
    }

    ContentVerifierProvider createContentVerifierProvider(PublicKey paramPublicKey)
      throws OperatorCreationException
    {
      return new JcaContentVerifierProviderBuilder().setProvider(this.providerName).build(paramPublicKey);
    }

    ContentVerifierProvider createContentVerifierProvider(X509Certificate paramX509Certificate)
      throws OperatorCreationException
    {
      return new JcaContentVerifierProviderBuilder().setProvider(this.providerName).build(paramX509Certificate);
    }

    DigestCalculatorProvider createDigestCalculatorProvider()
      throws OperatorCreationException
    {
      return new JcaDigestCalculatorProviderBuilder().setProvider(this.providerName).build();
    }

    ContentVerifierProvider createContentVerifierProvider(X509CertificateHolder paramX509CertificateHolder)
      throws OperatorCreationException, CertificateException
    {
      return new JcaContentVerifierProviderBuilder().setProvider(this.providerName).build(paramX509CertificateHolder);
    }
  }

  private class ProviderHelper extends JcaSimpleSignerInfoVerifierBuilder.Helper
  {
    private final Provider provider;

    public ProviderHelper(Provider arg2)
    {
      super(null);
      Object localObject;
      this.provider = localObject;
    }

    ContentVerifierProvider createContentVerifierProvider(PublicKey paramPublicKey)
      throws OperatorCreationException
    {
      return new JcaContentVerifierProviderBuilder().setProvider(this.provider).build(paramPublicKey);
    }

    ContentVerifierProvider createContentVerifierProvider(X509Certificate paramX509Certificate)
      throws OperatorCreationException
    {
      return new JcaContentVerifierProviderBuilder().setProvider(this.provider).build(paramX509Certificate);
    }

    DigestCalculatorProvider createDigestCalculatorProvider()
      throws OperatorCreationException
    {
      return new JcaDigestCalculatorProviderBuilder().setProvider(this.provider).build();
    }

    ContentVerifierProvider createContentVerifierProvider(X509CertificateHolder paramX509CertificateHolder)
      throws OperatorCreationException, CertificateException
    {
      return new JcaContentVerifierProviderBuilder().setProvider(this.provider).build(paramX509CertificateHolder);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder
 * JD-Core Version:    0.6.0
 */