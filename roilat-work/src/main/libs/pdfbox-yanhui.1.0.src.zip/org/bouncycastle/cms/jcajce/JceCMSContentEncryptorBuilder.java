package org.bouncycastle.cms.jcajce;

import java.io.OutputStream;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.OutputEncryptor;

public class JceCMSContentEncryptorBuilder
{
  private final ASN1ObjectIdentifier encryptionOID;
  private final int keySize;
  private EnvelopedDataHelper helper = new EnvelopedDataHelper(new DefaultJcaJceHelper());
  private SecureRandom random;

  public JceCMSContentEncryptorBuilder(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    this(paramASN1ObjectIdentifier, -1);
  }

  public JceCMSContentEncryptorBuilder(ASN1ObjectIdentifier paramASN1ObjectIdentifier, int paramInt)
  {
    this.encryptionOID = paramASN1ObjectIdentifier;
    this.keySize = paramInt;
  }

  public JceCMSContentEncryptorBuilder setProvider(Provider paramProvider)
  {
    this.helper = new EnvelopedDataHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceCMSContentEncryptorBuilder setProvider(String paramString)
  {
    this.helper = new EnvelopedDataHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public JceCMSContentEncryptorBuilder setSecureRandom(SecureRandom paramSecureRandom)
  {
    this.random = paramSecureRandom;
    return this;
  }

  public OutputEncryptor build()
    throws CMSException
  {
    return new CMSOutputEncryptor(this.encryptionOID, this.keySize, this.random);
  }

  private class CMSOutputEncryptor
    implements OutputEncryptor
  {
    private SecretKey encKey;
    private AlgorithmIdentifier algorithmIdentifier;
    private Cipher cipher;

    CMSOutputEncryptor(ASN1ObjectIdentifier paramInt, int paramSecureRandom, SecureRandom arg4)
      throws CMSException
    {
      KeyGenerator localKeyGenerator = JceCMSContentEncryptorBuilder.this.helper.createKeyGenerator(paramInt);
      SecureRandom localSecureRandom;
      if (localSecureRandom == null)
        localSecureRandom = new SecureRandom();
      if (paramSecureRandom < 0)
        localKeyGenerator.init(localSecureRandom);
      else
        localKeyGenerator.init(paramSecureRandom, localSecureRandom);
      this.cipher = JceCMSContentEncryptorBuilder.this.helper.createCipher(paramInt);
      this.encKey = localKeyGenerator.generateKey();
      AlgorithmParameters localAlgorithmParameters = JceCMSContentEncryptorBuilder.this.helper.generateParameters(paramInt, this.encKey, localSecureRandom);
      try
      {
        this.cipher.init(1, this.encKey, localAlgorithmParameters, localSecureRandom);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CMSException("unable to initialize cipher: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
      }
      if (localAlgorithmParameters == null)
        localAlgorithmParameters = this.cipher.getParameters();
      this.algorithmIdentifier = JceCMSContentEncryptorBuilder.this.helper.getAlgorithmIdentifier(paramInt, localAlgorithmParameters);
    }

    public AlgorithmIdentifier getAlgorithmIdentifier()
    {
      return this.algorithmIdentifier;
    }

    public OutputStream getOutputStream(OutputStream paramOutputStream)
    {
      return new CipherOutputStream(paramOutputStream, this.cipher);
    }

    public GenericKey getKey()
    {
      return new GenericKey(this.encKey);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder
 * JD-Core Version:    0.6.0
 */