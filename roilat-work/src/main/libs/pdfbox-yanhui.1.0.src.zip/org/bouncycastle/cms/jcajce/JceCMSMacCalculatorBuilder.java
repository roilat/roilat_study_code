package org.bouncycastle.cms.jcajce;

import java.io.OutputStream;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.RC2ParameterSpec;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.jcajce.io.MacOutputStream;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.MacCalculator;

public class JceCMSMacCalculatorBuilder
{
  private final ASN1ObjectIdentifier macOID;
  private final int keySize;
  private EnvelopedDataHelper helper = new EnvelopedDataHelper(new DefaultJcaJceHelper());
  private SecureRandom random;
  private MacOutputStream macOutputStream;

  public JceCMSMacCalculatorBuilder(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    this(paramASN1ObjectIdentifier, -1);
  }

  public JceCMSMacCalculatorBuilder(ASN1ObjectIdentifier paramASN1ObjectIdentifier, int paramInt)
  {
    this.macOID = paramASN1ObjectIdentifier;
    this.keySize = paramInt;
  }

  public JceCMSMacCalculatorBuilder setProvider(Provider paramProvider)
  {
    this.helper = new EnvelopedDataHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceCMSMacCalculatorBuilder setProvider(String paramString)
  {
    this.helper = new EnvelopedDataHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public JceCMSMacCalculatorBuilder setSecureRandom(SecureRandom paramSecureRandom)
  {
    this.random = paramSecureRandom;
    return this;
  }

  public MacCalculator build()
    throws CMSException
  {
    return new CMSOutputEncryptor(this.macOID, this.keySize, this.random);
  }

  private class CMSOutputEncryptor
    implements MacCalculator
  {
    private SecretKey encKey;
    private AlgorithmIdentifier algorithmIdentifier;
    private Mac mac;
    private SecureRandom random;

    CMSOutputEncryptor(ASN1ObjectIdentifier paramInt, int paramSecureRandom, SecureRandom arg4)
      throws CMSException
    {
      KeyGenerator localKeyGenerator = JceCMSMacCalculatorBuilder.this.helper.createKeyGenerator(paramInt);
      SecureRandom localSecureRandom;
      if (localSecureRandom == null)
        localSecureRandom = new SecureRandom();
      this.random = localSecureRandom;
      if (paramSecureRandom < 0)
        localKeyGenerator.init(localSecureRandom);
      else
        localKeyGenerator.init(paramSecureRandom, localSecureRandom);
      this.encKey = localKeyGenerator.generateKey();
      AlgorithmParameterSpec localAlgorithmParameterSpec = generateParameterSpec(paramInt, this.encKey);
      this.algorithmIdentifier = JceCMSMacCalculatorBuilder.this.helper.getAlgorithmIdentifier(paramInt, localAlgorithmParameterSpec);
      this.mac = JceCMSMacCalculatorBuilder.this.helper.createContentMac(this.encKey, this.algorithmIdentifier);
    }

    public AlgorithmIdentifier getAlgorithmIdentifier()
    {
      return this.algorithmIdentifier;
    }

    public OutputStream getOutputStream()
    {
      return new MacOutputStream(this.mac);
    }

    public byte[] getMac()
    {
      return this.mac.doFinal();
    }

    public GenericKey getKey()
    {
      return new GenericKey(this.encKey);
    }

    protected AlgorithmParameterSpec generateParameterSpec(ASN1ObjectIdentifier paramASN1ObjectIdentifier, SecretKey paramSecretKey)
      throws CMSException
    {
      try
      {
        if (paramASN1ObjectIdentifier.equals(PKCSObjectIdentifiers.RC2_CBC))
        {
          localObject = new byte[8];
          this.random.nextBytes(localObject);
          return new RC2ParameterSpec(paramSecretKey.getEncoded().length * 8, localObject);
        }
        Object localObject = JceCMSMacCalculatorBuilder.this.helper.createAlgorithmParameterGenerator(paramASN1ObjectIdentifier);
        AlgorithmParameters localAlgorithmParameters = ((AlgorithmParameterGenerator)localObject).generateParameters();
        return localAlgorithmParameters.getParameterSpec(IvParameterSpec.class);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
      }
      return (AlgorithmParameterSpec)null;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JceCMSMacCalculatorBuilder
 * JD-Core Version:    0.6.0
 */