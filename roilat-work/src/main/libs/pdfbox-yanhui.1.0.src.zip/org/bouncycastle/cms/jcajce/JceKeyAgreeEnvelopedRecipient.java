package org.bouncycastle.cms.jcajce;

import java.io.InputStream;
import java.security.Key;
import java.security.PrivateKey;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.RecipientOperator;
import org.bouncycastle.operator.InputDecryptor;

public class JceKeyAgreeEnvelopedRecipient extends JceKeyAgreeRecipient
{
  public JceKeyAgreeEnvelopedRecipient(PrivateKey paramPrivateKey)
  {
    super(paramPrivateKey);
  }

  public RecipientOperator getRecipientOperator(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, SubjectPublicKeyInfo paramSubjectPublicKeyInfo, ASN1OctetString paramASN1OctetString, byte[] paramArrayOfByte)
    throws CMSException
  {
    Key localKey = extractSecretKey(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramSubjectPublicKeyInfo, paramASN1OctetString, paramArrayOfByte);
    Cipher localCipher = this.contentHelper.createContentCipher(localKey, paramAlgorithmIdentifier2);
    return new RecipientOperator(new InputDecryptor(paramAlgorithmIdentifier2, localCipher)
    {
      public AlgorithmIdentifier getAlgorithmIdentifier()
      {
        return this.val$contentEncryptionAlgorithm;
      }

      public InputStream getInputStream(InputStream paramInputStream)
      {
        return new CipherInputStream(paramInputStream, this.val$dataCipher);
      }
    });
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JceKeyAgreeEnvelopedRecipient
 * JD-Core Version:    0.6.0
 */