package org.bouncycastle.cms.jcajce;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.cms.OriginatorPublicKey;
import org.bouncycastle.asn1.cms.ecc.MQVuserKeyingMaterial;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cms.CMSEnvelopedGenerator;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.KeyAgreeRecipient;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.jce.spec.MQVPrivateKeySpec;
import org.bouncycastle.jce.spec.MQVPublicKeySpec;

public abstract class JceKeyAgreeRecipient
  implements KeyAgreeRecipient
{
  private PrivateKey recipientKey;
  protected EnvelopedDataHelper helper = new EnvelopedDataHelper(new DefaultJcaJceHelper());
  protected EnvelopedDataHelper contentHelper = this.helper;

  public JceKeyAgreeRecipient(PrivateKey paramPrivateKey)
  {
    this.recipientKey = paramPrivateKey;
  }

  public JceKeyAgreeRecipient setProvider(Provider paramProvider)
  {
    this.helper = new EnvelopedDataHelper(new ProviderJcaJceHelper(paramProvider));
    this.contentHelper = this.helper;
    return this;
  }

  public JceKeyAgreeRecipient setProvider(String paramString)
  {
    this.helper = new EnvelopedDataHelper(new NamedJcaJceHelper(paramString));
    this.contentHelper = this.helper;
    return this;
  }

  public JceKeyAgreeRecipient setContentProvider(Provider paramProvider)
  {
    this.contentHelper = new EnvelopedDataHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceKeyAgreeRecipient setContentProvider(String paramString)
  {
    this.contentHelper = new EnvelopedDataHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  private SecretKey calculateAgreedWrapKey(AlgorithmIdentifier paramAlgorithmIdentifier, ASN1ObjectIdentifier paramASN1ObjectIdentifier, PublicKey paramPublicKey, ASN1OctetString paramASN1OctetString, PrivateKey paramPrivateKey)
    throws CMSException, GeneralSecurityException, IOException
  {
    String str = paramAlgorithmIdentifier.getAlgorithm().getId();
    if (str.equals(CMSEnvelopedGenerator.ECMQV_SHA1KDF))
    {
      localObject = paramASN1OctetString.getOctets();
      MQVuserKeyingMaterial localMQVuserKeyingMaterial = MQVuserKeyingMaterial.getInstance(ASN1Object.fromByteArray(localObject));
      SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo(getPrivateKeyAlgorithmIdentifier(), localMQVuserKeyingMaterial.getEphemeralPublicKey().getPublicKey().getBytes());
      X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(localSubjectPublicKeyInfo.getEncoded());
      KeyFactory localKeyFactory = this.helper.createKeyFactory(paramAlgorithmIdentifier.getAlgorithm());
      PublicKey localPublicKey = localKeyFactory.generatePublic(localX509EncodedKeySpec);
      paramPublicKey = new MQVPublicKeySpec(paramPublicKey, localPublicKey);
      paramPrivateKey = new MQVPrivateKeySpec(paramPrivateKey, paramPrivateKey);
    }
    Object localObject = this.helper.createKeyAgreement(paramAlgorithmIdentifier.getAlgorithm());
    ((KeyAgreement)localObject).init(paramPrivateKey);
    ((KeyAgreement)localObject).doPhase(paramPublicKey, true);
    return (SecretKey)((KeyAgreement)localObject).generateSecret(paramASN1ObjectIdentifier.getId());
  }

  private Key unwrapSessionKey(ASN1ObjectIdentifier paramASN1ObjectIdentifier1, SecretKey paramSecretKey, ASN1ObjectIdentifier paramASN1ObjectIdentifier2, byte[] paramArrayOfByte)
    throws CMSException, InvalidKeyException, NoSuchAlgorithmException
  {
    Cipher localCipher = this.helper.createCipher(paramASN1ObjectIdentifier1);
    localCipher.init(4, paramSecretKey);
    return localCipher.unwrap(paramArrayOfByte, this.helper.getBaseCipherName(paramASN1ObjectIdentifier2), 3);
  }

  protected Key extractSecretKey(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, SubjectPublicKeyInfo paramSubjectPublicKeyInfo, ASN1OctetString paramASN1OctetString, byte[] paramArrayOfByte)
    throws CMSException
  {
    try
    {
      ASN1ObjectIdentifier localASN1ObjectIdentifier = AlgorithmIdentifier.getInstance(paramAlgorithmIdentifier1.getParameters()).getAlgorithm();
      X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(paramSubjectPublicKeyInfo.getEncoded());
      KeyFactory localKeyFactory = this.helper.createKeyFactory(paramAlgorithmIdentifier1.getAlgorithm());
      PublicKey localPublicKey = localKeyFactory.generatePublic(localX509EncodedKeySpec);
      SecretKey localSecretKey = calculateAgreedWrapKey(paramAlgorithmIdentifier1, localASN1ObjectIdentifier, localPublicKey, paramASN1OctetString, this.recipientKey);
      return unwrapSessionKey(localASN1ObjectIdentifier, localSecretKey, paramAlgorithmIdentifier2.getAlgorithm(), paramArrayOfByte);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (InvalidKeySpecException localInvalidKeySpecException)
    {
      throw new CMSException("originator key spec invalid.", localInvalidKeySpecException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (Exception localException)
    {
    }
    throw new CMSException("originator key invalid.", localException);
  }

  public AlgorithmIdentifier getPrivateKeyAlgorithmIdentifier()
  {
    return PrivateKeyInfo.getInstance(this.recipientKey.getEncoded()).getAlgorithmId();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JceKeyAgreeRecipient
 * JD-Core Version:    0.6.0
 */