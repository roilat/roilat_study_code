package org.bouncycastle.cms.jcajce;

import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECParameterSpec;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientIdentifier;
import org.bouncycastle.asn1.cms.RecipientEncryptedKey;
import org.bouncycastle.asn1.cms.RecipientKeyIdentifier;
import org.bouncycastle.asn1.cms.ecc.MQVuserKeyingMaterial;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cms.CMSAlgorithm;
import org.bouncycastle.cms.CMSEnvelopedGenerator;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.KeyAgreeRecipientInfoGenerator;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.jce.spec.MQVPrivateKeySpec;
import org.bouncycastle.jce.spec.MQVPublicKeySpec;
import org.bouncycastle.operator.GenericKey;

public class JceKeyAgreeRecipientInfoGenerator extends KeyAgreeRecipientInfoGenerator
{
  private List recipientIDs = new ArrayList();
  private List recipientKeys = new ArrayList();
  private PublicKey senderPublicKey;
  private PrivateKey senderPrivateKey;
  private EnvelopedDataHelper helper = new EnvelopedDataHelper(new DefaultJcaJceHelper());
  private SecureRandom random;
  private KeyPair ephemeralKP;

  public JceKeyAgreeRecipientInfoGenerator(ASN1ObjectIdentifier paramASN1ObjectIdentifier1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, ASN1ObjectIdentifier paramASN1ObjectIdentifier2)
    throws CMSException
  {
    super(paramASN1ObjectIdentifier1, SubjectPublicKeyInfo.getInstance(paramPublicKey.getEncoded()), paramASN1ObjectIdentifier2);
    this.senderPublicKey = paramPublicKey;
    this.senderPrivateKey = paramPrivateKey;
  }

  public JceKeyAgreeRecipientInfoGenerator setProvider(Provider paramProvider)
  {
    this.helper = new EnvelopedDataHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceKeyAgreeRecipientInfoGenerator setProvider(String paramString)
  {
    this.helper = new EnvelopedDataHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public JceKeyAgreeRecipientInfoGenerator setSecureRandom(SecureRandom paramSecureRandom)
  {
    this.random = paramSecureRandom;
    return this;
  }

  public JceKeyAgreeRecipientInfoGenerator addRecipient(X509Certificate paramX509Certificate)
    throws CertificateEncodingException
  {
    this.recipientIDs.add(new KeyAgreeRecipientIdentifier(CMSUtils.getIssuerAndSerialNumber(paramX509Certificate)));
    this.recipientKeys.add(paramX509Certificate.getPublicKey());
    return this;
  }

  public JceKeyAgreeRecipientInfoGenerator addRecipient(byte[] paramArrayOfByte, PublicKey paramPublicKey)
    throws CertificateEncodingException
  {
    this.recipientIDs.add(new KeyAgreeRecipientIdentifier(new RecipientKeyIdentifier(paramArrayOfByte)));
    this.recipientKeys.add(paramPublicKey);
    return this;
  }

  public ASN1Sequence generateRecipientEncryptedKeys(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, GenericKey paramGenericKey)
    throws CMSException
  {
    init(paramAlgorithmIdentifier1.getAlgorithm());
    Object localObject1 = this.senderPrivateKey;
    ASN1ObjectIdentifier localASN1ObjectIdentifier = paramAlgorithmIdentifier1.getAlgorithm();
    if (localASN1ObjectIdentifier.getId().equals(CMSEnvelopedGenerator.ECMQV_SHA1KDF))
      localObject1 = new MQVPrivateKeySpec((PrivateKey)localObject1, this.ephemeralKP.getPrivate(), this.ephemeralKP.getPublic());
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    for (int i = 0; i != this.recipientIDs.size(); i++)
    {
      Object localObject2 = (PublicKey)this.recipientKeys.get(i);
      KeyAgreeRecipientIdentifier localKeyAgreeRecipientIdentifier = (KeyAgreeRecipientIdentifier)this.recipientIDs.get(i);
      if (localASN1ObjectIdentifier.getId().equals(CMSEnvelopedGenerator.ECMQV_SHA1KDF))
        localObject2 = new MQVPublicKeySpec((PublicKey)localObject2, (PublicKey)localObject2);
      try
      {
        KeyAgreement localKeyAgreement = this.helper.createKeyAgreement(localASN1ObjectIdentifier);
        localKeyAgreement.init((Key)localObject1, this.random);
        localKeyAgreement.doPhase((Key)localObject2, true);
        SecretKey localSecretKey = localKeyAgreement.generateSecret(paramAlgorithmIdentifier2.getAlgorithm().getId());
        Cipher localCipher = this.helper.createCipher(paramAlgorithmIdentifier2.getAlgorithm());
        localCipher.init(3, localSecretKey, this.random);
        byte[] arrayOfByte = localCipher.wrap(CMSUtils.getJceKey(paramGenericKey));
        DEROctetString localDEROctetString = new DEROctetString(arrayOfByte);
        localASN1EncodableVector.add(new RecipientEncryptedKey(localKeyAgreeRecipientIdentifier, localDEROctetString));
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CMSException("cannot perform agreement step: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
      }
    }
    return (ASN1Sequence)(ASN1Sequence)new DERSequence(localASN1EncodableVector);
  }

  protected ASN1Encodable getUserKeyingMaterial(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws CMSException
  {
    init(paramAlgorithmIdentifier.getAlgorithm());
    if (this.ephemeralKP != null)
      return new MQVuserKeyingMaterial(createOriginatorPublicKey(SubjectPublicKeyInfo.getInstance(this.ephemeralKP.getPublic().getEncoded())), null);
    return null;
  }

  private void init(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws CMSException
  {
    if (this.random == null)
      this.random = new SecureRandom();
    if ((paramASN1ObjectIdentifier.equals(CMSAlgorithm.ECMQV_SHA1KDF)) && (this.ephemeralKP == null))
      try
      {
        ECParameterSpec localECParameterSpec = ((ECPublicKey)this.senderPublicKey).getParams();
        KeyPairGenerator localKeyPairGenerator = this.helper.createKeyPairGenerator(paramASN1ObjectIdentifier);
        localKeyPairGenerator.initialize(localECParameterSpec, this.random);
        this.ephemeralKP = localKeyPairGenerator.generateKeyPair();
      }
      catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
      {
        throw new CMSException("cannot determine MQV ephemeral key pair parameters from public key: " + localInvalidAlgorithmParameterException);
      }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JceKeyAgreeRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */