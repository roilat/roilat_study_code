package org.bouncycastle.cms.jcajce;

import java.io.OutputStream;
import java.security.Key;
import java.security.PrivateKey;
import javax.crypto.Mac;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.RecipientOperator;
import org.bouncycastle.jcajce.io.MacOutputStream;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.MacCalculator;

public class JceKeyTransAuthenticatedRecipient extends JceKeyTransRecipient
{
  public JceKeyTransAuthenticatedRecipient(PrivateKey paramPrivateKey)
  {
    super(paramPrivateKey);
  }

  public RecipientOperator getRecipientOperator(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, byte[] paramArrayOfByte)
    throws CMSException
  {
    Key localKey = extractSecretKey(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramArrayOfByte);
    Mac localMac = this.contentHelper.createContentMac(localKey, paramAlgorithmIdentifier2);
    return new RecipientOperator(new MacCalculator(paramAlgorithmIdentifier2, localKey, localMac)
    {
      public AlgorithmIdentifier getAlgorithmIdentifier()
      {
        return this.val$contentMacAlgorithm;
      }

      public GenericKey getKey()
      {
        return new GenericKey(this.val$secretKey);
      }

      public OutputStream getOutputStream()
      {
        return new MacOutputStream(this.val$dataMac);
      }

      public byte[] getMac()
      {
        return this.val$dataMac.doFinal();
      }
    });
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JceKeyTransAuthenticatedRecipient
 * JD-Core Version:    0.6.0
 */