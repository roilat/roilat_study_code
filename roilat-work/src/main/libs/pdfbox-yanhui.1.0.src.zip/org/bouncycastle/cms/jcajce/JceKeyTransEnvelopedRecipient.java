package org.bouncycastle.cms.jcajce;

import java.io.InputStream;
import java.security.Key;
import java.security.PrivateKey;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.RecipientOperator;
import org.bouncycastle.operator.InputDecryptor;

public class JceKeyTransEnvelopedRecipient extends JceKeyTransRecipient
{
  public JceKeyTransEnvelopedRecipient(PrivateKey paramPrivateKey)
  {
    super(paramPrivateKey);
  }

  public RecipientOperator getRecipientOperator(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, byte[] paramArrayOfByte)
    throws CMSException
  {
    Key localKey = extractSecretKey(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramArrayOfByte);
    Cipher localCipher = this.contentHelper.createContentCipher(localKey, paramAlgorithmIdentifier2);
    return new RecipientOperator(new InputDecryptor(paramAlgorithmIdentifier2, localCipher)
    {
      public AlgorithmIdentifier getAlgorithmIdentifier()
      {
        return this.val$contentEncryptionAlgorithm;
      }

      public InputStream getInputStream(InputStream paramInputStream)
      {
        return new CipherInputStream(paramInputStream, this.val$dataCipher);
      }
    });
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JceKeyTransEnvelopedRecipient
 * JD-Core Version:    0.6.0
 */