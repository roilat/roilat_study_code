package org.bouncycastle.cms.jcajce;

import java.security.Key;
import java.security.PrivateKey;
import java.security.Provider;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.KeyTransRecipient;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.AsymmetricKeyUnwrapper;
import org.bouncycastle.operator.OperatorException;

public abstract class JceKeyTransRecipient
  implements KeyTransRecipient
{
  private PrivateKey recipientKey;
  protected EnvelopedDataHelper helper = new EnvelopedDataHelper(new DefaultJcaJceHelper());
  protected EnvelopedDataHelper contentHelper = this.helper;

  public JceKeyTransRecipient(PrivateKey paramPrivateKey)
  {
    this.recipientKey = paramPrivateKey;
  }

  public JceKeyTransRecipient setProvider(Provider paramProvider)
  {
    this.helper = new EnvelopedDataHelper(new ProviderJcaJceHelper(paramProvider));
    this.contentHelper = this.helper;
    return this;
  }

  public JceKeyTransRecipient setProvider(String paramString)
  {
    this.helper = new EnvelopedDataHelper(new NamedJcaJceHelper(paramString));
    this.contentHelper = this.helper;
    return this;
  }

  public JceKeyTransRecipient setContentProvider(Provider paramProvider)
  {
    this.contentHelper = new EnvelopedDataHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceKeyTransRecipient setContentProvider(String paramString)
  {
    this.contentHelper = new EnvelopedDataHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  protected Key extractSecretKey(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, byte[] paramArrayOfByte)
    throws CMSException
  {
    AsymmetricKeyUnwrapper localAsymmetricKeyUnwrapper = this.helper.createAsymmetricUnwrapper(paramAlgorithmIdentifier1, this.recipientKey);
    try
    {
      return CMSUtils.getJceKey(localAsymmetricKeyUnwrapper.generateUnwrappedKey(paramAlgorithmIdentifier2, paramArrayOfByte));
    }
    catch (OperatorException localOperatorException)
    {
    }
    throw new CMSException("exception unwrapping key: " + localOperatorException.getMessage(), localOperatorException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JceKeyTransRecipient
 * JD-Core Version:    0.6.0
 */