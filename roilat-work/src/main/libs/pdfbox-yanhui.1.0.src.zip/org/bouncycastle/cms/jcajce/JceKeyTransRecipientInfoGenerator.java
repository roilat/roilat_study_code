package org.bouncycastle.cms.jcajce;

import java.security.Provider;
import java.security.PublicKey;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
import org.bouncycastle.cms.KeyTransRecipientInfoGenerator;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JceAsymmetricKeyWrapper;

public class JceKeyTransRecipientInfoGenerator extends KeyTransRecipientInfoGenerator
{
  public JceKeyTransRecipientInfoGenerator(X509Certificate paramX509Certificate)
    throws CertificateEncodingException
  {
    super(new JcaX509CertificateHolder(paramX509Certificate).getIssuerAndSerialNumber(), new JceAsymmetricKeyWrapper(paramX509Certificate.getPublicKey()));
  }

  public JceKeyTransRecipientInfoGenerator(byte[] paramArrayOfByte, PublicKey paramPublicKey)
  {
    super(paramArrayOfByte, new JceAsymmetricKeyWrapper(paramPublicKey));
  }

  public JceKeyTransRecipientInfoGenerator setProvider(String paramString)
    throws OperatorCreationException
  {
    ((JceAsymmetricKeyWrapper)this.wrapper).setProvider(paramString);
    return this;
  }

  public JceKeyTransRecipientInfoGenerator setProvider(Provider paramProvider)
    throws OperatorCreationException
  {
    ((JceAsymmetricKeyWrapper)this.wrapper).setProvider(paramProvider);
    return this;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */