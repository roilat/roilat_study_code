package org.bouncycastle.cms.jcajce;

import java.io.InputStream;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.RecipientOperator;
import org.bouncycastle.operator.InputDecryptor;

public class JcePasswordEnvelopedRecipient extends JcePasswordRecipient
{
  public JcePasswordEnvelopedRecipient(char[] paramArrayOfChar)
  {
    super(paramArrayOfChar);
  }

  public RecipientOperator getRecipientOperator(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws CMSException
  {
    Key localKey = extractSecretKey(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramArrayOfByte1, paramArrayOfByte2);
    Cipher localCipher = this.helper.createContentCipher(localKey, paramAlgorithmIdentifier2);
    return new RecipientOperator(new InputDecryptor(paramAlgorithmIdentifier2, localCipher)
    {
      public AlgorithmIdentifier getAlgorithmIdentifier()
      {
        return this.val$contentEncryptionAlgorithm;
      }

      public InputStream getInputStream(InputStream paramInputStream)
      {
        return new CipherInputStream(paramInputStream, this.val$dataCipher);
      }
    });
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JcePasswordEnvelopedRecipient
 * JD-Core Version:    0.6.0
 */