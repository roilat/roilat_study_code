package org.bouncycastle.cms.jcajce;

import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.Provider;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.PasswordRecipient;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;

public abstract class JcePasswordRecipient
  implements PasswordRecipient
{
  private int schemeID = 1;
  protected EnvelopedDataHelper helper = new EnvelopedDataHelper(new DefaultJcaJceHelper());
  private char[] password;

  JcePasswordRecipient(char[] paramArrayOfChar)
  {
    this.password = paramArrayOfChar;
  }

  public JcePasswordRecipient setPasswordConversionScheme(int paramInt)
  {
    this.schemeID = paramInt;
    return this;
  }

  public JcePasswordRecipient setProvider(Provider paramProvider)
  {
    this.helper = new EnvelopedDataHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JcePasswordRecipient setProvider(String paramString)
  {
    this.helper = new EnvelopedDataHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  protected Key extractSecretKey(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws CMSException
  {
    Cipher localCipher = this.helper.createRFC3211Wrapper(paramAlgorithmIdentifier1.getAlgorithm());
    try
    {
      IvParameterSpec localIvParameterSpec = new IvParameterSpec(ASN1OctetString.getInstance(paramAlgorithmIdentifier1.getParameters()).getOctets());
      localCipher.init(4, new SecretKeySpec(paramArrayOfByte1, localCipher.getAlgorithm()), localIvParameterSpec);
      return localCipher.unwrap(paramArrayOfByte2, paramAlgorithmIdentifier2.getAlgorithm().getId(), 3);
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("cannot process content encryption key: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  public int getPasswordConversionScheme()
  {
    return this.schemeID;
  }

  public char[] getPassword()
  {
    return this.password;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JcePasswordRecipient
 * JD-Core Version:    0.6.0
 */