package org.bouncycastle.cms.jcajce;

import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.Provider;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.PasswordRecipientInfoGenerator;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.GenericKey;

public class JcePasswordRecipientInfoGenerator extends PasswordRecipientInfoGenerator
{
  private EnvelopedDataHelper helper = new EnvelopedDataHelper(new DefaultJcaJceHelper());

  public JcePasswordRecipientInfoGenerator(ASN1ObjectIdentifier paramASN1ObjectIdentifier, char[] paramArrayOfChar)
  {
    super(paramASN1ObjectIdentifier, paramArrayOfChar);
  }

  public JcePasswordRecipientInfoGenerator setProvider(Provider paramProvider)
  {
    this.helper = new EnvelopedDataHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JcePasswordRecipientInfoGenerator setProvider(String paramString)
  {
    this.helper = new EnvelopedDataHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public byte[] generateEncryptedBytes(AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte, GenericKey paramGenericKey)
    throws CMSException
  {
    Key localKey = CMSUtils.getJceKey(paramGenericKey);
    Cipher localCipher = this.helper.createRFC3211Wrapper(paramAlgorithmIdentifier.getAlgorithm());
    try
    {
      IvParameterSpec localIvParameterSpec = new IvParameterSpec(ASN1OctetString.getInstance(paramAlgorithmIdentifier.getParameters()).getOctets());
      localCipher.init(3, new SecretKeySpec(paramArrayOfByte, localCipher.getAlgorithm()), localIvParameterSpec);
      return localCipher.wrap(localKey);
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new CMSException("cannot process content encryption key: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.JcePasswordRecipientInfoGenerator
 * JD-Core Version:    0.6.0
 */