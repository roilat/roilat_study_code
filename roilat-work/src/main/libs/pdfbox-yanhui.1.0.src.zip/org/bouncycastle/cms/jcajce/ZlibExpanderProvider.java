package org.bouncycastle.cms.jcajce;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.InflaterInputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.InputExpander;
import org.bouncycastle.operator.InputExpanderProvider;
import org.bouncycastle.util.io.StreamOverflowException;

public class ZlibExpanderProvider
  implements InputExpanderProvider
{
  private final long limit;

  public ZlibExpanderProvider()
  {
    this.limit = -1L;
  }

  public ZlibExpanderProvider(long paramLong)
  {
    this.limit = paramLong;
  }

  public InputExpander get(AlgorithmIdentifier paramAlgorithmIdentifier)
  {
    return new InputExpander(paramAlgorithmIdentifier)
    {
      public AlgorithmIdentifier getAlgorithmIdentifier()
      {
        return this.val$algorithm;
      }

      public InputStream getInputStream(InputStream paramInputStream)
      {
        Object localObject = new InflaterInputStream(paramInputStream);
        if (ZlibExpanderProvider.this.limit >= 0L)
          localObject = new ZlibExpanderProvider.LimitedInputStream((InputStream)localObject, ZlibExpanderProvider.this.limit);
        return (InputStream)localObject;
      }
    };
  }

  private static class LimitedInputStream extends FilterInputStream
  {
    private long remaining;

    public LimitedInputStream(InputStream paramInputStream, long paramLong)
    {
      super();
      this.remaining = paramLong;
    }

    public int read()
      throws IOException
    {
      if (this.remaining >= 0L)
      {
        int i = this.in.read();
        if ((i < 0) || (--this.remaining >= 0L))
          return i;
      }
      throw new StreamOverflowException("expanded byte limit exceeded");
    }

    public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      if (paramInt2 < 1)
        return super.read(paramArrayOfByte, paramInt1, paramInt2);
      if (this.remaining < 1L)
      {
        read();
        return -1;
      }
      int i = this.remaining > paramInt2 ? paramInt2 : (int)this.remaining;
      int j = this.in.read(paramArrayOfByte, paramInt1, i);
      if (j > 0)
        this.remaining -= j;
      return j;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.cms.jcajce.ZlibExpanderProvider
 * JD-Core Version:    0.6.0
 */