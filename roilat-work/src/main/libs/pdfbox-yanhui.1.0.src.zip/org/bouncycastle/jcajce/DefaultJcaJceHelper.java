package org.bouncycastle.jcajce;

import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.KeyFactory;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.AsymmetricKeyUnwrapper;
import org.bouncycastle.operator.SymmetricKeyUnwrapper;
import org.bouncycastle.operator.jcajce.JceAsymmetricKeyUnwrapper;
import org.bouncycastle.operator.jcajce.JceSymmetricKeyUnwrapper;

public class DefaultJcaJceHelper
  implements JcaJceHelper
{
  public Cipher createCipher(String paramString)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    return Cipher.getInstance(paramString);
  }

  public Mac createMac(String paramString)
    throws NoSuchAlgorithmException
  {
    return Mac.getInstance(paramString);
  }

  public KeyAgreement createKeyAgreement(String paramString)
    throws NoSuchAlgorithmException
  {
    return KeyAgreement.getInstance(paramString);
  }

  public AlgorithmParameterGenerator createAlgorithmParameterGenerator(String paramString)
    throws NoSuchAlgorithmException
  {
    return AlgorithmParameterGenerator.getInstance(paramString);
  }

  public AlgorithmParameters createAlgorithmParameters(String paramString)
    throws NoSuchAlgorithmException
  {
    return AlgorithmParameters.getInstance(paramString);
  }

  public KeyGenerator createKeyGenerator(String paramString)
    throws NoSuchAlgorithmException
  {
    return KeyGenerator.getInstance(paramString);
  }

  public KeyFactory createKeyFactory(String paramString)
    throws NoSuchAlgorithmException
  {
    return KeyFactory.getInstance(paramString);
  }

  public KeyPairGenerator createKeyPairGenerator(String paramString)
    throws NoSuchAlgorithmException
  {
    return KeyPairGenerator.getInstance(paramString);
  }

  public MessageDigest createDigest(String paramString)
    throws NoSuchAlgorithmException
  {
    return MessageDigest.getInstance(paramString);
  }

  public Signature createSignature(String paramString)
    throws NoSuchAlgorithmException
  {
    return Signature.getInstance(paramString);
  }

  public CertificateFactory createCertificateFactory(String paramString)
    throws NoSuchAlgorithmException, CertificateException
  {
    return CertificateFactory.getInstance(paramString);
  }

  public AsymmetricKeyUnwrapper createAsymmetricUnwrapper(AlgorithmIdentifier paramAlgorithmIdentifier, PrivateKey paramPrivateKey)
  {
    return new JceAsymmetricKeyUnwrapper(paramAlgorithmIdentifier, paramPrivateKey);
  }

  public SymmetricKeyUnwrapper createSymmetricUnwrapper(AlgorithmIdentifier paramAlgorithmIdentifier, SecretKey paramSecretKey)
  {
    return new JceSymmetricKeyUnwrapper(paramAlgorithmIdentifier, paramSecretKey);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.jcajce.DefaultJcaJceHelper
 * JD-Core Version:    0.6.0
 */