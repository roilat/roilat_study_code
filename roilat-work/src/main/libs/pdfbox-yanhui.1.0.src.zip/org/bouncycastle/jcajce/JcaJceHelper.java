package org.bouncycastle.jcajce;

import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.KeyFactory;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.operator.AsymmetricKeyUnwrapper;
import org.bouncycastle.operator.SymmetricKeyUnwrapper;

public abstract interface JcaJceHelper
{
  public abstract Cipher createCipher(String paramString)
    throws NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException;

  public abstract Mac createMac(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException;

  public abstract KeyAgreement createKeyAgreement(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException;

  public abstract AlgorithmParameterGenerator createAlgorithmParameterGenerator(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException;

  public abstract AlgorithmParameters createAlgorithmParameters(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException;

  public abstract KeyGenerator createKeyGenerator(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException;

  public abstract KeyFactory createKeyFactory(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException;

  public abstract KeyPairGenerator createKeyPairGenerator(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException;

  public abstract MessageDigest createDigest(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException;

  public abstract Signature createSignature(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException;

  public abstract CertificateFactory createCertificateFactory(String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, CertificateException;

  public abstract AsymmetricKeyUnwrapper createAsymmetricUnwrapper(AlgorithmIdentifier paramAlgorithmIdentifier, PrivateKey paramPrivateKey);

  public abstract SymmetricKeyUnwrapper createSymmetricUnwrapper(AlgorithmIdentifier paramAlgorithmIdentifier, SecretKey paramSecretKey);
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.jcajce.JcaJceHelper
 * JD-Core Version:    0.6.0
 */