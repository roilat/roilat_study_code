package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessable;

public class CMSProcessableBodyPart
  implements CMSProcessable
{
  private BodyPart bodyPart;

  public CMSProcessableBodyPart(BodyPart paramBodyPart)
  {
    this.bodyPart = paramBodyPart;
  }

  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
    try
    {
      this.bodyPart.writeTo(paramOutputStream);
    }
    catch (MessagingException localMessagingException)
    {
      throw new CMSException("can't write BodyPart to stream.", localMessagingException);
    }
  }

  public Object getContent()
  {
    return this.bodyPart;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.CMSProcessableBodyPart
 * JD-Core Version:    0.6.0
 */