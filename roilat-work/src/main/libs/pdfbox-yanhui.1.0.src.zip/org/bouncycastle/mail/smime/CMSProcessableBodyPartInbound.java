package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessable;

public class CMSProcessableBodyPartInbound
  implements CMSProcessable
{
  private final BodyPart bodyPart;
  private final String defaultContentTransferEncoding;

  public CMSProcessableBodyPartInbound(BodyPart paramBodyPart)
  {
    this(paramBodyPart, "7bit");
  }

  public CMSProcessableBodyPartInbound(BodyPart paramBodyPart, String paramString)
  {
    this.bodyPart = paramBodyPart;
    this.defaultContentTransferEncoding = paramString;
  }

  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
    try
    {
      SMIMEUtil.outputBodyPart(paramOutputStream, this.bodyPart, this.defaultContentTransferEncoding);
    }
    catch (MessagingException localMessagingException)
    {
      throw new CMSException("can't write BodyPart to stream: " + localMessagingException, localMessagingException);
    }
  }

  public Object getContent()
  {
    return this.bodyPart;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.CMSProcessableBodyPartInbound
 * JD-Core Version:    0.6.0
 */