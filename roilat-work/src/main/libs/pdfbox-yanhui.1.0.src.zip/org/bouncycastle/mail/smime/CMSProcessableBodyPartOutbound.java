package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessable;
import org.bouncycastle.mail.smime.util.CRLFOutputStream;

public class CMSProcessableBodyPartOutbound
  implements CMSProcessable
{
  private BodyPart bodyPart;
  private String defaultContentTransferEncoding;

  public CMSProcessableBodyPartOutbound(BodyPart paramBodyPart)
  {
    this.bodyPart = paramBodyPart;
  }

  public CMSProcessableBodyPartOutbound(BodyPart paramBodyPart, String paramString)
  {
    this.bodyPart = paramBodyPart;
    this.defaultContentTransferEncoding = paramString;
  }

  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
    try
    {
      if (SMIMEUtil.isCanonicalisationRequired((MimeBodyPart)this.bodyPart, this.defaultContentTransferEncoding))
        paramOutputStream = new CRLFOutputStream(paramOutputStream);
      this.bodyPart.writeTo(paramOutputStream);
    }
    catch (MessagingException localMessagingException)
    {
      throw new CMSException("can't write BodyPart to stream.", localMessagingException);
    }
  }

  public Object getContent()
  {
    return this.bodyPart;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.CMSProcessableBodyPartOutbound
 * JD-Core Version:    0.6.0
 */