package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.InputStream;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimePart;
import org.bouncycastle.cms.CMSCompressedData;
import org.bouncycastle.cms.CMSException;

public class SMIMECompressed extends CMSCompressedData
{
  MimePart message;

  private static InputStream getInputStream(Part paramPart)
    throws MessagingException
  {
    try
    {
      return paramPart.getInputStream();
    }
    catch (IOException localIOException)
    {
    }
    throw new MessagingException("can't extract input stream: " + localIOException);
  }

  public SMIMECompressed(MimeBodyPart paramMimeBodyPart)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeBodyPart));
    this.message = paramMimeBodyPart;
  }

  public SMIMECompressed(MimeMessage paramMimeMessage)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeMessage));
    this.message = paramMimeMessage;
  }

  public MimePart getCompressedContent()
  {
    return this.message;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.SMIMECompressed
 * JD-Core Version:    0.6.0
 */