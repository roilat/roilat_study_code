package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.cms.CMSCompressedDataStreamGenerator;

public class SMIMECompressedGenerator extends SMIMEGenerator
{
  public static final String ZLIB = "1.2.840.113549.1.9.16.3.8";
  private static final String COMPRESSED_CONTENT_TYPE = "application/pkcs7-mime; name=\"smime.p7z\"; smime-type=compressed-data";

  private MimeBodyPart make(MimeBodyPart paramMimeBodyPart, String paramString)
    throws SMIMEException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new ContentCompressor(paramMimeBodyPart, paramString), "application/pkcs7-mime; name=\"smime.p7z\"; smime-type=compressed-data");
      localMimeBodyPart.addHeader("Content-Type", "application/pkcs7-mime; name=\"smime.p7z\"; smime-type=compressed-data");
      localMimeBodyPart.addHeader("Content-Disposition", "attachment; filename=\"smime.p7z\"");
      localMimeBodyPart.addHeader("Content-Description", "S/MIME Compressed Message");
      localMimeBodyPart.addHeader("Content-Transfer-Encoding", this.encoding);
      return localMimeBodyPart;
    }
    catch (MessagingException localMessagingException)
    {
    }
    throw new SMIMEException("exception putting multi-part together.", localMessagingException);
  }

  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, String paramString)
    throws SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), paramString);
  }

  public MimeBodyPart generate(MimeMessage paramMimeMessage, String paramString)
    throws SMIMEException
  {
    try
    {
      paramMimeMessage.saveChanges();
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("unable to save message", localMessagingException);
    }
    return make(makeContentBodyPart(paramMimeMessage), paramString);
  }

  static
  {
    MailcapCommandMap localMailcapCommandMap = (MailcapCommandMap)CommandMap.getDefaultCommandMap();
    localMailcapCommandMap.addMailcap("application/pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_mime");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_mime");
    CommandMap.setDefaultCommandMap(localMailcapCommandMap);
  }

  private class ContentCompressor
    implements SMIMEStreamingProcessor
  {
    private final MimeBodyPart _content;
    private final String _compressionOid;

    ContentCompressor(MimeBodyPart paramString, String arg3)
    {
      this._content = paramString;
      Object localObject;
      this._compressionOid = localObject;
    }

    public void write(OutputStream paramOutputStream)
      throws IOException
    {
      CMSCompressedDataStreamGenerator localCMSCompressedDataStreamGenerator = new CMSCompressedDataStreamGenerator();
      OutputStream localOutputStream = localCMSCompressedDataStreamGenerator.open(paramOutputStream, this._compressionOid);
      try
      {
        this._content.writeTo(localOutputStream);
        localOutputStream.close();
      }
      catch (MessagingException localMessagingException)
      {
        throw new IOException(localMessagingException.toString());
      }
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.SMIMECompressedGenerator
 * JD-Core Version:    0.6.0
 */