package org.bouncycastle.mail.smime;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimePart;
import org.bouncycastle.cms.CMSCompressedDataParser;
import org.bouncycastle.cms.CMSException;

public class SMIMECompressedParser extends CMSCompressedDataParser
{
  private final MimePart message;

  private static InputStream getInputStream(Part paramPart, int paramInt)
    throws MessagingException
  {
    try
    {
      InputStream localInputStream = paramPart.getInputStream();
      if (paramInt == 0)
        return new BufferedInputStream(localInputStream);
      return new BufferedInputStream(localInputStream, paramInt);
    }
    catch (IOException localIOException)
    {
    }
    throw new MessagingException("can't extract input stream: " + localIOException);
  }

  public SMIMECompressedParser(MimeBodyPart paramMimeBodyPart)
    throws MessagingException, CMSException
  {
    this(paramMimeBodyPart, 0);
  }

  public SMIMECompressedParser(MimeMessage paramMimeMessage)
    throws MessagingException, CMSException
  {
    this(paramMimeMessage, 0);
  }

  public SMIMECompressedParser(MimeBodyPart paramMimeBodyPart, int paramInt)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeBodyPart, paramInt));
    this.message = paramMimeBodyPart;
  }

  public SMIMECompressedParser(MimeMessage paramMimeMessage, int paramInt)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeMessage, paramInt));
    this.message = paramMimeMessage;
  }

  public MimePart getCompressedContent()
  {
    return this.message;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.SMIMECompressedParser
 * JD-Core Version:    0.6.0
 */