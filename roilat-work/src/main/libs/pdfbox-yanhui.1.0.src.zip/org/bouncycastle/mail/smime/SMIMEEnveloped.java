package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.InputStream;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimePart;
import org.bouncycastle.cms.CMSEnvelopedData;
import org.bouncycastle.cms.CMSException;

public class SMIMEEnveloped extends CMSEnvelopedData
{
  MimePart message;

  private static InputStream getInputStream(Part paramPart)
    throws MessagingException
  {
    try
    {
      return paramPart.getInputStream();
    }
    catch (IOException localIOException)
    {
    }
    throw new MessagingException("can't extract input stream: " + localIOException);
  }

  public SMIMEEnveloped(MimeBodyPart paramMimeBodyPart)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeBodyPart));
    this.message = paramMimeBodyPart;
  }

  public SMIMEEnveloped(MimeMessage paramMimeMessage)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeMessage));
    this.message = paramMimeMessage;
  }

  public MimePart getEncryptedContent()
  {
    return this.message;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.SMIMEEnveloped
 * JD-Core Version:    0.6.0
 */