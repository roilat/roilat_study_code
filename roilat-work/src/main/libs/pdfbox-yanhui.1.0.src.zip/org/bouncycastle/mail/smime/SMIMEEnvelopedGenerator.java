package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.activation.CommandMap;
import javax.activation.DataHandler;
import javax.activation.MailcapCommandMap;
import javax.crypto.SecretKey;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.cms.CMSEnvelopedDataGenerator;
import org.bouncycastle.cms.CMSEnvelopedDataStreamGenerator;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.RecipientInfoGenerator;
import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
import org.bouncycastle.cms.jcajce.JceKEKRecipientInfoGenerator;
import org.bouncycastle.cms.jcajce.JceKeyAgreeRecipientInfoGenerator;
import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.OutputEncryptor;

public class SMIMEEnvelopedGenerator extends SMIMEGenerator
{
  public static final String DES_EDE3_CBC = CMSEnvelopedDataGenerator.DES_EDE3_CBC;
  public static final String RC2_CBC = CMSEnvelopedDataGenerator.RC2_CBC;
  public static final String IDEA_CBC = "1.3.6.1.4.1.188.7.1.1.2";
  public static final String CAST5_CBC = "1.2.840.113533.7.66.10";
  public static final String AES128_CBC = CMSEnvelopedDataGenerator.AES128_CBC;
  public static final String AES192_CBC = CMSEnvelopedDataGenerator.AES192_CBC;
  public static final String AES256_CBC = CMSEnvelopedDataGenerator.AES256_CBC;
  public static final String CAMELLIA128_CBC = CMSEnvelopedDataGenerator.CAMELLIA128_CBC;
  public static final String CAMELLIA192_CBC = CMSEnvelopedDataGenerator.CAMELLIA192_CBC;
  public static final String CAMELLIA256_CBC = CMSEnvelopedDataGenerator.CAMELLIA256_CBC;
  public static final String SEED_CBC = CMSEnvelopedDataGenerator.SEED_CBC;
  public static final String DES_EDE3_WRAP = CMSEnvelopedDataGenerator.DES_EDE3_WRAP;
  public static final String AES128_WRAP = CMSEnvelopedDataGenerator.AES128_WRAP;
  public static final String AES256_WRAP = CMSEnvelopedDataGenerator.AES256_WRAP;
  public static final String CAMELLIA128_WRAP = CMSEnvelopedDataGenerator.CAMELLIA128_WRAP;
  public static final String CAMELLIA192_WRAP = CMSEnvelopedDataGenerator.CAMELLIA192_WRAP;
  public static final String CAMELLIA256_WRAP = CMSEnvelopedDataGenerator.CAMELLIA256_WRAP;
  public static final String SEED_WRAP = CMSEnvelopedDataGenerator.SEED_WRAP;
  public static final String ECDH_SHA1KDF = CMSEnvelopedDataGenerator.ECDH_SHA1KDF;
  private static final String ENCRYPTED_CONTENT_TYPE = "application/pkcs7-mime; name=\"smime.p7m\"; smime-type=enveloped-data";
  private EnvelopedGenerator fact = new EnvelopedGenerator(null);
  private List recipients = new ArrayList();

  private static MailcapCommandMap addCommands(CommandMap paramCommandMap)
  {
    MailcapCommandMap localMailcapCommandMap = (MailcapCommandMap)paramCommandMap;
    localMailcapCommandMap.addMailcap("application/pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_mime");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_mime");
    localMailcapCommandMap.addMailcap("multipart/signed;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.multipart_signed");
    return localMailcapCommandMap;
  }

  public void addRecipientInfoGenerator(RecipientInfoGenerator paramRecipientInfoGenerator)
    throws IllegalArgumentException
  {
    this.fact.addRecipientInfoGenerator(paramRecipientInfoGenerator);
  }

  /** @deprecated */
  public void addKeyTransRecipient(X509Certificate paramX509Certificate)
    throws IllegalArgumentException
  {
    try
    {
      JceKeyTransRecipientInfoGenerator localJceKeyTransRecipientInfoGenerator = new JceKeyTransRecipientInfoGenerator(paramX509Certificate);
      this.recipients.add(localJceKeyTransRecipientInfoGenerator);
      this.fact.addRecipientInfoGenerator(localJceKeyTransRecipientInfoGenerator);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
      throw new IllegalArgumentException(localCertificateEncodingException.toString());
    }
  }

  /** @deprecated */
  public void addKeyTransRecipient(PublicKey paramPublicKey, byte[] paramArrayOfByte)
    throws IllegalArgumentException
  {
    JceKeyTransRecipientInfoGenerator localJceKeyTransRecipientInfoGenerator = new JceKeyTransRecipientInfoGenerator(paramArrayOfByte, paramPublicKey);
    this.recipients.add(localJceKeyTransRecipientInfoGenerator);
    this.fact.addRecipientInfoGenerator(localJceKeyTransRecipientInfoGenerator);
  }

  /** @deprecated */
  public void addKEKRecipient(SecretKey paramSecretKey, byte[] paramArrayOfByte)
    throws IllegalArgumentException
  {
    JceKEKRecipientInfoGenerator localJceKEKRecipientInfoGenerator = new JceKEKRecipientInfoGenerator(paramArrayOfByte, paramSecretKey);
    this.recipients.add(localJceKEKRecipientInfoGenerator);
    this.fact.addRecipientInfoGenerator(localJceKEKRecipientInfoGenerator);
  }

  /** @deprecated */
  public void addKeyAgreementRecipient(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, X509Certificate paramX509Certificate, String paramString2, String paramString3)
    throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException
  {
    addKeyAgreementRecipient(paramString1, paramPrivateKey, paramPublicKey, paramX509Certificate, paramString2, paramString3);
  }

  /** @deprecated */
  public void addKeyAgreementRecipient(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, X509Certificate paramX509Certificate, String paramString2, Provider paramProvider)
    throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException
  {
    try
    {
      JceKeyAgreeRecipientInfoGenerator localJceKeyAgreeRecipientInfoGenerator = new JceKeyAgreeRecipientInfoGenerator(new ASN1ObjectIdentifier(paramString1), paramPrivateKey, paramPublicKey, new ASN1ObjectIdentifier(paramString2));
      localJceKeyAgreeRecipientInfoGenerator.addRecipient(paramX509Certificate);
      if (paramProvider != null)
        localJceKeyAgreeRecipientInfoGenerator.setProvider(paramProvider);
      this.fact.addRecipientInfoGenerator(localJceKeyAgreeRecipientInfoGenerator);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
      throw new NoSuchAlgorithmException("cannot set up generator: " + localCertificateEncodingException);
    }
    catch (CMSException localCMSException)
    {
      throw new NoSuchAlgorithmException("cannot set up generator: " + localCMSException);
    }
  }

  public void setBerEncodeRecipients(boolean paramBoolean)
  {
    this.fact.setBEREncodeRecipients(paramBoolean);
  }

  private MimeBodyPart make(MimeBodyPart paramMimeBodyPart, ASN1ObjectIdentifier paramASN1ObjectIdentifier, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    createSymmetricKeyGenerator(paramASN1ObjectIdentifier.getId(), paramProvider);
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new ContentEncryptor(paramMimeBodyPart, paramASN1ObjectIdentifier, paramInt, paramProvider), "application/pkcs7-mime; name=\"smime.p7m\"; smime-type=enveloped-data");
      localMimeBodyPart.addHeader("Content-Type", "application/pkcs7-mime; name=\"smime.p7m\"; smime-type=enveloped-data");
      localMimeBodyPart.addHeader("Content-Disposition", "attachment; filename=\"smime.p7m\"");
      localMimeBodyPart.addHeader("Content-Description", "S/MIME Encrypted Message");
      localMimeBodyPart.addHeader("Content-Transfer-Encoding", this.encoding);
      return localMimeBodyPart;
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("exception putting S/MIME message together.", localMessagingException);
    }
    catch (CMSException localCMSException)
    {
    }
    throw new SMIMEException("exception putting envelope together.", localCMSException);
  }

  private MimeBodyPart make(MimeBodyPart paramMimeBodyPart, OutputEncryptor paramOutputEncryptor)
    throws SMIMEException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new ContentEncryptor(paramMimeBodyPart, paramOutputEncryptor), "application/pkcs7-mime; name=\"smime.p7m\"; smime-type=enveloped-data");
      localMimeBodyPart.addHeader("Content-Type", "application/pkcs7-mime; name=\"smime.p7m\"; smime-type=enveloped-data");
      localMimeBodyPart.addHeader("Content-Disposition", "attachment; filename=\"smime.p7m\"");
      localMimeBodyPart.addHeader("Content-Description", "S/MIME Encrypted Message");
      localMimeBodyPart.addHeader("Content-Transfer-Encoding", this.encoding);
      return localMimeBodyPart;
    }
    catch (MessagingException localMessagingException)
    {
    }
    throw new SMIMEException("exception putting multi-part together.", localMessagingException);
  }

  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, OutputEncryptor paramOutputEncryptor)
    throws SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), paramOutputEncryptor);
  }

  public MimeBodyPart generate(MimeMessage paramMimeMessage, OutputEncryptor paramOutputEncryptor)
    throws SMIMEException
  {
    try
    {
      paramMimeMessage.saveChanges();
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("unable to save message", localMessagingException);
    }
    return make(makeContentBodyPart(paramMimeMessage), paramOutputEncryptor);
  }

  /** @deprecated */
  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), new ASN1ObjectIdentifier(paramString1), 0, SMIMEUtil.getProvider(paramString2));
  }

  /** @deprecated */
  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), new ASN1ObjectIdentifier(paramString), 0, paramProvider);
  }

  /** @deprecated */
  public MimeBodyPart generate(MimeMessage paramMimeMessage, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return generate(paramMimeMessage, paramString1, SMIMEUtil.getProvider(paramString2));
  }

  /** @deprecated */
  public MimeBodyPart generate(MimeMessage paramMimeMessage, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    try
    {
      paramMimeMessage.saveChanges();
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("unable to save message", localMessagingException);
    }
    return make(makeContentBodyPart(paramMimeMessage), new ASN1ObjectIdentifier(paramString), 0, paramProvider);
  }

  /** @deprecated */
  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, String paramString1, int paramInt, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return generate(paramMimeBodyPart, paramString1, paramInt, SMIMEUtil.getProvider(paramString2));
  }

  /** @deprecated */
  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), new ASN1ObjectIdentifier(paramString), paramInt, paramProvider);
  }

  /** @deprecated */
  public MimeBodyPart generate(MimeMessage paramMimeMessage, String paramString1, int paramInt, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return generate(paramMimeMessage, paramString1, paramInt, SMIMEUtil.getProvider(paramString2));
  }

  /** @deprecated */
  public MimeBodyPart generate(MimeMessage paramMimeMessage, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    try
    {
      paramMimeMessage.saveChanges();
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("unable to save message", localMessagingException);
    }
    return make(makeContentBodyPart(paramMimeMessage), new ASN1ObjectIdentifier(paramString), paramInt, paramProvider);
  }

  static
  {
    CommandMap.setDefaultCommandMap(addCommands(CommandMap.getDefaultCommandMap()));
  }

  private class ContentEncryptor
    implements SMIMEStreamingProcessor
  {
    private final MimeBodyPart _content;
    private OutputEncryptor _encryptor;
    private boolean _firstTime = true;

    ContentEncryptor(MimeBodyPart paramASN1ObjectIdentifier, ASN1ObjectIdentifier paramInt, int paramProvider, Provider arg5)
      throws CMSException
    {
      this._content = paramASN1ObjectIdentifier;
      Provider localProvider;
      if (paramProvider == 0)
        this._encryptor = new JceCMSContentEncryptorBuilder(paramInt).setProvider(localProvider).build();
      else
        this._encryptor = new JceCMSContentEncryptorBuilder(paramInt, paramProvider).setProvider(localProvider).build();
      if (localProvider != null)
      {
        Iterator localIterator = SMIMEEnvelopedGenerator.this.recipients.iterator();
        while (localIterator.hasNext())
        {
          RecipientInfoGenerator localRecipientInfoGenerator = (RecipientInfoGenerator)localIterator.next();
          try
          {
            if ((localRecipientInfoGenerator instanceof JceKeyTransRecipientInfoGenerator))
              ((JceKeyTransRecipientInfoGenerator)localRecipientInfoGenerator).setProvider(localProvider);
            else if ((localRecipientInfoGenerator instanceof JceKEKRecipientInfoGenerator))
              ((JceKEKRecipientInfoGenerator)localRecipientInfoGenerator).setProvider(localProvider);
          }
          catch (OperatorCreationException localOperatorCreationException)
          {
            throw new CMSException("cannot create recipient: " + localOperatorCreationException.getMessage(), localOperatorCreationException);
          }
        }
      }
    }

    ContentEncryptor(MimeBodyPart paramOutputEncryptor, OutputEncryptor arg3)
    {
      this._content = paramOutputEncryptor;
      Object localObject;
      this._encryptor = localObject;
    }

    public void write(OutputStream paramOutputStream)
      throws IOException
    {
      try
      {
        OutputStream localOutputStream;
        if (this._firstTime)
        {
          localOutputStream = SMIMEEnvelopedGenerator.this.fact.open(paramOutputStream, this._encryptor);
          this._firstTime = false;
        }
        else
        {
          localOutputStream = SMIMEEnvelopedGenerator.this.fact.regenerate(paramOutputStream, this._encryptor);
        }
        this._content.getDataHandler().setCommandMap(SMIMEEnvelopedGenerator.access$300(CommandMap.getDefaultCommandMap()));
        this._content.writeTo(localOutputStream);
        localOutputStream.close();
      }
      catch (MessagingException localMessagingException)
      {
        throw new SMIMEEnvelopedGenerator.WrappingIOException(localMessagingException.toString(), localMessagingException);
      }
      catch (CMSException localCMSException)
      {
        throw new SMIMEEnvelopedGenerator.WrappingIOException(localCMSException.toString(), localCMSException);
      }
    }
  }

  private class EnvelopedGenerator extends CMSEnvelopedDataStreamGenerator
  {
    private ASN1ObjectIdentifier dataType;
    private ASN1EncodableVector recipientInfos;

    private EnvelopedGenerator()
    {
    }

    protected OutputStream open(ASN1ObjectIdentifier paramASN1ObjectIdentifier, OutputStream paramOutputStream, ASN1EncodableVector paramASN1EncodableVector, OutputEncryptor paramOutputEncryptor)
      throws IOException
    {
      this.dataType = paramASN1ObjectIdentifier;
      this.recipientInfos = paramASN1EncodableVector;
      return super.open(paramASN1ObjectIdentifier, paramOutputStream, paramASN1EncodableVector, paramOutputEncryptor);
    }

    OutputStream regenerate(OutputStream paramOutputStream, OutputEncryptor paramOutputEncryptor)
      throws IOException
    {
      return super.open(this.dataType, paramOutputStream, this.recipientInfos, paramOutputEncryptor);
    }
  }

  private static class WrappingIOException extends IOException
  {
    private Throwable cause;

    WrappingIOException(String paramString, Throwable paramThrowable)
    {
      super();
      this.cause = paramThrowable;
    }

    public Throwable getCause()
    {
      return this.cause;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator
 * JD-Core Version:    0.6.0
 */