package org.bouncycastle.mail.smime;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimePart;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessable;
import org.bouncycastle.cms.CMSSignedData;

public class SMIMESigned extends CMSSignedData
{
  Object message;
  MimeBodyPart content;

  private static InputStream getInputStream(Part paramPart)
    throws MessagingException
  {
    try
    {
      if (paramPart.isMimeType("multipart/signed"))
        throw new MessagingException("attempt to create signed data object from multipart content - use MimeMultipart constructor.");
      return paramPart.getInputStream();
    }
    catch (IOException localIOException)
    {
    }
    throw new MessagingException("can't extract input stream: " + localIOException);
  }

  public SMIMESigned(MimeMultipart paramMimeMultipart)
    throws MessagingException, CMSException
  {
    super(new CMSProcessableBodyPartInbound(paramMimeMultipart.getBodyPart(0)), getInputStream(paramMimeMultipart.getBodyPart(1)));
    this.message = paramMimeMultipart;
    this.content = ((MimeBodyPart)paramMimeMultipart.getBodyPart(0));
  }

  public SMIMESigned(MimeMultipart paramMimeMultipart, String paramString)
    throws MessagingException, CMSException
  {
    super(new CMSProcessableBodyPartInbound(paramMimeMultipart.getBodyPart(0), paramString), getInputStream(paramMimeMultipart.getBodyPart(1)));
    this.message = paramMimeMultipart;
    this.content = ((MimeBodyPart)paramMimeMultipart.getBodyPart(0));
  }

  public SMIMESigned(Part paramPart)
    throws MessagingException, CMSException, SMIMEException
  {
    super(getInputStream(paramPart));
    this.message = paramPart;
    CMSProcessable localCMSProcessable = getSignedContent();
    if (localCMSProcessable != null)
    {
      byte[] arrayOfByte = (byte[])(byte[])localCMSProcessable.getContent();
      this.content = SMIMEUtil.toMimeBodyPart(arrayOfByte);
    }
  }

  public MimeBodyPart getContent()
  {
    return this.content;
  }

  public MimeMessage getContentAsMimeMessage(Session paramSession)
    throws MessagingException, IOException
  {
    Object localObject1 = getSignedContent().getContent();
    byte[] arrayOfByte = null;
    Object localObject2;
    if ((localObject1 instanceof byte[]))
    {
      arrayOfByte = (byte[])(byte[])localObject1;
    }
    else if ((localObject1 instanceof MimePart))
    {
      localObject2 = (MimePart)localObject1;
      ByteArrayOutputStream localByteArrayOutputStream;
      if (((MimePart)localObject2).getSize() > 0)
        localByteArrayOutputStream = new ByteArrayOutputStream(((MimePart)localObject2).getSize());
      else
        localByteArrayOutputStream = new ByteArrayOutputStream();
      ((MimePart)localObject2).writeTo(localByteArrayOutputStream);
      arrayOfByte = localByteArrayOutputStream.toByteArray();
    }
    else
    {
      localObject2 = "<null>";
      if (localObject1 != null)
        localObject2 = localObject1.getClass().getName();
      throw new MessagingException("Could not transfrom content of type " + (String)localObject2 + " into MimeMessage.");
    }
    if (arrayOfByte != null)
    {
      localObject2 = new ByteArrayInputStream(arrayOfByte);
      return new MimeMessage(paramSession, (InputStream)localObject2);
    }
    return (MimeMessage)null;
  }

  public Object getContentWithSignature()
  {
    return this.message;
  }

  static
  {
    MailcapCommandMap localMailcapCommandMap = (MailcapCommandMap)CommandMap.getDefaultCommandMap();
    localMailcapCommandMap.addMailcap("application/pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_mime");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_mime");
    localMailcapCommandMap.addMailcap("multipart/signed;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.multipart_signed");
    CommandMap.setDefaultCommandMap(localMailcapCommandMap);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.SMIMESigned
 * JD-Core Version:    0.6.0
 */