package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.activation.CommandMap;
import javax.activation.DataHandler;
import javax.activation.MailcapCommandMap;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cryptopro.CryptoProObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.teletrust.TeleTrusTObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSSignedDataStreamGenerator;
import org.bouncycastle.cms.SignerInfoGenerator;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.mail.smime.util.CRLFOutputStream;
import org.bouncycastle.util.Store;
import org.bouncycastle.x509.X509Store;

public class SMIMESignedGenerator extends SMIMEGenerator
{
  public static final String DIGEST_SHA1 = OIWObjectIdentifiers.idSHA1.getId();
  public static final String DIGEST_MD5 = PKCSObjectIdentifiers.md5.getId();
  public static final String DIGEST_SHA224 = NISTObjectIdentifiers.id_sha224.getId();
  public static final String DIGEST_SHA256 = NISTObjectIdentifiers.id_sha256.getId();
  public static final String DIGEST_SHA384 = NISTObjectIdentifiers.id_sha384.getId();
  public static final String DIGEST_SHA512 = NISTObjectIdentifiers.id_sha512.getId();
  public static final String DIGEST_GOST3411 = CryptoProObjectIdentifiers.gostR3411.getId();
  public static final String DIGEST_RIPEMD128 = TeleTrusTObjectIdentifiers.ripemd128.getId();
  public static final String DIGEST_RIPEMD160 = TeleTrusTObjectIdentifiers.ripemd160.getId();
  public static final String DIGEST_RIPEMD256 = TeleTrusTObjectIdentifiers.ripemd256.getId();
  public static final String ENCRYPTION_RSA = PKCSObjectIdentifiers.rsaEncryption.getId();
  public static final String ENCRYPTION_DSA = X9ObjectIdentifiers.id_dsa_with_sha1.getId();
  public static final String ENCRYPTION_ECDSA = X9ObjectIdentifiers.ecdsa_with_SHA1.getId();
  public static final String ENCRYPTION_RSA_PSS = PKCSObjectIdentifiers.id_RSASSA_PSS.getId();
  public static final String ENCRYPTION_GOST3410 = CryptoProObjectIdentifiers.gostR3410_94.getId();
  public static final String ENCRYPTION_ECGOST3410 = CryptoProObjectIdentifiers.gostR3410_2001.getId();
  private static final String CERTIFICATE_MANAGEMENT_CONTENT = "application/pkcs7-mime; name=smime.p7c; smime-type=certs-only";
  private static final String DETACHED_SIGNATURE_TYPE = "application/pkcs7-signature; name=smime.p7s; smime-type=signed-data";
  private static final String ENCAPSULATED_SIGNED_CONTENT_TYPE = "application/pkcs7-mime; name=smime.p7m; smime-type=signed-data";
  private final String _defaultContentTransferEncoding;
  private List _certStores = new ArrayList();
  private List certStores = new ArrayList();
  private List crlStores = new ArrayList();
  private List attrCertStores = new ArrayList();
  private List signerInfoGens = new ArrayList();
  private List _signers = new ArrayList();
  private List _oldSigners = new ArrayList();
  private List _attributeCerts = new ArrayList();
  private Map _digests = new HashMap();

  private static MailcapCommandMap addCommands(CommandMap paramCommandMap)
  {
    MailcapCommandMap localMailcapCommandMap = (MailcapCommandMap)paramCommandMap;
    localMailcapCommandMap.addMailcap("application/pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_mime");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_mime");
    localMailcapCommandMap.addMailcap("multipart/signed;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.multipart_signed");
    return localMailcapCommandMap;
  }

  public SMIMESignedGenerator()
  {
    this._defaultContentTransferEncoding = "7bit";
  }

  public SMIMESignedGenerator(String paramString)
  {
    this._defaultContentTransferEncoding = paramString;
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString)
    throws IllegalArgumentException
  {
    this._signers.add(new Signer(paramPrivateKey, paramX509Certificate, paramString, null, null));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2)
    throws IllegalArgumentException
  {
    this._signers.add(new Signer(paramPrivateKey, paramX509Certificate, paramString1, paramString2, null, null));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    this._signers.add(new Signer(paramPrivateKey, paramX509Certificate, paramString, paramAttributeTable1, paramAttributeTable2));
  }

  /** @deprecated */
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    this._signers.add(new Signer(paramPrivateKey, paramX509Certificate, paramString1, paramString2, paramAttributeTable1, paramAttributeTable2));
  }

  public void addSigners(SignerInformationStore paramSignerInformationStore)
  {
    Iterator localIterator = paramSignerInformationStore.getSigners().iterator();
    while (localIterator.hasNext())
      this._oldSigners.add(localIterator.next());
  }

  public void addSignerInfoGenerator(SignerInfoGenerator paramSignerInfoGenerator)
  {
    this.signerInfoGens.add(paramSignerInfoGenerator);
  }

  /** @deprecated */
  public void addCertificatesAndCRLs(CertStore paramCertStore)
    throws CertStoreException, SMIMEException
  {
    this._certStores.add(paramCertStore);
  }

  public void addCertificates(Store paramStore)
  {
    this.certStores.add(paramStore);
  }

  public void addCRLs(Store paramStore)
  {
    this.crlStores.add(paramStore);
  }

  public void addAttributeCertificates(Store paramStore)
  {
    this.attrCertStores.add(paramStore);
  }

  /** @deprecated */
  public void addAttributeCertificates(X509Store paramX509Store)
    throws CMSException
  {
    this._attributeCerts.add(paramX509Store);
  }

  private void addHashHeader(StringBuffer paramStringBuffer, List paramList)
  {
    int i = 0;
    Iterator localIterator = paramList.iterator();
    HashSet localHashSet = new HashSet();
    Object localObject;
    while (localIterator.hasNext())
    {
      localObject = localIterator.next();
      String str;
      if ((localObject instanceof Signer))
        str = ((Signer)localObject).getDigestOID();
      else if ((localObject instanceof SignerInformation))
        str = ((SignerInformation)localObject).getDigestAlgOID();
      else
        str = ((SignerInfoGenerator)localObject).getDigestAlgorithm().getAlgorithm().getId();
      if (str.equals(DIGEST_SHA1))
        localHashSet.add("sha1");
      else if (str.equals(DIGEST_MD5))
        localHashSet.add("md5");
      else if (str.equals(DIGEST_SHA224))
        localHashSet.add("sha224");
      else if (str.equals(DIGEST_SHA256))
        localHashSet.add("sha256");
      else if (str.equals(DIGEST_SHA384))
        localHashSet.add("sha384");
      else if (str.equals(DIGEST_SHA512))
        localHashSet.add("sha512");
      else if (str.equals(DIGEST_GOST3411))
        localHashSet.add("gostr3411-94");
      else
        localHashSet.add("unknown");
    }
    localIterator = localHashSet.iterator();
    while (localIterator.hasNext())
    {
      localObject = (String)localIterator.next();
      if (i == 0)
      {
        if (localHashSet.size() != 1)
          paramStringBuffer.append("; micalg=\"");
        else
          paramStringBuffer.append("; micalg=");
      }
      else
        paramStringBuffer.append(',');
      paramStringBuffer.append((String)localObject);
      i++;
    }
    if ((i != 0) && (localHashSet.size() != 1))
      paramStringBuffer.append('"');
  }

  private MimeMultipart make(MimeBodyPart paramMimeBodyPart, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new ContentSigner(paramMimeBodyPart, false, paramProvider), "application/pkcs7-signature; name=smime.p7s; smime-type=signed-data");
      localMimeBodyPart.addHeader("Content-Type", "application/pkcs7-signature; name=smime.p7s; smime-type=signed-data");
      localMimeBodyPart.addHeader("Content-Disposition", "attachment; filename=\"smime.p7s\"");
      localMimeBodyPart.addHeader("Content-Description", "S/MIME Cryptographic Signature");
      localMimeBodyPart.addHeader("Content-Transfer-Encoding", this.encoding);
      StringBuffer localStringBuffer = new StringBuffer("signed; protocol=\"application/pkcs7-signature\"");
      ArrayList localArrayList = new ArrayList(this._signers);
      localArrayList.addAll(this._oldSigners);
      localArrayList.addAll(this.signerInfoGens);
      addHashHeader(localStringBuffer, localArrayList);
      MimeMultipart localMimeMultipart = new MimeMultipart(localStringBuffer.toString());
      localMimeMultipart.addBodyPart(paramMimeBodyPart);
      localMimeMultipart.addBodyPart(localMimeBodyPart);
      return localMimeMultipart;
    }
    catch (MessagingException localMessagingException)
    {
    }
    throw new SMIMEException("exception putting multi-part together.", localMessagingException);
  }

  private MimeMultipart make(MimeBodyPart paramMimeBodyPart)
    throws SMIMEException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new ContentSigner(paramMimeBodyPart, false), "application/pkcs7-signature; name=smime.p7s; smime-type=signed-data");
      localMimeBodyPart.addHeader("Content-Type", "application/pkcs7-signature; name=smime.p7s; smime-type=signed-data");
      localMimeBodyPart.addHeader("Content-Disposition", "attachment; filename=\"smime.p7s\"");
      localMimeBodyPart.addHeader("Content-Description", "S/MIME Cryptographic Signature");
      localMimeBodyPart.addHeader("Content-Transfer-Encoding", this.encoding);
      StringBuffer localStringBuffer = new StringBuffer("signed; protocol=\"application/pkcs7-signature\"");
      ArrayList localArrayList = new ArrayList(this._signers);
      localArrayList.addAll(this._oldSigners);
      localArrayList.addAll(this.signerInfoGens);
      addHashHeader(localStringBuffer, localArrayList);
      MimeMultipart localMimeMultipart = new MimeMultipart(localStringBuffer.toString());
      localMimeMultipart.addBodyPart(paramMimeBodyPart);
      localMimeMultipart.addBodyPart(localMimeBodyPart);
      return localMimeMultipart;
    }
    catch (MessagingException localMessagingException)
    {
    }
    throw new SMIMEException("exception putting multi-part together.", localMessagingException);
  }

  private MimeBodyPart makeEncapsulated(MimeBodyPart paramMimeBodyPart, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new ContentSigner(paramMimeBodyPart, true, paramProvider), "application/pkcs7-mime; name=smime.p7m; smime-type=signed-data");
      localMimeBodyPart.addHeader("Content-Type", "application/pkcs7-mime; name=smime.p7m; smime-type=signed-data");
      localMimeBodyPart.addHeader("Content-Disposition", "attachment; filename=\"smime.p7m\"");
      localMimeBodyPart.addHeader("Content-Description", "S/MIME Cryptographic Signed Data");
      localMimeBodyPart.addHeader("Content-Transfer-Encoding", this.encoding);
      return localMimeBodyPart;
    }
    catch (MessagingException localMessagingException)
    {
    }
    throw new SMIMEException("exception putting body part together.", localMessagingException);
  }

  private MimeBodyPart makeEncapsulated(MimeBodyPart paramMimeBodyPart)
    throws SMIMEException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new ContentSigner(paramMimeBodyPart, true), "application/pkcs7-mime; name=smime.p7m; smime-type=signed-data");
      localMimeBodyPart.addHeader("Content-Type", "application/pkcs7-mime; name=smime.p7m; smime-type=signed-data");
      localMimeBodyPart.addHeader("Content-Disposition", "attachment; filename=\"smime.p7m\"");
      localMimeBodyPart.addHeader("Content-Description", "S/MIME Cryptographic Signed Data");
      localMimeBodyPart.addHeader("Content-Transfer-Encoding", this.encoding);
      return localMimeBodyPart;
    }
    catch (MessagingException localMessagingException)
    {
    }
    throw new SMIMEException("exception putting body part together.", localMessagingException);
  }

  public Map getGeneratedDigests()
  {
    return new HashMap(this._digests);
  }

  /** @deprecated */
  public MimeMultipart generate(MimeBodyPart paramMimeBodyPart, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), SMIMEUtil.getProvider(paramString));
  }

  public MimeMultipart generate(MimeBodyPart paramMimeBodyPart, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), paramProvider);
  }

  public MimeMultipart generate(MimeMessage paramMimeMessage, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return generate(paramMimeMessage, SMIMEUtil.getProvider(paramString));
  }

  public MimeMultipart generate(MimeMessage paramMimeMessage, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    try
    {
      paramMimeMessage.saveChanges();
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("unable to save message", localMessagingException);
    }
    return make(makeContentBodyPart(paramMimeMessage), paramProvider);
  }

  public MimeMultipart generate(MimeBodyPart paramMimeBodyPart)
    throws SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart));
  }

  public MimeBodyPart generateEncapsulated(MimeBodyPart paramMimeBodyPart)
    throws SMIMEException
  {
    return makeEncapsulated(makeContentBodyPart(paramMimeBodyPart));
  }

  /** @deprecated */
  public MimeBodyPart generateEncapsulated(MimeBodyPart paramMimeBodyPart, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return makeEncapsulated(makeContentBodyPart(paramMimeBodyPart), SMIMEUtil.getProvider(paramString));
  }

  /** @deprecated */
  public MimeBodyPart generateEncapsulated(MimeBodyPart paramMimeBodyPart, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return makeEncapsulated(makeContentBodyPart(paramMimeBodyPart), paramProvider);
  }

  /** @deprecated */
  public MimeBodyPart generateEncapsulated(MimeMessage paramMimeMessage, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return generateEncapsulated(paramMimeMessage, SMIMEUtil.getProvider(paramString));
  }

  /** @deprecated */
  public MimeBodyPart generateEncapsulated(MimeMessage paramMimeMessage, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    try
    {
      paramMimeMessage.saveChanges();
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("unable to save message", localMessagingException);
    }
    return makeEncapsulated(makeContentBodyPart(paramMimeMessage), paramProvider);
  }

  public MimeBodyPart generateCertificateManagement(String paramString)
    throws SMIMEException, NoSuchProviderException
  {
    return generateCertificateManagement(SMIMEUtil.getProvider(paramString));
  }

  public MimeBodyPart generateCertificateManagement(Provider paramProvider)
    throws SMIMEException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new ContentSigner(null, true, paramProvider), "application/pkcs7-mime; name=smime.p7c; smime-type=certs-only");
      localMimeBodyPart.addHeader("Content-Type", "application/pkcs7-mime; name=smime.p7c; smime-type=certs-only");
      localMimeBodyPart.addHeader("Content-Disposition", "attachment; filename=\"smime.p7c\"");
      localMimeBodyPart.addHeader("Content-Description", "S/MIME Certificate Management Message");
      localMimeBodyPart.addHeader("Content-Transfer-Encoding", this.encoding);
      return localMimeBodyPart;
    }
    catch (MessagingException localMessagingException)
    {
    }
    throw new SMIMEException("exception putting body part together.", localMessagingException);
  }

  static
  {
    CommandMap.setDefaultCommandMap(addCommands(CommandMap.getDefaultCommandMap()));
  }

  private class ContentSigner
    implements SMIMEStreamingProcessor
  {
    private final MimeBodyPart content;
    private final boolean encapsulate;
    private final Provider provider;
    private final boolean noProvider;

    ContentSigner(MimeBodyPart paramBoolean, boolean paramProvider, Provider arg4)
    {
      this.content = paramBoolean;
      this.encapsulate = paramProvider;
      Object localObject;
      this.provider = localObject;
      this.noProvider = false;
    }

    ContentSigner(MimeBodyPart paramBoolean, boolean arg3)
    {
      this.content = paramBoolean;
      boolean bool;
      this.encapsulate = bool;
      this.provider = null;
      this.noProvider = true;
    }

    protected CMSSignedDataStreamGenerator getGenerator()
      throws CMSException, CertStoreException, InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException
    {
      CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
      Iterator localIterator = SMIMESignedGenerator.this._certStores.iterator();
      while (localIterator.hasNext())
        localCMSSignedDataStreamGenerator.addCertificatesAndCRLs((CertStore)localIterator.next());
      localIterator = SMIMESignedGenerator.this.certStores.iterator();
      while (localIterator.hasNext())
        localCMSSignedDataStreamGenerator.addCertificates((Store)localIterator.next());
      localIterator = SMIMESignedGenerator.this.crlStores.iterator();
      while (localIterator.hasNext())
        localCMSSignedDataStreamGenerator.addCRLs((Store)localIterator.next());
      localIterator = SMIMESignedGenerator.this.attrCertStores.iterator();
      while (localIterator.hasNext())
        localCMSSignedDataStreamGenerator.addAttributeCertificates((Store)localIterator.next());
      localIterator = SMIMESignedGenerator.this._attributeCerts.iterator();
      while (localIterator.hasNext())
        localCMSSignedDataStreamGenerator.addAttributeCertificates((X509Store)localIterator.next());
      localIterator = SMIMESignedGenerator.this._signers.iterator();
      while (localIterator.hasNext())
      {
        SMIMESignedGenerator.Signer localSigner = (SMIMESignedGenerator.Signer)localIterator.next();
        if (localSigner.getEncryptionOID() != null)
          localCMSSignedDataStreamGenerator.addSigner(localSigner.getKey(), localSigner.getCert(), localSigner.getEncryptionOID(), localSigner.getDigestOID(), localSigner.getSignedAttr(), localSigner.getUnsignedAttr(), this.provider);
        else
          localCMSSignedDataStreamGenerator.addSigner(localSigner.getKey(), localSigner.getCert(), localSigner.getDigestOID(), localSigner.getSignedAttr(), localSigner.getUnsignedAttr(), this.provider);
      }
      localIterator = SMIMESignedGenerator.this.signerInfoGens.iterator();
      while (localIterator.hasNext())
        localCMSSignedDataStreamGenerator.addSignerInfoGenerator((SignerInfoGenerator)localIterator.next());
      localCMSSignedDataStreamGenerator.addSigners(new SignerInformationStore(SMIMESignedGenerator.this._oldSigners));
      return localCMSSignedDataStreamGenerator;
    }

    private void writeBodyPart(OutputStream paramOutputStream, MimeBodyPart paramMimeBodyPart)
      throws IOException, MessagingException
    {
      if ((paramMimeBodyPart.getContent() instanceof Multipart))
      {
        Multipart localMultipart = (Multipart)paramMimeBodyPart.getContent();
        ContentType localContentType = new ContentType(localMultipart.getContentType());
        String str = "--" + localContentType.getParameter("boundary");
        SMIMEUtil.LineOutputStream localLineOutputStream = new SMIMEUtil.LineOutputStream(paramOutputStream);
        Enumeration localEnumeration = paramMimeBodyPart.getAllHeaderLines();
        while (localEnumeration.hasMoreElements())
          localLineOutputStream.writeln((String)localEnumeration.nextElement());
        localLineOutputStream.writeln();
        SMIMEUtil.outputPreamble(localLineOutputStream, paramMimeBodyPart, str);
        for (int i = 0; i < localMultipart.getCount(); i++)
        {
          localLineOutputStream.writeln(str);
          writeBodyPart(paramOutputStream, (MimeBodyPart)localMultipart.getBodyPart(i));
          localLineOutputStream.writeln();
        }
        localLineOutputStream.writeln(str + "--");
      }
      else
      {
        if (SMIMEUtil.isCanonicalisationRequired(paramMimeBodyPart, SMIMESignedGenerator.this._defaultContentTransferEncoding))
          paramOutputStream = new CRLFOutputStream(paramOutputStream);
        paramMimeBodyPart.writeTo(paramOutputStream);
      }
    }

    public void write(OutputStream paramOutputStream)
      throws IOException
    {
      try
      {
        CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = getGenerator();
        OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(paramOutputStream, this.encapsulate);
        if (this.content != null)
          if (!this.encapsulate)
          {
            writeBodyPart(localOutputStream, this.content);
          }
          else
          {
            this.content.getDataHandler().setCommandMap(SMIMESignedGenerator.access$900(CommandMap.getDefaultCommandMap()));
            this.content.writeTo(localOutputStream);
          }
        localOutputStream.close();
        SMIMESignedGenerator.access$1002(SMIMESignedGenerator.this, localCMSSignedDataStreamGenerator.getGeneratedDigests());
      }
      catch (MessagingException localMessagingException)
      {
        throw new IOException(localMessagingException.toString());
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        throw new IOException(localNoSuchAlgorithmException.toString());
      }
      catch (NoSuchProviderException localNoSuchProviderException)
      {
        throw new IOException(localNoSuchProviderException.toString());
      }
      catch (CMSException localCMSException)
      {
        throw new IOException(localCMSException.toString());
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        throw new IOException(localInvalidKeyException.toString());
      }
      catch (CertStoreException localCertStoreException)
      {
        throw new IOException(localCertStoreException.toString());
      }
    }
  }

  private class Signer
  {
    final PrivateKey key;
    final X509Certificate cert;
    final String encryptionOID;
    final String digestOID;
    final AttributeTable signedAttr;
    final AttributeTable unsignedAttr;

    Signer(PrivateKey paramX509Certificate, X509Certificate paramString, String paramAttributeTable1, AttributeTable paramAttributeTable2, AttributeTable arg6)
    {
      this(paramX509Certificate, paramString, null, paramAttributeTable1, paramAttributeTable2, localAttributeTable);
    }

    Signer(PrivateKey paramX509Certificate, X509Certificate paramString1, String paramString2, String paramAttributeTable1, AttributeTable paramAttributeTable2, AttributeTable arg7)
    {
      this.key = paramX509Certificate;
      this.cert = paramString1;
      this.encryptionOID = paramString2;
      this.digestOID = paramAttributeTable1;
      this.signedAttr = paramAttributeTable2;
      Object localObject;
      this.unsignedAttr = localObject;
    }

    public X509Certificate getCert()
    {
      return this.cert;
    }

    public String getEncryptionOID()
    {
      return this.encryptionOID;
    }

    public String getDigestOID()
    {
      return this.digestOID;
    }

    public PrivateKey getKey()
    {
      return this.key;
    }

    public AttributeTable getSignedAttr()
    {
      return this.signedAttr;
    }

    public AttributeTable getUnsignedAttr()
    {
      return this.unsignedAttr;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.SMIMESignedGenerator
 * JD-Core Version:    0.6.0
 */