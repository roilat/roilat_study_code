package org.bouncycastle.mail.smime;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSSignedDataParser;
import org.bouncycastle.cms.CMSTypedStream;

public class SMIMESignedParser extends CMSSignedDataParser
{
  Object message;
  MimeBodyPart content;

  private static InputStream getInputStream(Part paramPart)
    throws MessagingException
  {
    try
    {
      if (paramPart.isMimeType("multipart/signed"))
        throw new MessagingException("attempt to create signed data object from multipart content - use MimeMultipart constructor.");
      return paramPart.getInputStream();
    }
    catch (IOException localIOException)
    {
    }
    throw new MessagingException("can't extract input stream: " + localIOException);
  }

  private static File getTmpFile()
    throws MessagingException
  {
    try
    {
      return File.createTempFile("bcMail", ".mime");
    }
    catch (IOException localIOException)
    {
    }
    throw new MessagingException("can't extract input stream: " + localIOException);
  }

  private static CMSTypedStream getSignedInputStream(BodyPart paramBodyPart, String paramString, File paramFile)
    throws MessagingException
  {
    try
    {
      BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramFile));
      SMIMEUtil.outputBodyPart(localBufferedOutputStream, paramBodyPart, paramString);
      localBufferedOutputStream.close();
      TemporaryFileInputStream localTemporaryFileInputStream = new TemporaryFileInputStream(paramFile);
      return new CMSTypedStream(localTemporaryFileInputStream);
    }
    catch (IOException localIOException)
    {
    }
    throw new MessagingException("can't extract input stream: " + localIOException);
  }

  public SMIMESignedParser(MimeMultipart paramMimeMultipart)
    throws MessagingException, CMSException
  {
    this(paramMimeMultipart, getTmpFile());
  }

  public SMIMESignedParser(MimeMultipart paramMimeMultipart, File paramFile)
    throws MessagingException, CMSException
  {
    this(paramMimeMultipart, "7bit", paramFile);
  }

  public SMIMESignedParser(MimeMultipart paramMimeMultipart, String paramString)
    throws MessagingException, CMSException
  {
    this(paramMimeMultipart, paramString, getTmpFile());
  }

  public SMIMESignedParser(MimeMultipart paramMimeMultipart, String paramString, File paramFile)
    throws MessagingException, CMSException
  {
    super(getSignedInputStream(paramMimeMultipart.getBodyPart(0), paramString, paramFile), getInputStream(paramMimeMultipart.getBodyPart(1)));
    this.message = paramMimeMultipart;
    this.content = ((MimeBodyPart)paramMimeMultipart.getBodyPart(0));
    drainContent();
  }

  public SMIMESignedParser(Part paramPart)
    throws MessagingException, CMSException, SMIMEException
  {
    super(getInputStream(paramPart));
    this.message = paramPart;
    CMSTypedStream localCMSTypedStream = getSignedContent();
    if (localCMSTypedStream != null)
      this.content = SMIMEUtil.toWriteOnceBodyPart(localCMSTypedStream);
  }

  public SMIMESignedParser(Part paramPart, File paramFile)
    throws MessagingException, CMSException, SMIMEException
  {
    super(getInputStream(paramPart));
    this.message = paramPart;
    CMSTypedStream localCMSTypedStream = getSignedContent();
    if (localCMSTypedStream != null)
      this.content = SMIMEUtil.toMimeBodyPart(localCMSTypedStream, paramFile);
  }

  public MimeBodyPart getContent()
  {
    return this.content;
  }

  public MimeMessage getContentAsMimeMessage(Session paramSession)
    throws MessagingException, IOException
  {
    if ((this.message instanceof MimeMultipart))
    {
      BodyPart localBodyPart = ((MimeMultipart)this.message).getBodyPart(0);
      return new MimeMessage(paramSession, localBodyPart.getInputStream());
    }
    return new MimeMessage(paramSession, getSignedContent().getContentStream());
  }

  public Object getContentWithSignature()
  {
    return this.message;
  }

  private void drainContent()
    throws CMSException
  {
    try
    {
      getSignedContent().drain();
    }
    catch (IOException localIOException)
    {
      throw new CMSException("unable to read content for verification: " + localIOException, localIOException);
    }
  }

  static
  {
    MailcapCommandMap localMailcapCommandMap = (MailcapCommandMap)CommandMap.getDefaultCommandMap();
    localMailcapCommandMap.addMailcap("application/pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_mime");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_mime");
    localMailcapCommandMap.addMailcap("multipart/signed;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.multipart_signed");
    CommandMap.setDefaultCommandMap(localMailcapCommandMap);
  }

  private static class TemporaryFileInputStream extends BufferedInputStream
  {
    private final File _file;

    TemporaryFileInputStream(File paramFile)
      throws FileNotFoundException
    {
      super();
      this._file = paramFile;
    }

    public void close()
      throws IOException
    {
      super.close();
      this._file.delete();
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.SMIMESignedParser
 * JD-Core Version:    0.6.0
 */