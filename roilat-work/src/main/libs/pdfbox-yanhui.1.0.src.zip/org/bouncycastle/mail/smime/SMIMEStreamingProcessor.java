package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface SMIMEStreamingProcessor
{
  public abstract void write(OutputStream paramOutputStream)
    throws IOException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.SMIMEStreamingProcessor
 * JD-Core Version:    0.6.0
 */