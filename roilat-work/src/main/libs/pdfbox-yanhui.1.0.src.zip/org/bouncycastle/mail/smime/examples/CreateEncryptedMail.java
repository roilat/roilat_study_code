package org.bouncycastle.mail.smime.examples;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.Properties;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;

public class CreateEncryptedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    if (paramArrayOfString.length != 2)
    {
      System.err.println("usage: CreateEncryptedMail pkcs12Keystore password");
      System.exit(0);
    }
    KeyStore localKeyStore = KeyStore.getInstance("PKCS12", "BC");
    localKeyStore.load(new FileInputStream(paramArrayOfString[0]), paramArrayOfString[1].toCharArray());
    Enumeration localEnumeration = localKeyStore.aliases();
    Object localObject1 = null;
    while (localEnumeration.hasMoreElements())
    {
      localObject2 = (String)localEnumeration.nextElement();
      if (localKeyStore.isKeyEntry((String)localObject2))
        localObject1 = localObject2;
    }
    if (localObject1 == null)
    {
      System.err.println("can't find a private key!");
      System.exit(0);
    }
    Object localObject2 = localKeyStore.getCertificateChain(localObject1);
    SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
    localSMIMEEnvelopedGenerator.addKeyTransRecipient((X509Certificate)localObject2[0]);
    MimeBodyPart localMimeBodyPart1 = new MimeBodyPart();
    localMimeBodyPart1.setText("Hello world!");
    MimeBodyPart localMimeBodyPart2 = localSMIMEEnvelopedGenerator.generate(localMimeBodyPart1, SMIMEEnvelopedGenerator.RC2_CBC, "BC");
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    InternetAddress localInternetAddress1 = new InternetAddress("\"Eric H. Echidna\"<eric@bouncycastle.org>");
    InternetAddress localInternetAddress2 = new InternetAddress("example@bouncycastle.org");
    MimeMessage localMimeMessage = new MimeMessage(localSession);
    localMimeMessage.setFrom(localInternetAddress1);
    localMimeMessage.setRecipient(Message.RecipientType.TO, localInternetAddress2);
    localMimeMessage.setSubject("example encrypted message");
    localMimeMessage.setContent(localMimeBodyPart2.getContent(), localMimeBodyPart2.getContentType());
    localMimeMessage.saveChanges();
    localMimeMessage.writeTo(new FileOutputStream("encrypted.message"));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.CreateEncryptedMail
 * JD-Core Version:    0.6.0
 */