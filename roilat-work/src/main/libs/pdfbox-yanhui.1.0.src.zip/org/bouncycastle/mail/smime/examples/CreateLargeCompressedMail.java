package org.bouncycastle.mail.smime.examples;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.mail.smime.SMIMECompressedGenerator;

public class CreateLargeCompressedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    SMIMECompressedGenerator localSMIMECompressedGenerator = new SMIMECompressedGenerator();
    MimeBodyPart localMimeBodyPart1 = new MimeBodyPart();
    localMimeBodyPart1.setDataHandler(new DataHandler(new FileDataSource(new File(paramArrayOfString[0]))));
    localMimeBodyPart1.setHeader("Content-Type", "application/octet-stream");
    localMimeBodyPart1.setHeader("Content-Transfer-Encoding", "binary");
    MimeBodyPart localMimeBodyPart2 = localSMIMECompressedGenerator.generate(localMimeBodyPart1, "1.2.840.113549.1.9.16.3.8");
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    InternetAddress localInternetAddress1 = new InternetAddress("\"Eric H. Echidna\"<eric@bouncycastle.org>");
    InternetAddress localInternetAddress2 = new InternetAddress("example@bouncycastle.org");
    MimeMessage localMimeMessage = new MimeMessage(localSession);
    localMimeMessage.setFrom(localInternetAddress1);
    localMimeMessage.setRecipient(Message.RecipientType.TO, localInternetAddress2);
    localMimeMessage.setSubject("example compressed message");
    localMimeMessage.setContent(localMimeBodyPart2.getContent(), localMimeBodyPart2.getContentType());
    localMimeMessage.saveChanges();
    localMimeMessage.writeTo(new FileOutputStream("compressed.message"));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.CreateLargeCompressedMail
 * JD-Core Version:    0.6.0
 */