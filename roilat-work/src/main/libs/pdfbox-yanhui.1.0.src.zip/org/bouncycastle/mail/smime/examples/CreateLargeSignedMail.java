package org.bouncycastle.mail.smime.examples;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.smime.SMIMECapabilitiesAttribute;
import org.bouncycastle.asn1.smime.SMIMECapability;
import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
import org.bouncycastle.asn1.smime.SMIMEEncryptionKeyPreferenceAttribute;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AuthorityKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;
import org.bouncycastle.mail.smime.SMIMESignedGenerator;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

public class CreateLargeSignedMail
{
  static int serialNo = 1;

  static AuthorityKeyIdentifier createAuthorityKeyId(PublicKey paramPublicKey)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramPublicKey.getEncoded());
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo((ASN1Sequence)new ASN1InputStream(localByteArrayInputStream).readObject());
    return new AuthorityKeyIdentifier(localSubjectPublicKeyInfo);
  }

  static SubjectKeyIdentifier createSubjectKeyId(PublicKey paramPublicKey)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramPublicKey.getEncoded());
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo((ASN1Sequence)new ASN1InputStream(localByteArrayInputStream).readObject());
    return new SubjectKeyIdentifier(localSubjectPublicKeyInfo);
  }

  static X509Certificate makeCertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2)
    throws GeneralSecurityException, IOException, OperatorCreationException
  {
    PublicKey localPublicKey1 = paramKeyPair1.getPublic();
    PrivateKey localPrivateKey = paramKeyPair2.getPrivate();
    PublicKey localPublicKey2 = paramKeyPair2.getPublic();
    JcaX509v3CertificateBuilder localJcaX509v3CertificateBuilder = new JcaX509v3CertificateBuilder(new X500Name(paramString2), BigInteger.valueOf(serialNo++), new Date(System.currentTimeMillis()), new Date(System.currentTimeMillis() + 8640000000L), new X500Name(paramString1), localPublicKey1);
    localJcaX509v3CertificateBuilder.addExtension(X509Extension.subjectKeyIdentifier, false, createSubjectKeyId(localPublicKey1));
    localJcaX509v3CertificateBuilder.addExtension(X509Extension.authorityKeyIdentifier, false, createAuthorityKeyId(localPublicKey2));
    return new JcaX509CertificateConverter().setProvider("BC").getCertificate(localJcaX509v3CertificateBuilder.build(new JcaContentSignerBuilder("MD5withRSA").setProvider("BC").build(localPrivateKey)));
  }

  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
    localKeyPairGenerator.initialize(1024, new SecureRandom());
    String str1 = "O=Bouncy Castle, C=AU";
    KeyPair localKeyPair1 = localKeyPairGenerator.generateKeyPair();
    X509Certificate localX509Certificate1 = makeCertificate(localKeyPair1, str1, localKeyPair1, str1);
    String str2 = "CN=Eric H. Echidna, E=eric@bouncycastle.org, O=Bouncy Castle, C=AU";
    KeyPair localKeyPair2 = localKeyPairGenerator.generateKeyPair();
    X509Certificate localX509Certificate2 = makeCertificate(localKeyPair2, str2, localKeyPair1, str1);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(localX509Certificate2);
    localArrayList.add(localX509Certificate1);
    JcaCertStore localJcaCertStore = new JcaCertStore(localArrayList);
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    SMIMECapabilityVector localSMIMECapabilityVector = new SMIMECapabilityVector();
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_EDE3_CBC);
    localSMIMECapabilityVector.addCapability(SMIMECapability.rC2_CBC, 128);
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_CBC);
    localASN1EncodableVector.add(new SMIMECapabilitiesAttribute(localSMIMECapabilityVector));
    IssuerAndSerialNumber localIssuerAndSerialNumber = new IssuerAndSerialNumber(new X500Name(str1), localX509Certificate2.getSerialNumber());
    localASN1EncodableVector.add(new SMIMEEncryptionKeyPreferenceAttribute(localIssuerAndSerialNumber));
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder().setProvider("BC").setSignedAttributeGenerator(new AttributeTable(localASN1EncodableVector)).build("SHA1withRSA", localKeyPair2.getPrivate(), localX509Certificate2));
    localSMIMESignedGenerator.addCertificates(localJcaCertStore);
    MimeBodyPart localMimeBodyPart = new MimeBodyPart();
    localMimeBodyPart.setDataHandler(new DataHandler(new FileDataSource(new File(paramArrayOfString[0]))));
    localMimeBodyPart.setHeader("Content-Type", "application/octet-stream");
    localMimeBodyPart.setHeader("Content-Transfer-Encoding", "base64");
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(localMimeBodyPart);
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    InternetAddress localInternetAddress1 = new InternetAddress("\"Eric H. Echidna\"<eric@bouncycastle.org>");
    InternetAddress localInternetAddress2 = new InternetAddress("example@bouncycastle.org");
    MimeMessage localMimeMessage = new MimeMessage(localSession);
    localMimeMessage.setFrom(localInternetAddress1);
    localMimeMessage.setRecipient(Message.RecipientType.TO, localInternetAddress2);
    localMimeMessage.setSubject("example signed message");
    localMimeMessage.setContent(localMimeMultipart, localMimeMultipart.getContentType());
    localMimeMessage.saveChanges();
    localMimeMessage.writeTo(new FileOutputStream("signed.message"));
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.CreateLargeSignedMail
 * JD-Core Version:    0.6.0
 */