package org.bouncycastle.mail.smime.examples;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.KeyStore;
import java.util.Enumeration;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;

public class ExampleUtils
{
  public static void dumpContent(MimeBodyPart paramMimeBodyPart, String paramString)
    throws MessagingException, IOException
  {
    System.out.println("content type: " + paramMimeBodyPart.getContentType());
    FileOutputStream localFileOutputStream = new FileOutputStream(paramString);
    InputStream localInputStream = paramMimeBodyPart.getInputStream();
    byte[] arrayOfByte = new byte[10000];
    int i;
    while ((i = localInputStream.read(arrayOfByte, 0, arrayOfByte.length)) > 0)
      localFileOutputStream.write(arrayOfByte, 0, i);
    localFileOutputStream.close();
  }

  public static String findKeyAlias(KeyStore paramKeyStore, String paramString, char[] paramArrayOfChar)
    throws Exception
  {
    paramKeyStore.load(new FileInputStream(paramString), paramArrayOfChar);
    Enumeration localEnumeration = paramKeyStore.aliases();
    Object localObject = null;
    while (localEnumeration.hasMoreElements())
    {
      String str = (String)localEnumeration.nextElement();
      if (paramKeyStore.isKeyEntry(str))
        localObject = str;
    }
    if (localObject == null)
      throw new IllegalArgumentException("can't find a private key in keyStore: " + paramString);
    return localObject;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.ExampleUtils
 * JD-Core Version:    0.6.0
 */