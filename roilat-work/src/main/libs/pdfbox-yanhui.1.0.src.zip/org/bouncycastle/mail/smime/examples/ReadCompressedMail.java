package org.bouncycastle.mail.smime.examples;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.mail.smime.SMIMECompressed;
import org.bouncycastle.mail.smime.SMIMEUtil;

public class ReadCompressedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new FileInputStream("compressed.message"));
    SMIMECompressed localSMIMECompressed = new SMIMECompressed(localMimeMessage);
    MimeBodyPart localMimeBodyPart = SMIMEUtil.toMimeBodyPart(localSMIMECompressed.getContent());
    System.out.println("Message Contents");
    System.out.println("----------------");
    System.out.println(localMimeBodyPart.getContent());
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.ReadCompressedMail
 * JD-Core Version:    0.6.0
 */