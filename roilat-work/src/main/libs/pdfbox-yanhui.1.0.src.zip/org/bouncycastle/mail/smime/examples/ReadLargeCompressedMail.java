package org.bouncycastle.mail.smime.examples;

import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.mail.smime.SMIMECompressedParser;
import org.bouncycastle.mail.smime.SMIMEUtil;
import org.bouncycastle.mail.smime.util.FileBackedMimeBodyPart;
import org.bouncycastle.mail.smime.util.SharedFileInputStream;

public class ReadLargeCompressedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new SharedFileInputStream("compressed.message"));
    SMIMECompressedParser localSMIMECompressedParser = new SMIMECompressedParser(localMimeMessage);
    FileBackedMimeBodyPart localFileBackedMimeBodyPart = SMIMEUtil.toMimeBodyPart(localSMIMECompressedParser.getContent());
    ExampleUtils.dumpContent(localFileBackedMimeBodyPart, paramArrayOfString[0]);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.ReadLargeCompressedMail
 * JD-Core Version:    0.6.0
 */