package org.bouncycastle.mail.smime.examples;

import java.io.PrintStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.cms.RecipientInformation;
import org.bouncycastle.cms.RecipientInformationStore;
import org.bouncycastle.cms.jcajce.JceKeyTransEnvelopedRecipient;
import org.bouncycastle.cms.jcajce.JceKeyTransRecipientId;
import org.bouncycastle.mail.smime.SMIMEEnvelopedParser;
import org.bouncycastle.mail.smime.SMIMEUtil;
import org.bouncycastle.mail.smime.util.FileBackedMimeBodyPart;
import org.bouncycastle.mail.smime.util.SharedFileInputStream;

public class ReadLargeEncryptedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    if (paramArrayOfString.length != 3)
    {
      System.err.println("usage: ReadLargeEncryptedMail pkcs12Keystore password outputFile");
      System.exit(0);
    }
    KeyStore localKeyStore = KeyStore.getInstance("PKCS12", "BC");
    String str = ExampleUtils.findKeyAlias(localKeyStore, paramArrayOfString[0], paramArrayOfString[1].toCharArray());
    X509Certificate localX509Certificate = (X509Certificate)localKeyStore.getCertificate(str);
    JceKeyTransRecipientId localJceKeyTransRecipientId = new JceKeyTransRecipientId(localX509Certificate);
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new SharedFileInputStream("encrypted.message"));
    SMIMEEnvelopedParser localSMIMEEnvelopedParser = new SMIMEEnvelopedParser(localMimeMessage);
    RecipientInformationStore localRecipientInformationStore = localSMIMEEnvelopedParser.getRecipientInfos();
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localJceKeyTransRecipientId);
    FileBackedMimeBodyPart localFileBackedMimeBodyPart = SMIMEUtil.toMimeBodyPart(localRecipientInformation.getContentStream(new JceKeyTransEnvelopedRecipient((PrivateKey)localKeyStore.getKey(str, null)).setProvider("BC")));
    ExampleUtils.dumpContent(localFileBackedMimeBodyPart, paramArrayOfString[2]);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.ReadLargeEncryptedMail
 * JD-Core Version:    0.6.0
 */