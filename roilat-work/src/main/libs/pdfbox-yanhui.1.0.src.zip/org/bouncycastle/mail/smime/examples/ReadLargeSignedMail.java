package org.bouncycastle.mail.smime.examples;

import java.io.PrintStream;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mail.smime.SMIMESignedParser;
import org.bouncycastle.mail.smime.util.SharedFileInputStream;
import org.bouncycastle.util.Store;

public class ReadLargeSignedMail
{
  private static final String BC = BouncyCastleProvider.PROVIDER_NAME;

  private static void verify(SMIMESignedParser paramSMIMESignedParser)
    throws Exception
  {
    Store localStore = paramSMIMESignedParser.getCertificates();
    SignerInformationStore localSignerInformationStore = paramSMIMESignedParser.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = localStore.getMatches(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = new JcaX509CertificateConverter().setProvider(BC).getCertificate((X509CertificateHolder)localIterator2.next());
      if (localSignerInformation.verify(new JcaSimpleSignerInfoVerifierBuilder().setProvider(BC).build(localX509Certificate)))
        System.out.println("signature verified");
      else
        System.out.println("signature failed!");
    }
  }

  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new SharedFileInputStream("signed.message"));
    SMIMESignedParser localSMIMESignedParser;
    if (localMimeMessage.isMimeType("multipart/signed"))
    {
      localSMIMESignedParser = new SMIMESignedParser((MimeMultipart)localMimeMessage.getContent());
      System.out.println("Status:");
      verify(localSMIMESignedParser);
    }
    else if (localMimeMessage.isMimeType("application/pkcs7-mime"))
    {
      localSMIMESignedParser = new SMIMESignedParser(localMimeMessage);
      System.out.println("Status:");
      verify(localSMIMESignedParser);
    }
    else
    {
      System.err.println("Not a signed message!");
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.ReadLargeSignedMail
 * JD-Core Version:    0.6.0
 */