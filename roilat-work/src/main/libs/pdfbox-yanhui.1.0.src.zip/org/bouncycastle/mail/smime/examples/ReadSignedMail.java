package org.bouncycastle.mail.smime.examples;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;
import javax.mail.BodyPart;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mail.smime.SMIMESigned;
import org.bouncycastle.util.Store;

public class ReadSignedMail
{
  private static final String BC = BouncyCastleProvider.PROVIDER_NAME;

  private static void verify(SMIMESigned paramSMIMESigned)
    throws Exception
  {
    Store localStore = paramSMIMESigned.getCertificates();
    SignerInformationStore localSignerInformationStore = paramSMIMESigned.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = localStore.getMatches(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = new JcaX509CertificateConverter().setProvider(BC).getCertificate((X509CertificateHolder)localIterator2.next());
      if (localSignerInformation.verify(new JcaSimpleSignerInfoVerifierBuilder().setProvider(BC).build(localX509Certificate)))
        System.out.println("signature verified");
      else
        System.out.println("signature failed!");
    }
  }

  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new FileInputStream("signed.message"));
    SMIMESigned localSMIMESigned;
    MimeBodyPart localMimeBodyPart;
    Object localObject1;
    if (localMimeMessage.isMimeType("multipart/signed"))
    {
      localSMIMESigned = new SMIMESigned((MimeMultipart)localMimeMessage.getContent());
      localMimeBodyPart = localSMIMESigned.getContent();
      System.out.println("Content:");
      localObject1 = localMimeBodyPart.getContent();
      if ((localObject1 instanceof String))
      {
        System.out.println((String)localObject1);
      }
      else if ((localObject1 instanceof Multipart))
      {
        Multipart localMultipart = (Multipart)localObject1;
        int i = localMultipart.getCount();
        for (int j = 0; j < i; j++)
        {
          BodyPart localBodyPart = localMultipart.getBodyPart(j);
          Object localObject2 = localBodyPart.getContent();
          System.out.println("Part " + j);
          System.out.println("---------------------------");
          if ((localObject2 instanceof String))
            System.out.println((String)localObject2);
          else
            System.out.println("can't print...");
        }
      }
      System.out.println("Status:");
      verify(localSMIMESigned);
    }
    else if ((localMimeMessage.isMimeType("application/pkcs7-mime")) || (localMimeMessage.isMimeType("application/x-pkcs7-mime")))
    {
      localSMIMESigned = new SMIMESigned(localMimeMessage);
      localMimeBodyPart = localSMIMESigned.getContent();
      System.out.println("Content:");
      localObject1 = localMimeBodyPart.getContent();
      if ((localObject1 instanceof String))
        System.out.println((String)localObject1);
      System.out.println("Status:");
      verify(localSMIMESigned);
    }
    else
    {
      System.err.println("Not a signed message!");
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.ReadSignedMail
 * JD-Core Version:    0.6.0
 */