package org.bouncycastle.mail.smime.examples;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.security.KeyStore;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.smime.SMIMECapabilitiesAttribute;
import org.bouncycastle.asn1.smime.SMIMECapability;
import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
import org.bouncycastle.asn1.smime.SMIMEEncryptionKeyPreferenceAttribute;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cms.CMSAlgorithm;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;
import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
import org.bouncycastle.mail.smime.SMIMEException;
import org.bouncycastle.mail.smime.SMIMESignedGenerator;
import org.bouncycastle.util.Strings;

public class SendSignedAndEncryptedMail
{
  public static void main(String[] paramArrayOfString)
  {
    if (paramArrayOfString.length != 5)
    {
      System.err.println("usage: SendSignedAndEncryptedMail <pkcs12Keystore> <password> <keyalias> <smtp server> <email address>");
      System.exit(0);
    }
    try
    {
      MailcapCommandMap localMailcapCommandMap = (MailcapCommandMap)CommandMap.getDefaultCommandMap();
      localMailcapCommandMap.addMailcap("application/pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_signature");
      localMailcapCommandMap.addMailcap("application/pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_mime");
      localMailcapCommandMap.addMailcap("application/x-pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_signature");
      localMailcapCommandMap.addMailcap("application/x-pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_mime");
      localMailcapCommandMap.addMailcap("multipart/signed;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.multipart_signed");
      CommandMap.setDefaultCommandMap(localMailcapCommandMap);
      Security.addProvider(new BouncyCastleProvider());
      KeyStore localKeyStore = KeyStore.getInstance("PKCS12", "BC");
      localKeyStore.load(new FileInputStream(paramArrayOfString[0]), paramArrayOfString[1].toCharArray());
      Certificate[] arrayOfCertificate = localKeyStore.getCertificateChain(paramArrayOfString[2]);
      PrivateKey localPrivateKey = (PrivateKey)localKeyStore.getKey(paramArrayOfString[2], paramArrayOfString[1].toCharArray());
      if (localPrivateKey == null)
        throw new Exception("cannot find private key for alias: " + paramArrayOfString[2]);
      Properties localProperties = System.getProperties();
      localProperties.put("mail.smtp.host", paramArrayOfString[3]);
      Session localSession = Session.getDefaultInstance(localProperties, null);
      MimeMessage localMimeMessage1 = new MimeMessage(localSession);
      localMimeMessage1.setFrom(new InternetAddress(paramArrayOfString[4]));
      localMimeMessage1.setRecipient(Message.RecipientType.TO, new InternetAddress(paramArrayOfString[4]));
      localMimeMessage1.setSubject("example encrypted message");
      localMimeMessage1.setContent("example encrypted message", "text/plain");
      localMimeMessage1.saveChanges();
      SMIMECapabilityVector localSMIMECapabilityVector = new SMIMECapabilityVector();
      localSMIMECapabilityVector.addCapability(SMIMECapability.dES_EDE3_CBC);
      localSMIMECapabilityVector.addCapability(SMIMECapability.rC2_CBC, 128);
      localSMIMECapabilityVector.addCapability(SMIMECapability.dES_CBC);
      ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
      localASN1EncodableVector.add(new SMIMEEncryptionKeyPreferenceAttribute(new IssuerAndSerialNumber(new X500Name(((X509Certificate)arrayOfCertificate[0]).getIssuerDN().getName()), ((X509Certificate)arrayOfCertificate[0]).getSerialNumber())));
      localASN1EncodableVector.add(new SMIMECapabilitiesAttribute(localSMIMECapabilityVector));
      SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
      localSMIMESignedGenerator.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder().setProvider("BC").setSignedAttributeGenerator(new AttributeTable(localASN1EncodableVector)).build("DSA".equals(localPrivateKey.getAlgorithm()) ? "SHA1withDSA" : "MD5withDSA", localPrivateKey, (X509Certificate)arrayOfCertificate[0]));
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(arrayOfCertificate[0]);
      JcaCertStore localJcaCertStore = new JcaCertStore(localArrayList);
      localSMIMESignedGenerator.addCertificates(localJcaCertStore);
      MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(localMimeMessage1, "BC");
      MimeMessage localMimeMessage2 = new MimeMessage(localSession);
      Enumeration localEnumeration = localMimeMessage1.getAllHeaderLines();
      while (localEnumeration.hasMoreElements())
        localMimeMessage2.addHeaderLine((String)localEnumeration.nextElement());
      localMimeMessage2.setContent(localMimeMultipart);
      localMimeMessage2.saveChanges();
      SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
      localSMIMEEnvelopedGenerator.addRecipientInfoGenerator(new JceKeyTransRecipientInfoGenerator((X509Certificate)arrayOfCertificate[0]).setProvider("BC"));
      MimeBodyPart localMimeBodyPart = localSMIMEEnvelopedGenerator.generate(localMimeMessage2, new JceCMSContentEncryptorBuilder(CMSAlgorithm.RC2_CBC).setProvider("BC").build());
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      localMimeBodyPart.writeTo(localByteArrayOutputStream);
      MimeMessage localMimeMessage3 = new MimeMessage(localSession, new ByteArrayInputStream(localByteArrayOutputStream.toByteArray()));
      localEnumeration = localMimeMessage1.getAllHeaderLines();
      while (localEnumeration.hasMoreElements())
      {
        String str = (String)localEnumeration.nextElement();
        if (!Strings.toLowerCase(str).startsWith("content-"))
          localMimeMessage3.addHeaderLine(str);
      }
      Transport.send(localMimeMessage3);
    }
    catch (SMIMEException localSMIMEException)
    {
      localSMIMEException.getUnderlyingException().printStackTrace(System.err);
      localSMIMEException.printStackTrace(System.err);
    }
    catch (Exception localException)
    {
      localException.printStackTrace(System.err);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.examples.SendSignedAndEncryptedMail
 * JD-Core Version:    0.6.0
 */