package org.bouncycastle.mail.smime.handlers;

import java.awt.datatransfer.DataFlavor;
import java.io.BufferedInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.mail.smime.SMIMEStreamingProcessor;

public class multipart_signed
  implements DataContentHandler
{
  private static final ActivationDataFlavor ADF = new ActivationDataFlavor(MimeMultipart.class, "multipart/signed", "Multipart Signed");
  private static final DataFlavor[] DFS = { ADF };

  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    try
    {
      return new MimeMultipart(paramDataSource);
    }
    catch (MessagingException localMessagingException)
    {
    }
    return null;
  }

  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (ADF.equals(paramDataFlavor))
      return getContent(paramDataSource);
    return null;
  }

  public DataFlavor[] getTransferDataFlavors()
  {
    return DFS;
  }

  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof MimeMultipart))
    {
      try
      {
        outputBodyPart(paramOutputStream, paramObject);
      }
      catch (MessagingException localMessagingException)
      {
        throw new IOException(localMessagingException.getMessage());
      }
    }
    else if ((paramObject instanceof byte[]))
    {
      paramOutputStream.write((byte[])(byte[])paramObject);
    }
    else if ((paramObject instanceof InputStream))
    {
      Object localObject = (InputStream)paramObject;
      if (!(localObject instanceof BufferedInputStream))
        localObject = new BufferedInputStream((InputStream)localObject);
      int i;
      while ((i = ((InputStream)localObject).read()) >= 0)
        paramOutputStream.write(i);
    }
    else if ((paramObject instanceof SMIMEStreamingProcessor))
    {
      SMIMEStreamingProcessor localSMIMEStreamingProcessor = (SMIMEStreamingProcessor)paramObject;
      localSMIMEStreamingProcessor.write(paramOutputStream);
    }
    else
    {
      throw new IOException("unknown object in writeTo " + paramObject);
    }
  }

  private void outputBodyPart(OutputStream paramOutputStream, Object paramObject)
    throws MessagingException, IOException
  {
    Object localObject2;
    Object localObject3;
    Object localObject4;
    if ((paramObject instanceof Multipart))
    {
      localObject1 = (Multipart)paramObject;
      localObject2 = new ContentType(((Multipart)localObject1).getContentType());
      localObject3 = "--" + ((ContentType)localObject2).getParameter("boundary");
      localObject4 = new LineOutputStream(paramOutputStream);
      for (int i = 0; i < ((Multipart)localObject1).getCount(); i++)
      {
        ((LineOutputStream)localObject4).writeln((String)localObject3);
        outputBodyPart(paramOutputStream, ((Multipart)localObject1).getBodyPart(i));
        ((LineOutputStream)localObject4).writeln();
      }
      ((LineOutputStream)localObject4).writeln((String)localObject3 + "--");
      return;
    }
    Object localObject1 = (MimeBodyPart)paramObject;
    if ((((MimeBodyPart)localObject1).getContent() instanceof Multipart))
    {
      localObject2 = (Multipart)((MimeBodyPart)localObject1).getContent();
      localObject3 = new ContentType(((Multipart)localObject2).getContentType());
      localObject4 = "--" + ((ContentType)localObject3).getParameter("boundary");
      LineOutputStream localLineOutputStream = new LineOutputStream(paramOutputStream);
      Enumeration localEnumeration = ((MimeBodyPart)localObject1).getAllHeaderLines();
      while (localEnumeration.hasMoreElements())
        localLineOutputStream.writeln((String)localEnumeration.nextElement());
      localLineOutputStream.writeln();
      outputPreamble(localLineOutputStream, (MimeBodyPart)localObject1, (String)localObject4);
      outputBodyPart(paramOutputStream, localObject2);
      return;
    }
    ((MimeBodyPart)localObject1).writeTo(paramOutputStream);
  }

  static void outputPreamble(LineOutputStream paramLineOutputStream, MimeBodyPart paramMimeBodyPart, String paramString)
    throws MessagingException, IOException
  {
    InputStream localInputStream;
    try
    {
      localInputStream = paramMimeBodyPart.getRawInputStream();
    }
    catch (MessagingException localMessagingException)
    {
      return;
    }
    String str;
    while (((str = readLine(localInputStream)) != null) && (!str.equals(paramString)))
      paramLineOutputStream.writeln(str);
    localInputStream.close();
    if (str == null)
      throw new MessagingException("no boundary found");
  }

  private static String readLine(InputStream paramInputStream)
    throws IOException
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i;
    while (((i = paramInputStream.read()) >= 0) && (i != 10))
    {
      if (i == 13)
        continue;
      localStringBuffer.append((char)i);
    }
    if (i < 0)
      return null;
    return localStringBuffer.toString();
  }

  private static class LineOutputStream extends FilterOutputStream
  {
    private static byte[] newline = new byte[2];

    public LineOutputStream(OutputStream paramOutputStream)
    {
      super();
    }

    public void writeln(String paramString)
      throws MessagingException
    {
      try
      {
        byte[] arrayOfByte = getBytes(paramString);
        this.out.write(arrayOfByte);
        this.out.write(newline);
      }
      catch (Exception localException)
      {
        throw new MessagingException("IOException", localException);
      }
    }

    public void writeln()
      throws MessagingException
    {
      try
      {
        this.out.write(newline);
      }
      catch (Exception localException)
      {
        throw new MessagingException("IOException", localException);
      }
    }

    private static byte[] getBytes(String paramString)
    {
      char[] arrayOfChar = paramString.toCharArray();
      int i = arrayOfChar.length;
      byte[] arrayOfByte = new byte[i];
      int j = 0;
      while (j < i)
        arrayOfByte[j] = (byte)arrayOfChar[(j++)];
      return arrayOfByte;
    }

    static
    {
      newline[0] = 13;
      newline[1] = 10;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.handlers.multipart_signed
 * JD-Core Version:    0.6.0
 */