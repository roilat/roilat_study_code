package org.bouncycastle.mail.smime.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import javax.mail.MessagingException;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;

public class FileBackedMimeBodyPart extends MimeBodyPart
{
  private static final int BUF_SIZE = 32760;
  private final File _file;

  public FileBackedMimeBodyPart(File paramFile)
    throws MessagingException, IOException
  {
    super(new SharedFileInputStream(paramFile));
    this._file = paramFile;
  }

  public FileBackedMimeBodyPart(InputStream paramInputStream, File paramFile)
    throws MessagingException, IOException
  {
    this(saveStreamToFile(paramInputStream, paramFile));
  }

  public FileBackedMimeBodyPart(InternetHeaders paramInternetHeaders, InputStream paramInputStream, File paramFile)
    throws MessagingException, IOException
  {
    this(saveStreamToFile(paramInternetHeaders, paramInputStream, paramFile));
  }

  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    if (!this._file.exists())
      throw new IOException("file " + this._file.getCanonicalPath() + " no longer exists.");
    super.writeTo(paramOutputStream);
  }

  public void dispose()
    throws IOException
  {
    ((SharedFileInputStream)this.contentStream).getRoot().dispose();
    if ((this._file.exists()) && (!this._file.delete()))
      throw new IOException("deletion of underlying file <" + this._file.getCanonicalPath() + "> failed.");
  }

  private static File saveStreamToFile(InputStream paramInputStream, File paramFile)
    throws IOException
  {
    saveContentToStream(new FileOutputStream(paramFile), paramInputStream);
    return paramFile;
  }

  private static File saveStreamToFile(InternetHeaders paramInternetHeaders, InputStream paramInputStream, File paramFile)
    throws IOException
  {
    FileOutputStream localFileOutputStream = new FileOutputStream(paramFile);
    Enumeration localEnumeration = paramInternetHeaders.getAllHeaderLines();
    while (localEnumeration.hasMoreElements())
      writeHeader(localFileOutputStream, (String)localEnumeration.nextElement());
    writeSeperator(localFileOutputStream);
    saveContentToStream(localFileOutputStream, paramInputStream);
    return paramFile;
  }

  private static void writeHeader(OutputStream paramOutputStream, String paramString)
    throws IOException
  {
    for (int i = 0; i != paramString.length(); i++)
      paramOutputStream.write(paramString.charAt(i));
    writeSeperator(paramOutputStream);
  }

  private static void writeSeperator(OutputStream paramOutputStream)
    throws IOException
  {
    paramOutputStream.write(13);
    paramOutputStream.write(10);
  }

  private static void saveContentToStream(OutputStream paramOutputStream, InputStream paramInputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[32760];
    int i;
    while ((i = paramInputStream.read(arrayOfByte, 0, arrayOfByte.length)) > 0)
      paramOutputStream.write(arrayOfByte, 0, i);
    paramOutputStream.close();
    paramInputStream.close();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.util.FileBackedMimeBodyPart
 * JD-Core Version:    0.6.0
 */