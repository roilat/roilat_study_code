package org.bouncycastle.mail.smime.validator;

import org.bouncycastle.i18n.ErrorBundle;
import org.bouncycastle.i18n.LocalizedException;

public class SignedMailValidatorException extends LocalizedException
{
  public SignedMailValidatorException(ErrorBundle paramErrorBundle, Throwable paramThrowable)
  {
    super(paramErrorBundle, paramThrowable);
  }

  public SignedMailValidatorException(ErrorBundle paramErrorBundle)
  {
    super(paramErrorBundle);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.mail.smime.validator.SignedMailValidatorException
 * JD-Core Version:    0.6.0
 */