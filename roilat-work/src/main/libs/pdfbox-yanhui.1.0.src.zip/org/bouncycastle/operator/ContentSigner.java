package org.bouncycastle.operator;

import java.io.OutputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface ContentSigner
{
  public abstract AlgorithmIdentifier getAlgorithmIdentifier();

  public abstract OutputStream getOutputStream();

  public abstract byte[] getSignature();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.ContentSigner
 * JD-Core Version:    0.6.0
 */