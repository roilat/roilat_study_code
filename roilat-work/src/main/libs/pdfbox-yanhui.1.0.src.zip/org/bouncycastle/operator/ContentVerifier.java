package org.bouncycastle.operator;

import java.io.OutputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface ContentVerifier
{
  public abstract AlgorithmIdentifier getAlgorithmIdentifier();

  public abstract OutputStream getOutputStream();

  public abstract boolean verify(byte[] paramArrayOfByte);
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.ContentVerifier
 * JD-Core Version:    0.6.0
 */