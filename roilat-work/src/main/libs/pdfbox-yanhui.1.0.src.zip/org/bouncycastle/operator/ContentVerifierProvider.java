package org.bouncycastle.operator;

import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cert.X509CertificateHolder;

public abstract interface ContentVerifierProvider
{
  public abstract boolean hasAssociatedCertificate();

  public abstract X509CertificateHolder getAssociatedCertificate();

  public abstract ContentVerifier get(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws OperatorCreationException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.ContentVerifierProvider
 * JD-Core Version:    0.6.0
 */