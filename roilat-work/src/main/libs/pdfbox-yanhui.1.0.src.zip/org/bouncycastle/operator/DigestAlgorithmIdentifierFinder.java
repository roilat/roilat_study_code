package org.bouncycastle.operator;

import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface DigestAlgorithmIdentifierFinder
{
  public abstract AlgorithmIdentifier find(AlgorithmIdentifier paramAlgorithmIdentifier);
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.DigestAlgorithmIdentifierFinder
 * JD-Core Version:    0.6.0
 */