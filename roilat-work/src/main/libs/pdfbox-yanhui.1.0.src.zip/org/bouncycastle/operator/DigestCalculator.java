package org.bouncycastle.operator;

import java.io.OutputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface DigestCalculator
{
  public abstract AlgorithmIdentifier getAlgorithmIdentifier();

  public abstract OutputStream getOutputStream();

  public abstract byte[] getDigest();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.DigestCalculator
 * JD-Core Version:    0.6.0
 */