package org.bouncycastle.operator;

public class GenericKey
{
  private Object representation;

  public GenericKey(Object paramObject)
  {
    this.representation = paramObject;
  }

  public Object getRepresentation()
  {
    return this.representation;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.GenericKey
 * JD-Core Version:    0.6.0
 */