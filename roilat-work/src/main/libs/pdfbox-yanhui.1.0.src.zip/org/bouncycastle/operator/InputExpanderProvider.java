package org.bouncycastle.operator;

import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface InputExpanderProvider
{
  public abstract InputExpander get(AlgorithmIdentifier paramAlgorithmIdentifier);
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.InputExpanderProvider
 * JD-Core Version:    0.6.0
 */