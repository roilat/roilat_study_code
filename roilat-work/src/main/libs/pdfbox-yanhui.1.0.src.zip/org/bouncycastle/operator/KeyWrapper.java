package org.bouncycastle.operator;

import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface KeyWrapper
{
  public abstract AlgorithmIdentifier getAlgorithmIdentifier();

  public abstract byte[] generateWrappedKey(GenericKey paramGenericKey)
    throws OperatorException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.KeyWrapper
 * JD-Core Version:    0.6.0
 */