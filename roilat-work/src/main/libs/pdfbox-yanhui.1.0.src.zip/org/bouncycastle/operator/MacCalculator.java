package org.bouncycastle.operator;

import java.io.OutputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface MacCalculator
{
  public abstract AlgorithmIdentifier getAlgorithmIdentifier();

  public abstract OutputStream getOutputStream();

  public abstract byte[] getMac();

  public abstract GenericKey getKey();
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.MacCalculator
 * JD-Core Version:    0.6.0
 */