package org.bouncycastle.operator;

public class OperatorCreationException extends OperatorException
{
  public OperatorCreationException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }

  public OperatorCreationException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.OperatorCreationException
 * JD-Core Version:    0.6.0
 */