package org.bouncycastle.operator;

public abstract interface RawContentVerifier
{
  public abstract boolean verify(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.RawContentVerifier
 * JD-Core Version:    0.6.0
 */