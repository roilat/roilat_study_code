package org.bouncycastle.operator;

public class RuntimeOperatorException extends RuntimeException
{
  private Throwable cause;

  public RuntimeOperatorException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    this.cause = paramThrowable;
  }

  public Throwable getCause()
  {
    return this.cause;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.RuntimeOperatorException
 * JD-Core Version:    0.6.0
 */