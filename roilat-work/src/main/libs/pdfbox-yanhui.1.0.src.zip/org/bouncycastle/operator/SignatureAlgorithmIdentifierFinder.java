package org.bouncycastle.operator;

import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract interface SignatureAlgorithmIdentifierFinder
{
  public abstract AlgorithmIdentifier find(String paramString);
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.SignatureAlgorithmIdentifierFinder
 * JD-Core Version:    0.6.0
 */