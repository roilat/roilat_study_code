package org.bouncycastle.operator.bc;

import java.io.OutputStream;
import java.security.SecureRandom;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.crypto.Signer;
import org.bouncycastle.crypto.params.AsymmetricKeyParameter;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.RuntimeOperatorException;

public abstract class BcContentSignerBuilder
{
  private SecureRandom random;
  private AlgorithmIdentifier sigAlgId;
  private AlgorithmIdentifier digAlgId;

  public BcContentSignerBuilder(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2)
  {
    this.sigAlgId = paramAlgorithmIdentifier1;
    this.digAlgId = paramAlgorithmIdentifier2;
  }

  public BcContentSignerBuilder setSecureRandom(SecureRandom paramSecureRandom)
  {
    this.random = paramSecureRandom;
    return this;
  }

  public ContentSigner build(AsymmetricKeyParameter paramAsymmetricKeyParameter)
    throws OperatorCreationException
  {
    Signer localSigner = createSigner(this.sigAlgId, this.digAlgId);
    if (this.random != null)
      localSigner.init(true, new ParametersWithRandom(paramAsymmetricKeyParameter, this.random));
    else
      localSigner.init(true, paramAsymmetricKeyParameter);
    return new ContentSigner(localSigner)
    {
      private BcSignerOutputStream stream = new BcSignerOutputStream(this.val$sig);

      public AlgorithmIdentifier getAlgorithmIdentifier()
      {
        return BcContentSignerBuilder.this.sigAlgId;
      }

      public OutputStream getOutputStream()
      {
        return this.stream;
      }

      public byte[] getSignature()
      {
        try
        {
          return this.stream.getSignature();
        }
        catch (CryptoException localCryptoException)
        {
        }
        throw new RuntimeOperatorException("exception obtaining signature: " + localCryptoException.getMessage(), localCryptoException);
      }
    };
  }

  protected abstract Signer createSigner(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2)
    throws OperatorCreationException;
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.bc.BcContentSignerBuilder
 * JD-Core Version:    0.6.0
 */