package org.bouncycastle.operator.bc;

import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.crypto.Signer;
import org.bouncycastle.crypto.params.AsymmetricKeyParameter;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;
import org.bouncycastle.operator.OperatorCreationException;

public abstract class BcContentVerifierProviderBuilder
{
  public ContentVerifierProvider build(X509CertificateHolder paramX509CertificateHolder)
    throws OperatorCreationException
  {
    return new ContentVerifierProvider(paramX509CertificateHolder)
    {
      public boolean hasAssociatedCertificate()
      {
        return true;
      }

      public X509CertificateHolder getAssociatedCertificate()
      {
        return this.val$certHolder;
      }

      public ContentVerifier get(AlgorithmIdentifier paramAlgorithmIdentifier)
        throws OperatorCreationException
      {
        try
        {
          AsymmetricKeyParameter localAsymmetricKeyParameter = BcContentVerifierProviderBuilder.this.extractKeyParameters(this.val$certHolder.getSubjectPublicKeyInfo());
          BcSignerOutputStream localBcSignerOutputStream = BcContentVerifierProviderBuilder.this.createSignatureStream(paramAlgorithmIdentifier, localAsymmetricKeyParameter);
          return new BcContentVerifierProviderBuilder.SigVerifier(BcContentVerifierProviderBuilder.this, paramAlgorithmIdentifier, localBcSignerOutputStream);
        }
        catch (IOException localIOException)
        {
        }
        throw new OperatorCreationException("exception on setup: " + localIOException, localIOException);
      }
    };
  }

  public ContentVerifierProvider build(AsymmetricKeyParameter paramAsymmetricKeyParameter)
    throws OperatorCreationException
  {
    return new ContentVerifierProvider(paramAsymmetricKeyParameter)
    {
      public boolean hasAssociatedCertificate()
      {
        return false;
      }

      public X509CertificateHolder getAssociatedCertificate()
      {
        return null;
      }

      public ContentVerifier get(AlgorithmIdentifier paramAlgorithmIdentifier)
        throws OperatorCreationException
      {
        BcSignerOutputStream localBcSignerOutputStream = BcContentVerifierProviderBuilder.this.createSignatureStream(paramAlgorithmIdentifier, this.val$publicKey);
        return new BcContentVerifierProviderBuilder.SigVerifier(BcContentVerifierProviderBuilder.this, paramAlgorithmIdentifier, localBcSignerOutputStream);
      }
    };
  }

  private BcSignerOutputStream createSignatureStream(AlgorithmIdentifier paramAlgorithmIdentifier, AsymmetricKeyParameter paramAsymmetricKeyParameter)
    throws OperatorCreationException
  {
    Signer localSigner = createSigner(paramAlgorithmIdentifier);
    localSigner.init(false, paramAsymmetricKeyParameter);
    return new BcSignerOutputStream(localSigner);
  }

  protected abstract AsymmetricKeyParameter extractKeyParameters(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
    throws IOException;

  protected abstract Signer createSigner(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws OperatorCreationException;

  private class SigVerifier
    implements ContentVerifier
  {
    private BcSignerOutputStream stream;
    private AlgorithmIdentifier algorithm;

    SigVerifier(AlgorithmIdentifier paramBcSignerOutputStream, BcSignerOutputStream arg3)
    {
      this.algorithm = paramBcSignerOutputStream;
      Object localObject;
      this.stream = localObject;
    }

    public AlgorithmIdentifier getAlgorithmIdentifier()
    {
      return this.algorithm;
    }

    public OutputStream getOutputStream()
    {
      if (this.stream == null)
        throw new IllegalStateException("verifier not initialised");
      return this.stream;
    }

    public boolean verify(byte[] paramArrayOfByte)
    {
      return this.stream.verify(paramArrayOfByte);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.bc.BcContentVerifierProviderBuilder
 * JD-Core Version:    0.6.0
 */