package org.bouncycastle.operator.bc;

import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;

public class BcDigestCalculatorProvider
  implements DigestCalculatorProvider
{
  private DigestOutputStream stream;

  public DigestCalculator get(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws OperatorCreationException
  {
    Digest localDigest = BcUtil.createDigest(paramAlgorithmIdentifier);
    this.stream = new DigestOutputStream(localDigest);
    return new DigestCalculator(paramAlgorithmIdentifier)
    {
      public AlgorithmIdentifier getAlgorithmIdentifier()
      {
        return this.val$algorithm;
      }

      public OutputStream getOutputStream()
      {
        return BcDigestCalculatorProvider.this.stream;
      }

      public byte[] getDigest()
      {
        return BcDigestCalculatorProvider.this.stream.getDigest();
      }
    };
  }

  private class DigestOutputStream extends OutputStream
  {
    private Digest dig;

    DigestOutputStream(Digest arg2)
    {
      Object localObject;
      this.dig = localObject;
    }

    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this.dig.update(paramArrayOfByte, paramInt1, paramInt2);
    }

    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this.dig.update(paramArrayOfByte, 0, paramArrayOfByte.length);
    }

    public void write(int paramInt)
      throws IOException
    {
      this.dig.update((byte)paramInt);
    }

    byte[] getDigest()
    {
      byte[] arrayOfByte = new byte[this.dig.getDigestSize()];
      this.dig.doFinal(arrayOfByte, 0);
      return arrayOfByte;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.bc.BcDigestCalculatorProvider
 * JD-Core Version:    0.6.0
 */