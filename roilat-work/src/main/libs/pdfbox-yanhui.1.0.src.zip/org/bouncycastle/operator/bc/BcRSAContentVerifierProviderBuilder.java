package org.bouncycastle.operator.bc;

import java.io.IOException;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.Signer;
import org.bouncycastle.crypto.params.AsymmetricKeyParameter;
import org.bouncycastle.crypto.signers.RSADigestSigner;
import org.bouncycastle.crypto.util.PublicKeyFactory;
import org.bouncycastle.operator.DigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.OperatorCreationException;

public class BcRSAContentVerifierProviderBuilder extends BcContentVerifierProviderBuilder
{
  private DigestAlgorithmIdentifierFinder digestAlgorithmFinder;

  public BcRSAContentVerifierProviderBuilder(DigestAlgorithmIdentifierFinder paramDigestAlgorithmIdentifierFinder)
  {
    this.digestAlgorithmFinder = paramDigestAlgorithmIdentifierFinder;
  }

  protected Signer createSigner(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws OperatorCreationException
  {
    AlgorithmIdentifier localAlgorithmIdentifier = this.digestAlgorithmFinder.find(paramAlgorithmIdentifier);
    Digest localDigest = BcUtil.createDigest(localAlgorithmIdentifier);
    return new RSADigestSigner(localDigest);
  }

  protected AsymmetricKeyParameter extractKeyParameters(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
    throws IOException
  {
    return PublicKeyFactory.createKey(paramSubjectPublicKeyInfo);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.bc.BcRSAContentVerifierProviderBuilder
 * JD-Core Version:    0.6.0
 */