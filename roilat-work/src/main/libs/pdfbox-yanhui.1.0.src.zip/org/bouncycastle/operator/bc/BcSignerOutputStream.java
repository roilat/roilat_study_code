package org.bouncycastle.operator.bc;

import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.crypto.Signer;

public class BcSignerOutputStream extends OutputStream
{
  private Signer sig;

  BcSignerOutputStream(Signer paramSigner)
  {
    this.sig = paramSigner;
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.sig.update(paramArrayOfByte, paramInt1, paramInt2);
  }

  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    this.sig.update(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public void write(int paramInt)
    throws IOException
  {
    this.sig.update((byte)paramInt);
  }

  byte[] getSignature()
    throws CryptoException
  {
    return this.sig.generateSignature();
  }

  boolean verify(byte[] paramArrayOfByte)
  {
    return this.sig.verifySignature(paramArrayOfByte);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.bc.BcSignerOutputStream
 * JD-Core Version:    0.6.0
 */