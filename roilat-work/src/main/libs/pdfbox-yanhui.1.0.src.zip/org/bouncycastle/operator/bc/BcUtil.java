package org.bouncycastle.operator.bc;

import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.MD4Digest;
import org.bouncycastle.crypto.digests.MD5Digest;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.digests.SHA224Digest;
import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.digests.SHA384Digest;
import org.bouncycastle.operator.OperatorCreationException;

class BcUtil
{
  static Digest createDigest(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws OperatorCreationException
  {
    Object localObject;
    if (paramAlgorithmIdentifier.getAlgorithm().equals(OIWObjectIdentifiers.idSHA1))
      localObject = new SHA1Digest();
    else if (paramAlgorithmIdentifier.getAlgorithm().equals(NISTObjectIdentifiers.id_sha224))
      localObject = new SHA224Digest();
    else if (paramAlgorithmIdentifier.getAlgorithm().equals(NISTObjectIdentifiers.id_sha256))
      localObject = new SHA256Digest();
    else if (paramAlgorithmIdentifier.getAlgorithm().equals(NISTObjectIdentifiers.id_sha384))
      localObject = new SHA384Digest();
    else if (paramAlgorithmIdentifier.getAlgorithm().equals(NISTObjectIdentifiers.id_sha512))
      localObject = new SHA384Digest();
    else if (paramAlgorithmIdentifier.getAlgorithm().equals(PKCSObjectIdentifiers.md5))
      localObject = new MD5Digest();
    else if (paramAlgorithmIdentifier.getAlgorithm().equals(PKCSObjectIdentifiers.md4))
      localObject = new MD4Digest();
    else
      throw new OperatorCreationException("cannot recognise digest");
    return (Digest)localObject;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.bc.BcUtil
 * JD-Core Version:    0.6.0
 */