package org.bouncycastle.operator.bc;

import java.security.Key;
import org.bouncycastle.operator.GenericKey;

class OperatorUtils
{
  static byte[] getKeyBytes(GenericKey paramGenericKey)
  {
    if ((paramGenericKey.getRepresentation() instanceof Key))
      return ((Key)paramGenericKey.getRepresentation()).getEncoded();
    if ((paramGenericKey.getRepresentation() instanceof byte[]))
      return (byte[])(byte[])paramGenericKey.getRepresentation();
    throw new IllegalArgumentException("unknown generic key type");
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.bc.OperatorUtils
 * JD-Core Version:    0.6.0
 */