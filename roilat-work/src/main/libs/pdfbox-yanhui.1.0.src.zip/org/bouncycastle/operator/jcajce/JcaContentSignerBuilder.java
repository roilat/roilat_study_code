package org.bouncycastle.operator.jcajce;

import java.io.IOException;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.DefaultSignatureAlgorithmIdentifierFinder;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.OperatorStreamException;
import org.bouncycastle.operator.RuntimeOperatorException;

public class JcaContentSignerBuilder
{
  private OperatorHelper helper = new OperatorHelper(new DefaultJcaJceHelper());
  private SecureRandom random;
  private String signatureAlgorithm;
  private AlgorithmIdentifier sigAlgId;

  public JcaContentSignerBuilder(String paramString)
  {
    this.signatureAlgorithm = paramString;
    this.sigAlgId = new DefaultSignatureAlgorithmIdentifierFinder().find(paramString);
  }

  public JcaContentSignerBuilder setProvider(Provider paramProvider)
  {
    this.helper = new OperatorHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JcaContentSignerBuilder setProvider(String paramString)
  {
    this.helper = new OperatorHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public JcaContentSignerBuilder setSecureRandom(SecureRandom paramSecureRandom)
  {
    this.random = paramSecureRandom;
    return this;
  }

  public ContentSigner build(PrivateKey paramPrivateKey)
    throws OperatorCreationException
  {
    try
    {
      Signature localSignature = this.helper.createSignature(this.sigAlgId);
      if (this.random != null)
        localSignature.initSign(paramPrivateKey, this.random);
      else
        localSignature.initSign(paramPrivateKey);
      return new ContentSigner(localSignature)
      {
        private JcaContentSignerBuilder.SignatureOutputStream stream = new JcaContentSignerBuilder.SignatureOutputStream(JcaContentSignerBuilder.this, this.val$sig);

        public AlgorithmIdentifier getAlgorithmIdentifier()
        {
          return JcaContentSignerBuilder.this.sigAlgId;
        }

        public OutputStream getOutputStream()
        {
          return this.stream;
        }

        public byte[] getSignature()
        {
          try
          {
            return this.stream.getSignature();
          }
          catch (SignatureException localSignatureException)
          {
          }
          throw new RuntimeOperatorException("exception obtaining signature: " + localSignatureException.getMessage(), localSignatureException);
        }
      };
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new OperatorCreationException("cannot create signer: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  private class SignatureOutputStream extends OutputStream
  {
    private Signature sig;

    SignatureOutputStream(Signature arg2)
    {
      Object localObject;
      this.sig = localObject;
    }

    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      try
      {
        this.sig.update(paramArrayOfByte, paramInt1, paramInt2);
      }
      catch (SignatureException localSignatureException)
      {
        throw new OperatorStreamException("exception in content signer: " + localSignatureException.getMessage(), localSignatureException);
      }
    }

    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      try
      {
        this.sig.update(paramArrayOfByte);
      }
      catch (SignatureException localSignatureException)
      {
        throw new OperatorStreamException("exception in content signer: " + localSignatureException.getMessage(), localSignatureException);
      }
    }

    public void write(int paramInt)
      throws IOException
    {
      try
      {
        this.sig.update((byte)paramInt);
      }
      catch (SignatureException localSignatureException)
      {
        throw new OperatorStreamException("exception in content signer: " + localSignatureException.getMessage(), localSignatureException);
      }
    }

    byte[] getSignature()
      throws SignatureException
    {
      return this.sig.sign();
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
 * JD-Core Version:    0.6.0
 */