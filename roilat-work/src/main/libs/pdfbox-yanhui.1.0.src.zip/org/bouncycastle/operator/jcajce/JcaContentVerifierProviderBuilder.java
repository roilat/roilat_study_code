package org.bouncycastle.operator.jcajce;

import java.io.IOException;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.OperatorStreamException;
import org.bouncycastle.operator.RawContentVerifier;
import org.bouncycastle.operator.RuntimeOperatorException;

public class JcaContentVerifierProviderBuilder
{
  private OperatorHelper helper = new OperatorHelper(new DefaultJcaJceHelper());

  public JcaContentVerifierProviderBuilder setProvider(Provider paramProvider)
  {
    this.helper = new OperatorHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JcaContentVerifierProviderBuilder setProvider(String paramString)
  {
    this.helper = new OperatorHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public ContentVerifierProvider build(X509CertificateHolder paramX509CertificateHolder)
    throws OperatorCreationException, CertificateException
  {
    return build(this.helper.convertCertificate(paramX509CertificateHolder));
  }

  public ContentVerifierProvider build(X509Certificate paramX509Certificate)
    throws OperatorCreationException
  {
    JcaX509CertificateHolder localJcaX509CertificateHolder;
    try
    {
      localJcaX509CertificateHolder = new JcaX509CertificateHolder(paramX509Certificate);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
      throw new OperatorCreationException("cannot process certificate: " + localCertificateEncodingException.getMessage(), localCertificateEncodingException);
    }
    return new ContentVerifierProvider(localJcaX509CertificateHolder, paramX509Certificate)
    {
      private JcaContentVerifierProviderBuilder.SignatureOutputStream stream;

      public boolean hasAssociatedCertificate()
      {
        return true;
      }

      public X509CertificateHolder getAssociatedCertificate()
      {
        return this.val$certHolder;
      }

      public ContentVerifier get(AlgorithmIdentifier paramAlgorithmIdentifier)
        throws OperatorCreationException
      {
        try
        {
          Signature localSignature1 = JcaContentVerifierProviderBuilder.this.helper.createSignature(paramAlgorithmIdentifier);
          localSignature1.initVerify(this.val$certificate.getPublicKey());
          this.stream = new JcaContentVerifierProviderBuilder.SignatureOutputStream(JcaContentVerifierProviderBuilder.this, localSignature1);
        }
        catch (GeneralSecurityException localGeneralSecurityException)
        {
          throw new OperatorCreationException("exception on setup: " + localGeneralSecurityException, localGeneralSecurityException);
        }
        Signature localSignature2 = JcaContentVerifierProviderBuilder.this.createRawSig(paramAlgorithmIdentifier, this.val$certificate.getPublicKey());
        if (localSignature2 != null)
          return new JcaContentVerifierProviderBuilder.RawSigVerifier(JcaContentVerifierProviderBuilder.this, paramAlgorithmIdentifier, this.stream, localSignature2);
        return new JcaContentVerifierProviderBuilder.SigVerifier(JcaContentVerifierProviderBuilder.this, paramAlgorithmIdentifier, this.stream);
      }
    };
  }

  public ContentVerifierProvider build(PublicKey paramPublicKey)
    throws OperatorCreationException
  {
    return new ContentVerifierProvider(paramPublicKey)
    {
      public boolean hasAssociatedCertificate()
      {
        return false;
      }

      public X509CertificateHolder getAssociatedCertificate()
      {
        return null;
      }

      public ContentVerifier get(AlgorithmIdentifier paramAlgorithmIdentifier)
        throws OperatorCreationException
      {
        JcaContentVerifierProviderBuilder.SignatureOutputStream localSignatureOutputStream = JcaContentVerifierProviderBuilder.this.createSignatureStream(paramAlgorithmIdentifier, this.val$publicKey);
        Signature localSignature = JcaContentVerifierProviderBuilder.this.createRawSig(paramAlgorithmIdentifier, this.val$publicKey);
        if (localSignature != null)
          return new JcaContentVerifierProviderBuilder.RawSigVerifier(JcaContentVerifierProviderBuilder.this, paramAlgorithmIdentifier, localSignatureOutputStream, localSignature);
        return new JcaContentVerifierProviderBuilder.SigVerifier(JcaContentVerifierProviderBuilder.this, paramAlgorithmIdentifier, localSignatureOutputStream);
      }
    };
  }

  private SignatureOutputStream createSignatureStream(AlgorithmIdentifier paramAlgorithmIdentifier, PublicKey paramPublicKey)
    throws OperatorCreationException
  {
    try
    {
      Signature localSignature = this.helper.createSignature(paramAlgorithmIdentifier);
      localSignature.initVerify(paramPublicKey);
      return new SignatureOutputStream(localSignature);
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new OperatorCreationException("exception on setup: " + localGeneralSecurityException, localGeneralSecurityException);
  }

  private Signature createRawSig(AlgorithmIdentifier paramAlgorithmIdentifier, PublicKey paramPublicKey)
  {
    Signature localSignature;
    try
    {
      localSignature = this.helper.createRawSignature(paramAlgorithmIdentifier);
      localSignature.initVerify(paramPublicKey);
    }
    catch (Exception localException)
    {
      localSignature = null;
    }
    return localSignature;
  }

  private class RawSigVerifier extends JcaContentVerifierProviderBuilder.SigVerifier
    implements RawContentVerifier
  {
    private Signature rawSignature;

    RawSigVerifier(AlgorithmIdentifier paramSignatureOutputStream, JcaContentVerifierProviderBuilder.SignatureOutputStream paramSignature, Signature arg4)
    {
      super(paramSignatureOutputStream, paramSignature);
      Object localObject;
      this.rawSignature = localObject;
    }

    public boolean verify(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    {
      try
      {
        this.rawSignature.update(paramArrayOfByte1);
        return this.rawSignature.verify(paramArrayOfByte2);
      }
      catch (SignatureException localSignatureException)
      {
      }
      throw new RuntimeOperatorException("exception obtaining raw signature: " + localSignatureException.getMessage(), localSignatureException);
    }
  }

  private class SigVerifier
    implements ContentVerifier
  {
    private JcaContentVerifierProviderBuilder.SignatureOutputStream stream;
    private AlgorithmIdentifier algorithm;

    SigVerifier(AlgorithmIdentifier paramSignatureOutputStream, JcaContentVerifierProviderBuilder.SignatureOutputStream arg3)
    {
      this.algorithm = paramSignatureOutputStream;
      Object localObject;
      this.stream = localObject;
    }

    public AlgorithmIdentifier getAlgorithmIdentifier()
    {
      return this.algorithm;
    }

    public OutputStream getOutputStream()
    {
      if (this.stream == null)
        throw new IllegalStateException("verifier not initialised");
      return this.stream;
    }

    public boolean verify(byte[] paramArrayOfByte)
    {
      try
      {
        return this.stream.verify(paramArrayOfByte);
      }
      catch (SignatureException localSignatureException)
      {
      }
      throw new RuntimeOperatorException("exception obtaining signature: " + localSignatureException.getMessage(), localSignatureException);
    }
  }

  private class SignatureOutputStream extends OutputStream
  {
    private Signature sig;

    SignatureOutputStream(Signature arg2)
    {
      Object localObject;
      this.sig = localObject;
    }

    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      try
      {
        this.sig.update(paramArrayOfByte, paramInt1, paramInt2);
      }
      catch (SignatureException localSignatureException)
      {
        throw new OperatorStreamException("exception in content signer: " + localSignatureException.getMessage(), localSignatureException);
      }
    }

    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      try
      {
        this.sig.update(paramArrayOfByte);
      }
      catch (SignatureException localSignatureException)
      {
        throw new OperatorStreamException("exception in content signer: " + localSignatureException.getMessage(), localSignatureException);
      }
    }

    public void write(int paramInt)
      throws IOException
    {
      try
      {
        this.sig.update((byte)paramInt);
      }
      catch (SignatureException localSignatureException)
      {
        throw new OperatorStreamException("exception in content signer: " + localSignatureException.getMessage(), localSignatureException);
      }
    }

    boolean verify(byte[] paramArrayOfByte)
      throws SignatureException
    {
      return this.sig.verify(paramArrayOfByte);
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.jcajce.JcaContentVerifierProviderBuilder
 * JD-Core Version:    0.6.0
 */