package org.bouncycastle.operator.jcajce;

import java.io.IOException;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.Provider;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;

public class JcaDigestCalculatorProviderBuilder
{
  private OperatorHelper helper = new OperatorHelper(new DefaultJcaJceHelper());

  public JcaDigestCalculatorProviderBuilder setProvider(Provider paramProvider)
  {
    this.helper = new OperatorHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JcaDigestCalculatorProviderBuilder setProvider(String paramString)
  {
    this.helper = new OperatorHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public DigestCalculatorProvider build()
    throws OperatorCreationException
  {
    return new DigestCalculatorProvider()
    {
      public DigestCalculator get(AlgorithmIdentifier paramAlgorithmIdentifier)
        throws OperatorCreationException
      {
        JcaDigestCalculatorProviderBuilder.DigestOutputStream localDigestOutputStream;
        try
        {
          MessageDigest localMessageDigest = JcaDigestCalculatorProviderBuilder.this.helper.createDigest(paramAlgorithmIdentifier);
          localDigestOutputStream = new JcaDigestCalculatorProviderBuilder.DigestOutputStream(JcaDigestCalculatorProviderBuilder.this, localMessageDigest);
        }
        catch (GeneralSecurityException localGeneralSecurityException)
        {
          throw new OperatorCreationException("exception on setup: " + localGeneralSecurityException, localGeneralSecurityException);
        }
        return new DigestCalculator(paramAlgorithmIdentifier, localDigestOutputStream)
        {
          public AlgorithmIdentifier getAlgorithmIdentifier()
          {
            return this.val$algorithm;
          }

          public OutputStream getOutputStream()
          {
            return this.val$stream;
          }

          public byte[] getDigest()
          {
            return this.val$stream.getDigest();
          }
        };
      }
    };
  }

  private class DigestOutputStream extends OutputStream
  {
    private MessageDigest dig;

    DigestOutputStream(MessageDigest arg2)
    {
      Object localObject;
      this.dig = localObject;
    }

    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this.dig.update(paramArrayOfByte, paramInt1, paramInt2);
    }

    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this.dig.update(paramArrayOfByte);
    }

    public void write(int paramInt)
      throws IOException
    {
      this.dig.update((byte)paramInt);
    }

    byte[] getDigest()
    {
      return this.dig.digest();
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder
 * JD-Core Version:    0.6.0
 */