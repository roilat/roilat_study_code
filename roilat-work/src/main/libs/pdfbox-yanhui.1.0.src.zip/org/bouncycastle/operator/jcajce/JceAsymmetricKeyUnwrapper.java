package org.bouncycastle.operator.jcajce;

import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.ProviderException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.AsymmetricKeyUnwrapper;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.OperatorException;

public class JceAsymmetricKeyUnwrapper extends AsymmetricKeyUnwrapper
{
  private OperatorHelper helper = new OperatorHelper(new DefaultJcaJceHelper());
  private PrivateKey privKey;

  public JceAsymmetricKeyUnwrapper(AlgorithmIdentifier paramAlgorithmIdentifier, PrivateKey paramPrivateKey)
  {
    super(paramAlgorithmIdentifier);
    this.privKey = paramPrivateKey;
  }

  public JceAsymmetricKeyUnwrapper setProvider(Provider paramProvider)
  {
    this.helper = new OperatorHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceAsymmetricKeyUnwrapper setProvider(String paramString)
  {
    this.helper = new OperatorHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public GenericKey generateUnwrappedKey(AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
    throws OperatorException
  {
    try
    {
      Object localObject = null;
      Cipher localCipher = this.helper.createAsymmetricWrapper(getAlgorithmIdentifier().getAlgorithm());
      try
      {
        localCipher.init(4, this.privKey);
        localObject = localCipher.unwrap(paramArrayOfByte, paramAlgorithmIdentifier.getAlgorithm().getId(), 3);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
      }
      catch (ProviderException localProviderException)
      {
      }
      if (localObject == null)
      {
        localCipher.init(2, this.privKey);
        localObject = new SecretKeySpec(localCipher.doFinal(paramArrayOfByte), paramAlgorithmIdentifier.getAlgorithm().getId());
      }
      return new GenericKey(localObject);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new OperatorException("key invalid: " + localInvalidKeyException.getMessage(), localInvalidKeyException);
    }
    catch (IllegalBlockSizeException localIllegalBlockSizeException)
    {
      throw new OperatorException("illegal blocksize: " + localIllegalBlockSizeException.getMessage(), localIllegalBlockSizeException);
    }
    catch (BadPaddingException localBadPaddingException)
    {
    }
    throw new OperatorException("bad padding: " + localBadPaddingException.getMessage(), localBadPaddingException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.jcajce.JceAsymmetricKeyUnwrapper
 * JD-Core Version:    0.6.0
 */