package org.bouncycastle.operator.jcajce;

import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.Provider;
import java.security.ProviderException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.crypto.Cipher;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.AsymmetricKeyWrapper;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.OperatorException;

public class JceAsymmetricKeyWrapper extends AsymmetricKeyWrapper
{
  private OperatorHelper helper = new OperatorHelper(new DefaultJcaJceHelper());
  private PublicKey publicKey;
  private SecureRandom random;

  public JceAsymmetricKeyWrapper(PublicKey paramPublicKey)
  {
    super(SubjectPublicKeyInfo.getInstance(paramPublicKey.getEncoded()).getAlgorithmId());
    this.publicKey = paramPublicKey;
  }

  public JceAsymmetricKeyWrapper(X509Certificate paramX509Certificate)
  {
    this(paramX509Certificate.getPublicKey());
  }

  public JceAsymmetricKeyWrapper setProvider(Provider paramProvider)
  {
    this.helper = new OperatorHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceAsymmetricKeyWrapper setProvider(String paramString)
  {
    this.helper = new OperatorHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public JceAsymmetricKeyWrapper setSecureRandom(SecureRandom paramSecureRandom)
  {
    this.random = paramSecureRandom;
    return this;
  }

  public byte[] generateWrappedKey(GenericKey paramGenericKey)
    throws OperatorException
  {
    Cipher localCipher = this.helper.createAsymmetricWrapper(getAlgorithmIdentifier().getAlgorithm());
    byte[] arrayOfByte = null;
    try
    {
      localCipher.init(3, this.publicKey, this.random);
      arrayOfByte = localCipher.wrap(OperatorUtils.getJceKey(paramGenericKey));
    }
    catch (GeneralSecurityException localGeneralSecurityException1)
    {
    }
    catch (IllegalStateException localIllegalStateException)
    {
    }
    catch (UnsupportedOperationException localUnsupportedOperationException)
    {
    }
    catch (ProviderException localProviderException)
    {
    }
    if (arrayOfByte == null)
      try
      {
        localCipher.init(1, this.publicKey, this.random);
        arrayOfByte = localCipher.doFinal(OperatorUtils.getJceKey(paramGenericKey).getEncoded());
      }
      catch (GeneralSecurityException localGeneralSecurityException2)
      {
        throw new OperatorException("unable to encrypt contents key", localGeneralSecurityException2);
      }
    return arrayOfByte;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.jcajce.JceAsymmetricKeyWrapper
 * JD-Core Version:    0.6.0
 */