package org.bouncycastle.operator.jcajce;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.operator.GenericKey;
import org.bouncycastle.operator.OperatorException;
import org.bouncycastle.operator.SymmetricKeyUnwrapper;

public class JceSymmetricKeyUnwrapper extends SymmetricKeyUnwrapper
{
  private OperatorHelper helper = new OperatorHelper(new DefaultJcaJceHelper());
  private SecretKey secretKey;

  public JceSymmetricKeyUnwrapper(AlgorithmIdentifier paramAlgorithmIdentifier, SecretKey paramSecretKey)
  {
    super(paramAlgorithmIdentifier);
    this.secretKey = paramSecretKey;
  }

  public JceSymmetricKeyUnwrapper setProvider(Provider paramProvider)
  {
    this.helper = new OperatorHelper(new ProviderJcaJceHelper(paramProvider));
    return this;
  }

  public JceSymmetricKeyUnwrapper setProvider(String paramString)
  {
    this.helper = new OperatorHelper(new NamedJcaJceHelper(paramString));
    return this;
  }

  public GenericKey generateUnwrappedKey(AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
    throws OperatorException
  {
    try
    {
      Cipher localCipher = this.helper.createSymmetricWrapper(getAlgorithmIdentifier().getAlgorithm());
      localCipher.init(4, this.secretKey);
      return new GenericKey(localCipher.unwrap(paramArrayOfByte, paramAlgorithmIdentifier.getAlgorithm().getId(), 3));
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new OperatorException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
    }
    throw new OperatorException("can't find algorithm.", localNoSuchAlgorithmException);
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.jcajce.JceSymmetricKeyUnwrapper
 * JD-Core Version:    0.6.0
 */