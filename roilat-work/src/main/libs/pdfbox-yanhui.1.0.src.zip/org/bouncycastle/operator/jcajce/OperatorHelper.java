package org.bouncycastle.operator.jcajce;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Signature;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cryptopro.CryptoProObjectIdentifiers;
import org.bouncycastle.asn1.kisa.KISAObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.ntt.NTTObjectIdentifiers;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.RSASSAPSSparams;
import org.bouncycastle.asn1.teletrust.TeleTrusTObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.jcajce.JcaJceHelper;
import org.bouncycastle.operator.OperatorCreationException;

class OperatorHelper
{
  private static final Map oids = new HashMap();
  private static final Map asymmetricWrapperAlgNames = new HashMap();
  private static final Map symmetricWrapperAlgNames = new HashMap();
  private JcaJceHelper helper;

  OperatorHelper(JcaJceHelper paramJcaJceHelper)
  {
    this.helper = paramJcaJceHelper;
  }

  Cipher createAsymmetricWrapper(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws OperatorCreationException
  {
    try
    {
      String str = (String)asymmetricWrapperAlgNames.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createCipher(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createCipher(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new OperatorCreationException("cannot create cipher: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  Cipher createSymmetricWrapper(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
    throws OperatorCreationException
  {
    try
    {
      String str = (String)symmetricWrapperAlgNames.get(paramASN1ObjectIdentifier);
      if (str != null)
        try
        {
          return this.helper.createCipher(str);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
        }
      return this.helper.createCipher(paramASN1ObjectIdentifier.getId());
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new OperatorCreationException("cannot create cipher: " + localGeneralSecurityException.getMessage(), localGeneralSecurityException);
  }

  MessageDigest createDigest(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws GeneralSecurityException
  {
    MessageDigest localMessageDigest;
    try
    {
      localMessageDigest = this.helper.createDigest(getSignatureName(paramAlgorithmIdentifier));
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      if (oids.get(paramAlgorithmIdentifier.getAlgorithm()) != null)
      {
        String str = (String)oids.get(paramAlgorithmIdentifier.getAlgorithm());
        localMessageDigest = this.helper.createDigest(str);
      }
      else
      {
        throw localNoSuchAlgorithmException;
      }
    }
    return localMessageDigest;
  }

  Signature createSignature(AlgorithmIdentifier paramAlgorithmIdentifier)
    throws GeneralSecurityException
  {
    Signature localSignature;
    try
    {
      localSignature = this.helper.createSignature(getSignatureName(paramAlgorithmIdentifier));
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      if (oids.get(paramAlgorithmIdentifier.getAlgorithm()) != null)
      {
        String str = (String)oids.get(paramAlgorithmIdentifier.getAlgorithm());
        localSignature = this.helper.createSignature(str);
      }
      else
      {
        throw localNoSuchAlgorithmException;
      }
    }
    return localSignature;
  }

  public Signature createRawSignature(AlgorithmIdentifier paramAlgorithmIdentifier)
  {
    Signature localSignature;
    try
    {
      String str = getSignatureName(paramAlgorithmIdentifier);
      str = "NONE" + str.substring(str.indexOf("WITH"));
      localSignature = this.helper.createSignature(str);
    }
    catch (Exception localException)
    {
      return null;
    }
    return localSignature;
  }

  private static String getSignatureName(AlgorithmIdentifier paramAlgorithmIdentifier)
  {
    DEREncodable localDEREncodable = paramAlgorithmIdentifier.getParameters();
    if ((localDEREncodable != null) && (!DERNull.INSTANCE.equals(localDEREncodable)) && (paramAlgorithmIdentifier.getAlgorithm().equals(PKCSObjectIdentifiers.id_RSASSA_PSS)))
    {
      RSASSAPSSparams localRSASSAPSSparams = RSASSAPSSparams.getInstance(localDEREncodable);
      return getDigestAlgName(localRSASSAPSSparams.getHashAlgorithm().getAlgorithm()) + "withRSAandMGF1";
    }
    if (oids.containsKey(paramAlgorithmIdentifier.getAlgorithm()))
      return (String)oids.get(paramAlgorithmIdentifier.getAlgorithm());
    return paramAlgorithmIdentifier.getAlgorithm().getId();
  }

  private static String getDigestAlgName(DERObjectIdentifier paramDERObjectIdentifier)
  {
    if (PKCSObjectIdentifiers.md5.equals(paramDERObjectIdentifier))
      return "MD5";
    if (OIWObjectIdentifiers.idSHA1.equals(paramDERObjectIdentifier))
      return "SHA1";
    if (NISTObjectIdentifiers.id_sha224.equals(paramDERObjectIdentifier))
      return "SHA224";
    if (NISTObjectIdentifiers.id_sha256.equals(paramDERObjectIdentifier))
      return "SHA256";
    if (NISTObjectIdentifiers.id_sha384.equals(paramDERObjectIdentifier))
      return "SHA384";
    if (NISTObjectIdentifiers.id_sha512.equals(paramDERObjectIdentifier))
      return "SHA512";
    if (TeleTrusTObjectIdentifiers.ripemd128.equals(paramDERObjectIdentifier))
      return "RIPEMD128";
    if (TeleTrusTObjectIdentifiers.ripemd160.equals(paramDERObjectIdentifier))
      return "RIPEMD160";
    if (TeleTrusTObjectIdentifiers.ripemd256.equals(paramDERObjectIdentifier))
      return "RIPEMD256";
    if (CryptoProObjectIdentifiers.gostR3411.equals(paramDERObjectIdentifier))
      return "GOST3411";
    return paramDERObjectIdentifier.getId();
  }

  public X509Certificate convertCertificate(X509CertificateHolder paramX509CertificateHolder)
    throws CertificateException
  {
    try
    {
      CertificateFactory localCertificateFactory = this.helper.createCertificateFactory("X.509");
      return (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(paramX509CertificateHolder.getEncoded()));
    }
    catch (IOException localIOException)
    {
      throw new OpCertificateException("cannot get encoded form of certificate: " + localIOException.getMessage(), localIOException);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new OpCertificateException("cannot create certificate factory: " + localNoSuchAlgorithmException.getMessage(), localNoSuchAlgorithmException);
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
    }
    throw new OpCertificateException("cannot find factory provider: " + localNoSuchProviderException.getMessage(), localNoSuchProviderException);
  }

  static
  {
    oids.put(new DERObjectIdentifier("1.2.840.113549.1.1.5"), "SHA1WITHRSA");
    oids.put(PKCSObjectIdentifiers.sha224WithRSAEncryption, "SHA224WITHRSA");
    oids.put(PKCSObjectIdentifiers.sha256WithRSAEncryption, "SHA256WITHRSA");
    oids.put(PKCSObjectIdentifiers.sha384WithRSAEncryption, "SHA384WITHRSA");
    oids.put(PKCSObjectIdentifiers.sha512WithRSAEncryption, "SHA512WITHRSA");
    oids.put(CryptoProObjectIdentifiers.gostR3411_94_with_gostR3410_94, "GOST3411WITHGOST3410");
    oids.put(CryptoProObjectIdentifiers.gostR3411_94_with_gostR3410_2001, "GOST3411WITHECGOST3410");
    oids.put(new DERObjectIdentifier("1.2.840.113549.1.1.4"), "MD5WITHRSA");
    oids.put(new DERObjectIdentifier("1.2.840.113549.1.1.2"), "MD2WITHRSA");
    oids.put(new DERObjectIdentifier("1.2.840.10040.4.3"), "SHA1WITHDSA");
    oids.put(X9ObjectIdentifiers.ecdsa_with_SHA1, "SHA1WITHECDSA");
    oids.put(X9ObjectIdentifiers.ecdsa_with_SHA224, "SHA224WITHECDSA");
    oids.put(X9ObjectIdentifiers.ecdsa_with_SHA256, "SHA256WITHECDSA");
    oids.put(X9ObjectIdentifiers.ecdsa_with_SHA384, "SHA384WITHECDSA");
    oids.put(X9ObjectIdentifiers.ecdsa_with_SHA512, "SHA512WITHECDSA");
    oids.put(OIWObjectIdentifiers.sha1WithRSA, "SHA1WITHRSA");
    oids.put(OIWObjectIdentifiers.dsaWithSHA1, "SHA1WITHDSA");
    oids.put(NISTObjectIdentifiers.dsa_with_sha224, "SHA224WITHDSA");
    oids.put(NISTObjectIdentifiers.dsa_with_sha256, "SHA256WITHDSA");
    asymmetricWrapperAlgNames.put(new ASN1ObjectIdentifier(PKCSObjectIdentifiers.rsaEncryption.getId()), "RSA/ECB/PKCS1Padding");
    symmetricWrapperAlgNames.put(PKCSObjectIdentifiers.id_alg_CMS3DESwrap, "DESEDEWrap");
    symmetricWrapperAlgNames.put(NISTObjectIdentifiers.id_aes128_wrap, "AESWrap");
    symmetricWrapperAlgNames.put(NISTObjectIdentifiers.id_aes192_wrap, "AESWrap");
    symmetricWrapperAlgNames.put(NISTObjectIdentifiers.id_aes256_wrap, "AESWrap");
    symmetricWrapperAlgNames.put(NTTObjectIdentifiers.id_camellia128_wrap, "CamilliaWrap");
    symmetricWrapperAlgNames.put(NTTObjectIdentifiers.id_camellia192_wrap, "CamilliaWrap");
    symmetricWrapperAlgNames.put(NTTObjectIdentifiers.id_camellia256_wrap, "CamilliaWrap");
    symmetricWrapperAlgNames.put(KISAObjectIdentifiers.id_npki_app_cmsSeed_wrap, "SEEDWrap");
  }

  private static class OpCertificateException extends CertificateException
  {
    private Throwable cause;

    public OpCertificateException(String paramString, Throwable paramThrowable)
    {
      super();
      this.cause = paramThrowable;
    }

    public Throwable getCause()
    {
      return this.cause;
    }
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.jcajce.OperatorHelper
 * JD-Core Version:    0.6.0
 */