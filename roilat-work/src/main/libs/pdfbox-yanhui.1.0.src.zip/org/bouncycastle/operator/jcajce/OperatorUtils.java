package org.bouncycastle.operator.jcajce;

import java.security.Key;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.operator.GenericKey;

class OperatorUtils
{
  static Key getJceKey(GenericKey paramGenericKey)
  {
    if ((paramGenericKey.getRepresentation() instanceof Key))
      return (Key)paramGenericKey.getRepresentation();
    if ((paramGenericKey.getRepresentation() instanceof byte[]))
      return new SecretKeySpec((byte[])(byte[])paramGenericKey.getRepresentation(), "ENC");
    throw new IllegalArgumentException("unknown generic key type");
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.operator.jcajce.OperatorUtils
 * JD-Core Version:    0.6.0
 */