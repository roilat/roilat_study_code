package org.bouncycastle.pkcs;

import java.io.IOException;
import org.bouncycastle.asn1.pkcs.EncryptedPrivateKeyInfo;

public class EncryptedPrivateKeyInfoHolder
{
  private EncryptedPrivateKeyInfo encryptedPrivateKeyInfo;

  public EncryptedPrivateKeyInfoHolder(EncryptedPrivateKeyInfo paramEncryptedPrivateKeyInfo)
  {
    this.encryptedPrivateKeyInfo = paramEncryptedPrivateKeyInfo;
  }

  public EncryptedPrivateKeyInfo toASN1Structure()
  {
    return this.encryptedPrivateKeyInfo;
  }

  public byte[] getEncoded()
    throws IOException
  {
    return this.encryptedPrivateKeyInfo.getEncoded();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.pkcs.EncryptedPrivateKeyInfoHolder
 * JD-Core Version:    0.6.0
 */