package org.bouncycastle.pkcs;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.pkcs.Attribute;
import org.bouncycastle.asn1.pkcs.CertificationRequest;
import org.bouncycastle.asn1.pkcs.CertificationRequestInfo;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.operator.ContentSigner;

public class PKCS10CertificationRequestBuilder
{
  private SubjectPublicKeyInfo publicKeyInfo;
  private X500Name subject;
  private List attributes = new ArrayList();

  public PKCS10CertificationRequestBuilder(X500Name paramX500Name, SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    this.subject = paramX500Name;
    this.publicKeyInfo = paramSubjectPublicKeyInfo;
  }

  public PKCS10CertificationRequestBuilder addAttribute(ASN1ObjectIdentifier paramASN1ObjectIdentifier, ASN1Encodable paramASN1Encodable)
  {
    this.attributes.add(new Attribute(paramASN1ObjectIdentifier, new DERSet(paramASN1Encodable)));
    return this;
  }

  public PKCS10CertificationRequestBuilder addAttribute(ASN1ObjectIdentifier paramASN1ObjectIdentifier, ASN1Encodable[] paramArrayOfASN1Encodable)
  {
    this.attributes.add(new Attribute(paramASN1ObjectIdentifier, new DERSet(paramArrayOfASN1Encodable)));
    return this;
  }

  public PKCS10CertificationRequestHolder build(ContentSigner paramContentSigner)
  {
    CertificationRequestInfo localCertificationRequestInfo;
    Object localObject;
    if (this.attributes.isEmpty())
    {
      localCertificationRequestInfo = new CertificationRequestInfo(this.subject, this.publicKeyInfo, null);
    }
    else
    {
      localObject = new ASN1EncodableVector();
      Iterator localIterator = this.attributes.iterator();
      while (localIterator.hasNext())
        ((ASN1EncodableVector)localObject).add(Attribute.getInstance(localIterator.next()));
      localCertificationRequestInfo = new CertificationRequestInfo(this.subject, this.publicKeyInfo, new DERSet((ASN1EncodableVector)localObject));
    }
    try
    {
      localObject = paramContentSigner.getOutputStream();
      ((OutputStream)localObject).write(localCertificationRequestInfo.getDEREncoded());
      ((OutputStream)localObject).close();
      return new PKCS10CertificationRequestHolder(new CertificationRequest(localCertificationRequestInfo, paramContentSigner.getAlgorithmIdentifier(), new DERBitString(paramContentSigner.getSignature())));
    }
    catch (IOException localIOException)
    {
    }
    throw new IllegalStateException("cannot produce certification request signature");
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.pkcs.PKCS10CertificationRequestBuilder
 * JD-Core Version:    0.6.0
 */