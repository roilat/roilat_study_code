package org.bouncycastle.pkcs;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.pkcs.Attribute;
import org.bouncycastle.asn1.pkcs.CertificationRequest;
import org.bouncycastle.asn1.pkcs.CertificationRequestInfo;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.operator.ContentVerifier;
import org.bouncycastle.operator.ContentVerifierProvider;

public class PKCS10CertificationRequestHolder
{
  private static Attribute[] EMPTY_ARRAY = new Attribute[0];
  private CertificationRequest certificationRequest;

  private static CertificationRequest parseBytes(byte[] paramArrayOfByte)
    throws IOException
  {
    try
    {
      return CertificationRequest.getInstance(ASN1Object.fromByteArray(paramArrayOfByte));
    }
    catch (ClassCastException localClassCastException)
    {
      throw new PKCSIOException("malformed data: " + localClassCastException.getMessage(), localClassCastException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    throw new PKCSIOException("malformed data: " + localIllegalArgumentException.getMessage(), localIllegalArgumentException);
  }

  public PKCS10CertificationRequestHolder(CertificationRequest paramCertificationRequest)
  {
    this.certificationRequest = paramCertificationRequest;
  }

  public PKCS10CertificationRequestHolder(byte[] paramArrayOfByte)
    throws IOException
  {
    this(parseBytes(paramArrayOfByte));
  }

  public CertificationRequest toASN1Structure()
  {
    return this.certificationRequest;
  }

  public X500Name getSubject()
  {
    return X500Name.getInstance(this.certificationRequest.getCertificationRequestInfo().getSubject());
  }

  public AlgorithmIdentifier getSignatureAlgorithm()
  {
    return this.certificationRequest.getSignatureAlgorithm();
  }

  public byte[] getSignature()
  {
    return this.certificationRequest.getSignature().getBytes();
  }

  public SubjectPublicKeyInfo getSubjectPublicKeyInfo()
  {
    return this.certificationRequest.getCertificationRequestInfo().getSubjectPublicKeyInfo();
  }

  public Attribute[] getAttributes()
  {
    ASN1Set localASN1Set = this.certificationRequest.getCertificationRequestInfo().getAttributes();
    if (localASN1Set == null)
      return EMPTY_ARRAY;
    Attribute[] arrayOfAttribute = new Attribute[localASN1Set.size()];
    for (int i = 0; i != localASN1Set.size(); i++)
      arrayOfAttribute[i] = Attribute.getInstance(localASN1Set.getObjectAt(i));
    return arrayOfAttribute;
  }

  public Attribute[] getAttributes(ASN1ObjectIdentifier paramASN1ObjectIdentifier)
  {
    ASN1Set localASN1Set = this.certificationRequest.getCertificationRequestInfo().getAttributes();
    if (localASN1Set == null)
      return EMPTY_ARRAY;
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i != localASN1Set.size(); i++)
    {
      Attribute localAttribute = Attribute.getInstance(localASN1Set.getObjectAt(i));
      if (!localAttribute.getAttrType().equals(paramASN1ObjectIdentifier))
        continue;
      localArrayList.add(localAttribute);
    }
    if (localArrayList.size() == 0)
      return EMPTY_ARRAY;
    return (Attribute[])(Attribute[])localArrayList.toArray(new Attribute[localArrayList.size()]);
  }

  public byte[] getEncoded()
    throws IOException
  {
    return this.certificationRequest.getEncoded();
  }

  public boolean isSignatureValid(ContentVerifierProvider paramContentVerifierProvider)
    throws PKCSException
  {
    CertificationRequestInfo localCertificationRequestInfo = this.certificationRequest.getCertificationRequestInfo();
    ContentVerifier localContentVerifier;
    try
    {
      localContentVerifier = paramContentVerifierProvider.get(this.certificationRequest.getSignatureAlgorithm());
      OutputStream localOutputStream = localContentVerifier.getOutputStream();
      localOutputStream.write(localCertificationRequestInfo.getDEREncoded());
      localOutputStream.close();
    }
    catch (Exception localException)
    {
      throw new PKCSException("unable to process signature: " + localException.getMessage(), localException);
    }
    return localContentVerifier.verify(this.certificationRequest.getSignature().getBytes());
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof PKCS10CertificationRequestHolder))
      return false;
    PKCS10CertificationRequestHolder localPKCS10CertificationRequestHolder = (PKCS10CertificationRequestHolder)paramObject;
    return toASN1Structure().equals(localPKCS10CertificationRequestHolder.toASN1Structure());
  }

  public int hashCode()
  {
    return toASN1Structure().hashCode();
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.pkcs.PKCS10CertificationRequestHolder
 * JD-Core Version:    0.6.0
 */