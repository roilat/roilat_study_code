package org.bouncycastle.pkcs;

import java.io.IOException;

public class PKCSIOException extends IOException
{
  private Throwable cause;

  public PKCSIOException(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    this.cause = paramThrowable;
  }

  public PKCSIOException(String paramString)
  {
    super(paramString);
  }

  public Throwable getCause()
  {
    return this.cause;
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.pkcs.PKCSIOException
 * JD-Core Version:    0.6.0
 */