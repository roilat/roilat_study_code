package org.bouncycastle.pkcs.jcajce;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Hashtable;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.pkcs.CertificationRequest;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.jcajce.DefaultJcaJceHelper;
import org.bouncycastle.jcajce.JcaJceHelper;
import org.bouncycastle.jcajce.NamedJcaJceHelper;
import org.bouncycastle.jcajce.ProviderJcaJceHelper;
import org.bouncycastle.pkcs.PKCS10CertificationRequestHolder;

public class JcaPKCS10CertificationRequestHolder extends PKCS10CertificationRequestHolder
{
  private static Hashtable keyAlgorithms = new Hashtable();
  private JcaJceHelper helper = new DefaultJcaJceHelper();

  public JcaPKCS10CertificationRequestHolder(CertificationRequest paramCertificationRequest)
  {
    super(paramCertificationRequest);
  }

  public JcaPKCS10CertificationRequestHolder(byte[] paramArrayOfByte)
    throws IOException
  {
    super(paramArrayOfByte);
  }

  public JcaPKCS10CertificationRequestHolder(PKCS10CertificationRequestHolder paramPKCS10CertificationRequestHolder)
  {
    super(paramPKCS10CertificationRequestHolder.toASN1Structure());
  }

  public JcaPKCS10CertificationRequestHolder setProvider(String paramString)
  {
    this.helper = new NamedJcaJceHelper(paramString);
    return this;
  }

  public JcaPKCS10CertificationRequestHolder setProvider(Provider paramProvider)
  {
    this.helper = new ProviderJcaJceHelper(paramProvider);
    return this;
  }

  public PublicKey getPublicKey()
    throws InvalidKeyException, NoSuchAlgorithmException
  {
    try
    {
      SubjectPublicKeyInfo localSubjectPublicKeyInfo = getSubjectPublicKeyInfo();
      X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(localSubjectPublicKeyInfo.getEncoded());
      KeyFactory localKeyFactory;
      try
      {
        localKeyFactory = this.helper.createKeyFactory(localSubjectPublicKeyInfo.getAlgorithmId().getAlgorithm().getId());
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        if (keyAlgorithms.get(localSubjectPublicKeyInfo.getAlgorithmId().getAlgorithm()) != null)
        {
          String str = (String)keyAlgorithms.get(localSubjectPublicKeyInfo.getAlgorithmId().getAlgorithm());
          localKeyFactory = this.helper.createKeyFactory(str);
        }
        else
        {
          throw localNoSuchAlgorithmException;
        }
      }
      return localKeyFactory.generatePublic(localX509EncodedKeySpec);
    }
    catch (InvalidKeySpecException localInvalidKeySpecException)
    {
      throw new InvalidKeyException("error decoding public key");
    }
    catch (IOException localIOException)
    {
      throw new InvalidKeyException("error extracting key encoding");
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
    }
    throw new NoSuchAlgorithmException("cannot find provider: " + localNoSuchProviderException.getMessage());
  }

  static
  {
    keyAlgorithms.put(PKCSObjectIdentifiers.rsaEncryption, "RSA");
    keyAlgorithms.put(X9ObjectIdentifiers.id_dsa, "DSA");
  }
}

/* Location:           C:\Users\wb-dtw368035\Desktop\pdfbox-yanhui.1.0.jar
 * Qualified Name:     org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestHolder
 * JD-Core Version:    0.6.0
 */